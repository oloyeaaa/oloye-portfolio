---
name: clone-studio
description: Generate a branded talking-head video of Oloye in a chosen studio set. Pick a studio, give a script, get back a photoreal, lip-synced, brand-stamped clip. Four modes - full-Higgsfield (default, cheap, our stack), hybrid-image (Higgsfield studio scene → HeyGen animate + sync), hybrid-lipsync (fix sync on an existing Higgsfield clip), or HeyGen-native (trained avatar). Use for "make a talking head", "clone studio", "put me in a [podcast/office/dark studio] talking", "talking-head video". Owned IP; the studio prompt library can also be exported as a lead magnet.
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, mcp__claude_ai_HeyGen__create_lipsync, mcp__claude_ai_HeyGen__get_lipsync, mcp__claude_ai_HeyGen__create_video_from_image, mcp__claude_ai_HeyGen__create_video_from_avatar, mcp__claude_ai_HeyGen__get_video, mcp__claude_ai_HeyGen__create_photo_avatar, mcp__claude_ai_HeyGen__list_avatar_looks, mcp__claude_ai_HeyGen__list_voices, mcp__claude_ai_HeyGen__clone_voice, mcp__claude_ai_HeyGen__create_asset_upload, mcp__claude_ai_HeyGen__complete_asset_upload
---

# Clone Studio — branded talking-heads, 4 modes

Pick a studio, give a script, get a finished talking-head of Oloye: photoreal, lip-synced, in his voice, with the Signal-Lime rim light and the "Oloye." watermark. Four modes on top of two providers (Higgsfield + HeyGen direct API) so we can trade cost, brand control, and lip-sync quality per clip. Brand layer (rim light in-render + wordmark ffmpeg overlay) is applied every mode, so output is on-brand regardless.

## When to use
"make a talking head", "clone studio", "put me in the [podcast/office/dark] studio", "a video of me saying X".

## Requirements
- **Higgsfield MCP** connected, with credits available (used for image, audio, and video generation in every mode except `heygen-native`).
- **HeyGen MCP** connected for `hybrid-image`, `hybrid-lipsync`, and `heygen-native` modes. Plus plan: renders cap at 720p (see Operational rules).
- **ffmpeg on PATH** for the brand-layer watermark overlay (every mode).
- **Brain logging is optional and Oloye-specific**: the "Speak from the Brain" section below applies only if you run the Content Brain Loop. Skip it otherwise.

## Paths
All relative paths below (face reference, watermark overlay, save folders) resolve from the workspace root; on this machine that is `<workspace-root>`. If your current working directory is not the workspace root, prefix them with it, or they will silently fail.

## Speak from the Brain (memory)
Talking-heads are Oloye. brand content. After a clip is finished, log it to the Content table per the Content Brain Loop (`~/.claude/skills/_shared/brain-content-loop.md`): `YOUR_CONTENT_TABLE_ID`, Format=`video`, Owner=`<you>`, Status=`review`, Link=the clip, Copy=the script. If the script came from `reel-pipeline`/`youtube-pipeline` it is already logged, update that row instead of duplicating. Brand tokens (rim light, wordmark) match `brand/tokens/colors.css`.

## Inputs
- **Mode:** `full-higgsfield` (default), `hybrid-image`, `hybrid-lipsync`, or `heygen-native`. See the **Mode picker** table below.
- **Studio** (from the library below), or describe one.
- **Script** (short; one clip is best at ~8 to 15 seconds, see Length).
- **Voice:** default = Oloye's cloned voice **Oloye-1** on Higgsfield (`voice_id c64e0a60-2964-4335-adee-50dd2d159ecf`, `voice_type element`). Used to generate the audio in every mode except `heygen-native`, where HeyGen's own voice clone is used (see setup).
- **Face reference:** default = `Business/90-Day Awareness Campaign/brand/avatar-oloye-office.jpg` (relative to the workspace root, see Paths).

## Mode picker

| | full-higgsfield (default) | hybrid-image | hybrid-lipsync | heygen-native |
|---|---|---|---|---|
| **Scene generation** | Higgsfield `nano_banana_pro` (our studio library) | Higgsfield `nano_banana_pro` | Higgsfield `wan2_7` (video) | HeyGen `create_video_from_avatar` |
| **Voice** | Oloye-1 on Higgsfield Vibe Voice | Oloye-1 on Higgsfield Vibe Voice | Oloye-1 on Higgsfield Vibe Voice | HeyGen clone or Higgsfield-then-upload |
| **Animation + sync** | Higgsfield `wan2_7` | HeyGen `create_video_from_image` (precision) | HeyGen `create_lipsync` (mode: precision) on the existing video | HeyGen avatar engine (Avatar IV / V) |
| **Lip-sync quality** | ~OK, varies shot-to-shot | Premium | Premium (re-syncs whatever you already have) | Premium |
| **Brand control** | Full — studio prompt, Soul ID, lime rim | Full on the still; HeyGen animates it | Full — the source clip is already ours | Weakest — HeyGen decides framing/motion |
| **Cost** | Few Higgsfield credits | Higgsfield still + HeyGen render minutes | Higgsfield full clip + HeyGen sync minutes | HeyGen render minutes only |
| **Speed** | ~2–4 min | ~few min | ~few min per fix | ~few min |
| **When to pick** | Default for volume, brand-owned content, lead-magnet demos | **New default premium** — best brand + best sync in one shot | You already burned Higgsfield credits on a clip you like otherwise; fix the mouth | High-volume utility clips where brand-perfect framing doesn't matter |

## One-time HeyGen setup (do this before first HeyGen-mode run)
Run once, save the returned IDs back into this file's **Locked IDs** table below.

1. **Photo avatar** (needed for `heygen-native`; optional for other modes) — upload the face reference and register it:
   - `create_asset_upload` for `avatar-oloye-office.jpg` → get `asset_id` + presigned `upload_url`. PUT the bytes. Call `complete_asset_upload`.
   - `create_photo_avatar` with `{file: {type: 'asset_id', asset_id: <that>}, name: 'Oloye-1'}`. Poll with `list_avatar_looks(ownership='private')` until it appears with a **look id**. That look id is `avatar_id` for `create_video_from_avatar`.
2. **HeyGen voice clone** (optional; only for `heygen-native` if the Higgsfield Vibe-Voice mismatch bothers us):
   - Prepare a clean 60–90s audio sample of Oloye speaking, upload via `create_asset_upload` → `complete_asset_upload`.
   - `clone_voice` with the asset id. Poll `list_voices(type='private')` for the new voice.
3. **Save the IDs** to the **Locked IDs** section below so future runs skip discovery.

## Locked IDs
Update after one-time setup runs. These IDs are **account-specific** (they belong to Oloye's HeyGen and Higgsfield accounts). A new user runs the one-time HeyGen setup above plus Higgsfield `create_voice` to mint their own IDs, then replaces this table with them.

| Field | Value |
|---|---|
| HeyGen `avatar_id` (Oloye-1 photo avatar look id) | `941b12d8883c4348afbc179e22e522a0` |
| HeyGen `avatar_group_id` (Oloye-1 group) | `3f935ac8fff34d618a5488af2d922bfc` |
| HeyGen supported engines for Oloye-1 | `avatar_iv`, `avatar_iii` |
| HeyGen `voice_id` (Oloye voice clone) | _tbd — needs a 60-90s clean audio sample_ |
| Higgsfield `voice_id` (Oloye-1, Vibe Voice) | `c64e0a60-2964-4335-adee-50dd2d159ecf` |
| Higgsfield face reference path | `Business/90-Day Awareness Campaign/brand/avatar-oloye-office.jpg` (relative to the workspace root, see Paths) |

**No HeyGen voice yet:** while the HeyGen `voice_id` row above is tbd, `heygen-native` mode MUST use the `audioAssetId` path (generate the voiceover audio externally, e.g. ElevenLabs or Higgsfield Vibe Voice, upload it as a HeyGen asset, and pass `audioAssetId`). Never call `create_video_from_avatar` with `script` + `voiceId` until a real HeyGen voice clone exists.

## Brand rules (always)
- **Subtle Signal-Lime (`#C6F23C`) rim light** on one side of the face/shoulder, every studio.
- **"Oloye." watermark** bottom-right on the final video (overlay `Business/ai-team/brand/wordmark-overlay.png`, relative to the workspace root, see Paths).
- **9:16 vertical**, photoreal, "real photography, not CGI / not 3D".
- **Lock identity:** keep facial structure, skin tone, hairline, beard, age and proportions from the reference.
- No em dashes in any on-screen text or caption. Result-led (`oloye-voice` skill).

## Pipeline — full-higgsfield (default, 5 steps)
1. **Compose the image prompt** = `[studio background seed]` + identity-lock directive + brand layer (lime rim, 9:16, photoreal, natural hands if hands are in frame).
2. **Generate the scene:** `generate_image` model `nano_banana_pro`, `aspect_ratio 9:16`, `medias:[{role:image, value:<face media_id>}]`. Poll `job_status sync`. Eyeball it (clean eyes, real hands, likeness). Regenerate if off.
3. **Generate the voiceover:** `generate_audio` model `text2speech_v2_vibe_voice`, `voice_type element`, `voice_id c64e0a60-...`, `prompt = the script`. (Keep under ~12s per take; Vibe Voice can drift on longer.)
4. **Animate + lip-sync:** `generate_video` model **`wan2_7`**, `aspect_ratio 9:16`, `medias:[{role:start_image, value:<image job id>}, {role:audio, value:<VO job id>}]`. Wan embeds synced audio.
5. **Watermark + save:** download mp4 → **Brand-layer ffmpeg** → save under `Business/90-Day Awareness Campaign/talking-heads/<slug>/` (relative to the workspace root, see Paths).

## Pipeline — hybrid-image (new default premium, 6 steps)
Keep our studio scene + voice; hand animation + sync to HeyGen. Best sync + best brand control in one shot.

1. **Higgsfield still:** same as steps 1–2 of full-higgsfield → get a `nano_banana_pro` image job. Download the still to a local mp4-adjacent path OR grab its Higgsfield preview URL.
2. **Higgsfield voice:** same as step 3 of full-higgsfield → get a Vibe-Voice audio job. Download the audio file.
3. **Upload both to HeyGen:** for each (image, audio):
   - `create_asset_upload` with correct `contentType` (`image/jpeg` or `audio/mpeg` etc.) + `sizeBytes` → get `asset_id` + `upload_url`.
   - PUT the bytes to `upload_url` (`curl -X PUT -T <file> -H "Content-Type: <ct>" "<url>"`).
   - `complete_asset_upload(asset_id)`.
4. **HeyGen animate + sync:** `create_video_from_image`:
   ```
   {
     image: {type: 'asset_id', asset_id: <still asset>},
     audioAssetId: <audio asset>,
     aspectRatio: '9:16',
     resolution: '720p',   // Plus plan cap; bump to '1080p' after upgrade
     fit: 'cover',
     motionPrompt: 'Natural talking-head delivery, gentle blinks, small confident head moves. No walking.',
     expressiveness: 'medium',
     title: 'clone-studio <slug>'
   }
   ```
5. **Poll:** `get_video(video_id)` until `status: completed`. Grab `video_url`. `curl` it locally.
6. **Watermark + save:** **Brand-layer ffmpeg** → save.

## Pipeline — hybrid-lipsync (fix the mouth on an existing Higgsfield clip, 4 steps)
Reach for this when you already ran full-higgsfield and the clip is good except the lip-sync.

1. **Locate assets:** your existing Higgsfield `wan2_7` mp4 (video) + the same Vibe-Voice audio you fed into it (or a freshly regenerated one).
2. **Upload to HeyGen:** two `create_asset_upload` → PUT → `complete_asset_upload` rounds (one for video, one for audio).
3. **Fix the sync:** `create_lipsync`:
   ```
   {
     video: {type: 'asset_id', asset_id: <video asset>},
     audio: {type: 'asset_id', asset_id: <audio asset>},
     mode: 'precision',
     keepTheSameFormat: true,
     title: 'clone-studio <slug> lipsync-fix'
   }
   ```
   Poll `get_lipsync(lipsync_id)` for `video_url`. `curl` it.
4. **Watermark + save:** **Brand-layer ffmpeg** → save. (The Higgsfield-generated studio + lime rim survive because we didn't regenerate the scene.)

## Pipeline — heygen-native (fastest, weakest brand, 3 steps)
Use only when brand-perfect studio framing doesn't matter and speed does.

1. **Prereq:** photo avatar registered (see **One-time HeyGen setup**) → `avatar_id` in Locked IDs. Voice: either HeyGen clone `voice_id`, or generate the Vibe-Voice audio on Higgsfield and upload as an asset first.
2. **HeyGen create:** `create_video_from_avatar`:
   ```
   {
     avatarId: <locked>,
     script: <text>,     // OR audioAssetId if using our Higgsfield voice
     voiceId: <heygen voice>,  // omit if using audioAssetId
     aspectRatio: '9:16',
     resolution: '720p',   // Plus plan cap; bump to '1080p' after upgrade
     motionPrompt: 'Natural conversational talking-head, warm confident delivery',
     background: {type: 'color', value: '#0a0a0a'},   // or an image asset
     title: 'clone-studio <slug> native'
   }
   ```
   Poll `get_video(video_id)` for `video_url`.
3. **Watermark + save:** **Brand-layer ffmpeg** → save.

## Brand-layer ffmpeg (all modes)
Overlay the wordmark bottom-right. The wordmark path is relative to the workspace root (see Paths); if running from another cwd, use the full path, e.g. `<workspace-root>/Business/ai-team/brand/wordmark-overlay.png`:
```
ffmpeg -y -i in.mp4 -i Business/ai-team/brand/wordmark-overlay.png -filter_complex "[1]scale=200:-1[wm];[0][wm]overlay=W-w-30:H-h-30" -c:a copy out.mp4
```
Scale ~26% of width; bump to ~280 for 1080-wide. In `heygen-native` also verify the lime rim is present — HeyGen's avatar engine may not honour a colour direction. If not, either accept it or re-shoot in `hybrid-image` where the lime rim is baked into the Higgsfield still.

## The studio library (our sets)
Each is a background seed; the brand layer (lime rim, 9:16, photoreal, identity-lock) is added on top every time.

| Studio | Vibe | Background seed prompt |
|---|---|---|
| **Dark Cinematic Desk** | moody authority (our hero look) | sitting at a wooden desk, dark low-key room, a warm lamp glowing behind, laptop on the desk, hands resting on the table |
| **Podcast Studio** | conversational, expert | seated behind a podcast mic, wooden slat acoustic wall softly lit, warm key light, blurred background |
| **Bright Creator Office** | approachable, daytime | modern bright office, window with soft daylight, desk, plants, monitor blurred behind |
| **Dark Recording Studio** | premium, intense | dark studio, acoustic foam wall, single soft key, deep shadows, cinematic |
| **Minimalist Seamless** | clean, timeless | plain dark charcoal seamless backdrop, soft studio key, nothing else |
| **Content-Creator Desk** | techy, in-the-build | desk with a monitor, subtle LED strips, tidy gear, soft bokeh |
| **Interview Room** | credible, broadcast | two-tone backdrop, soft three-point lighting, slightly off-centre framing |
| **Night Boardroom** | high-status | glass office at night, city lights bokeh behind, low warm light |

## Operational rules (credit-burners, learned the hard way)
Each of these cost a job the first time. Follow them.

1. **HeyGen Plus plan caps at 720p.** Any HeyGen call with `resolution: '1080p'` returns `RESOLUTION_NOT_ALLOWED` — 720p is the default for every mode until we upgrade.
2. **`wan2_7` defaults to 5 s.** Always pass `duration: <audio-seconds rounded up>` in the params. Without it, wan2_7 truncates an 8 s script to 5 s and it silently looks fine in the response.
3. **`create_lipsync` requires video ↔ audio within 15 % duration.** If Mode A is 5 s and audio is 8.5 s, Mode C fails. Regenerate Mode A at the right duration first, or trim the audio with `startTime`/`endTime`.
4. **HeyGen asset processing is async.** Passing `asset_id` in the same turn as `complete_asset_upload` can 404 with `asset_not_found`. Workaround: use the returned public `url` (immediately valid) as `{type: 'url', url: ...}` instead of `{type: 'asset_id', ...}` when firing a create call in the same turn as the upload.
5. **Higgsfield model IDs auto-alias.** `nano_banana_pro` → `nano_banana_2` server-side; both work. Don't be surprised by the response's `model` field.

## Length and quality notes
- **full-higgsfield:** Wan does ~8 to 15 s per clip (with explicit `duration`). For 30 to 60 s, generate 3 to 5 segments (same studio + face) and stitch with ffmpeg. Lip-sync varies shot to shot; generate 2 takes and pick.
- **hybrid-image:** HeyGen `create_video_from_image` handles longer takes cleanly; less need to segment. Set `motionPrompt` deliberately — the still is static so all motion comes from this string. Keep it small ("gentle blinks, small confident head moves"); big prompts produce jitter.
- **hybrid-lipsync:** Only re-syncs; doesn't regenerate motion. If the head barely moves in the source clip, mouth motion will look isolated. Use `mode: 'precision'`; skip `speed` unless proofing.
- **heygen-native:** Longest scripts, most consistent output, weakest brand alignment. Pair with a HeyGen `background` (image asset of a Higgsfield studio still) if you want to reclaim brand backdrop control.
- **Hands (Higgsfield still-gen only):** frame them only when the studio includes a desk; prompt "realistic natural hands" and regenerate if they look off.
- **Cost logging (every mode, non-negotiable):** log to the proof-numbers loop — mode, script length, wall-clock, Higgsfield credits, HeyGen render/sync minutes, take count, subjective sync score (1-5), subjective brand score (1-5). Two clips in each mode with the same script is enough to settle which mode earns which job.

## Export as a lead magnet (later)
The **studio library + the A/B prompt method** (background prompt, then subject-insert with identity-lock) is the giveaway — `full-higgsfield` mode only, because the prompt library is the transferable IP. To productise: run the `lead-magnet` skill on this, strip the Oloye-specific bits (voice id, watermark), keep the studio prompts + a plain how-to ("make your own AI clone studio in 3 steps"), title it as a promise, add the audit CTA.

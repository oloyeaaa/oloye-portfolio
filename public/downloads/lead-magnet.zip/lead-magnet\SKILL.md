---
name: lead-magnet
description: Turn any Oloye. IP (a skill, framework, checklist, or topic) into a branded, sendable lead magnet (a short PDF) in minutes, with a promo caption and a delivery method. Use when Oloye says "give away X", "make a lead magnet", "turn this into a freebie/download/guide/cheat sheet".
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, mcp__claude_ai_Airtable__create_records_for_table, mcp__claude_ai_Airtable__list_records_for_table
---

# Lead Magnet builder

Goal: turn "give away X" into a branded PDF a prospect actually wants, plus the caption to promote it and the way to deliver it. Fast, repeatable, on brand. This is how Oloye. IP becomes list-building fuel.

## When to use
"give away", "lead magnet", "freebie", "downloadable", "make X into a guide / cheat sheet / one-pager".

## Requirements
- **Node** with **`playwright-core`** and a Chromium build. `tools/render.cjs` reuses the Chromium already installed by Playwright; override the browser path with the `CHROME` env var if needed.
- **Internet at render time**: the template loads Google Fonts (Space Grotesk + Inter).
- The **`oloye-voice`** skill (all copy goes through it).
- **`~/.claude/skills/_shared/brain-content-loop.md`** for the Brain logging steps. If that file is absent, skip the logging steps and say so in the output.
- **Airtable MCP (optional)** for step 6 "Log to the Brain". If unavailable, use the manual fallback in step 6.

## Paths
All relative paths in this skill resolve from the Oloye-OS workspace root (on this machine `<workspace-root>`). That covers `tools/render.cjs`, the brand photo folder, and the output location below.

## Inputs (only ask if unclear)
- **Which IP or topic** (e.g. the launch-day checklist, the writing system, "the 5-minute AI audit").
- **ICP** (default: non-techy small-business owners).
- **The ONE outcome** the magnet delivers. The title is the promise, not the topic.

## Rules (non-negotiable, LOCKED for consistency)
- **Speak from the Brain.** Apply the Content Brain Loop (`~/.claude/skills/_shared/brain-content-loop.md`): read Active Lessons from the Lessons table and obey them (learning); the "Log to the Brain" step below is the memory half (Format=`lead magnet`). Only for Oloye. brand magnets, skip the log for client deliverables.
- Write all copy with the **`oloye-voice`** skill. **NO em dashes.** Result-led: time saved or money made.
- **Brand tokens only:** base `#0E0F12`, paper `#F5F6F7`, accent Signal Lime `#C6F23C`, fonts Space Grotesk + Inter, wordmark **"Oloye."** with the lime full stop. No tagline (the "AI Automation Guy" tagline is dropped).
- **Cover MUST carry a brand studio photo.** Copy one from `Business/90-Day Awareness Campaign/brand/` (dark studio shots like `talking-head-test/oloye-cinematic-desk.jpg` fade cleanly into the base) into the magnet folder as `cover.jpg`. Never ship a photo-less cover with empty space at the top.
- **Evidence rule:** nothing invented. Real, usable value only. If you cite a number it must be true and sourced.
- **CTA depends on the magnet's stage in the funnel (structure locked 2026-07-10):**
  - **Reach-stage magnet** (promoted ON the content itself): CTA = the comment keyword only, one pill,
    e.g. `Comment CLAUDE`. No links.
  - **Delivery-stage magnet** (the thing SENT after someone comments, e.g. a system blueprint): CTA =
    the stable product link `oloye.co.uk/get/<system>` (a site redirect Oloye controls; never a raw
    Gumroad/checkout URL in the PDF). The funnel: TOFU (Insta/networking/WhatsApp) → comment keyword →
    this PDF → /get/<system> → checkout. Every future system uses this same structure; redirects live
    in `Projects/oloye-portfolio/next.config.ts`.
- **ONE wordmark per page** (top-left only). No second/sign-off wordmark at the bottom of any page.
- **Genuinely useful and tight.** One value page if it can be. Never pad to look bigger.

## Process
1. **Scope it:** IP + ICP + ONE outcome. Write the one-line promise first.
2. **Pull the value** from the source IP file(s). Keep only what delivers the outcome. Cut the rest.
3. **Build the file:** copy `assets/template.html` into the output folder. **Also copy a brand studio photo into that folder as `cover.jpg`** (the cover renders it automatically). Fill the [BRACKETS]: cover (eyebrow + title + subtitle), one or more value pages, CTA page (comment keyword). Do not restyle it. Add a value page by duplicating a `.page.paper` block.
4. **Render** (run from the workspace root, or prefix `tools/render.cjs` with it):
   - PDF (the deliverable): `node tools/render.cjs "<path>/<slug>.html" "<path>/<slug>.pdf" --pdf`
   - PNG preview to check it: `node tools/render.cjs "<path>/<slug>.html" "<path>/<slug>.png" --full --width 800`
   - Read the PNG. Confirm it fits each A4 page, reads cleanly, and has zero em dashes.
5. **Promote + deliver:** write a short promo caption (oloye-voice) and pick ONE delivery method (below). State it.
6. **Log to the Brain:** add a row to Content (Title, Format=`lead magnet`, Owner=`<you>`, Status=`review`) and note the file path. If it becomes evergreen, add it to Reference too. **Fallback:** if the Airtable MCP is unavailable, output the Brain row as text (Title, Format, Owner, Status, file path) so Oloye can enter it manually, and say the log was not written.
7. **Output to Oloye:** the PDF path, the PNG preview, the caption, and the delivery method.

## Output location
`Business/90-Day Awareness Campaign/lead-magnets/<kebab-slug>/` (matches the existing `claude-command-cheatsheet` magnet).

## Template
`assets/template.html` is the branded A4 scaffold: **photo cover** (auto-loads `cover.jpg`), paper value pages, dark CTA (comment keyword). Duplicate and fill the [BRACKETS]. Keep the styling fixed for brand consistency. It is multi-page (each `.page` is one A4 sheet); add or remove value pages as the content needs. The locked rules are commented at the top of the file.

## Delivery options (pick one and say which)
- **Comment keyword auto-reply** (default, manual for now: send the PDF when someone comments the keyword on the reel).
- **Direct attach** in DMs or WhatsApp.
- When the email-nurture loop is built, the magnet becomes the opt-in that starts the sequence.

## Good lead-magnet checklist (before you ship)
- The title is a promise, not a topic.
- A stranger gets one real win in under 5 minutes of reading.
- It sounds like Oloye (voice profile), zero em dashes.
- Cover has a brand studio photo (no empty top space).
- CTA is the comment keyword only. No link. One wordmark per page.
- Branded: wordmark, lime accent, Space Grotesk. Looks premium.

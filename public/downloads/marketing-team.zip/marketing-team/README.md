# The Marketing Team

A working marketing department, installed inside Claude Code. One install gives your business a manager, a
content writer, an SEO blog writer, an outreach lead, and a weekly analytics review, all sharing one Brain so
corrections get remembered instead of repeated.

Works with Claude Code.

## What it does

- **Manager** - runs the daily brief and the standup, keeps you on your one focus, never invents a result.
- **Content** - turns one idea into a week of posts, reels, and long-form scripts in your own voice.
- **SEO writer** - researches a keyword and drafts a full blog post, ready to publish or paste in yourself.
- **Outreach** - finds real prospects, researches them, and drafts cold openers, draft-only, never sends.
- **Weekly review** - checks what's working and what to change, one lesson at a time.
- **The Brain** - one shared memory (local files or your own Airtable base) that every part of the team reads
  and writes, so a correction today changes what happens next week.

## Module map

| Module | What it gives you | Main commands |
|---|---|---|
| Manager | The install wizard, the daily brief, the standup pipeline | `/marketing-team:setup`, `/marketing-team:daily-brief`, `/marketing-team:standup` |
| Content | A week of posts, reel scripts, long-form scripts, product ads, motion design, lead magnets | `/marketing-team:reel` (plus skills used inside the standup) |
| SEO writer | Blog drafts, publishing, lesson capture, quality checks | `/marketing-team:blog-draft`, `/marketing-team:post-blog`, `/marketing-team:kill-draft`, `/marketing-team:lesson`, `/marketing-team:eval-writer` |
| Outreach | Prospect research and cold openers (draft-only) | run inside `/marketing-team:standup`, or on its own via the outreach skill |
| Analytics | A weekly Keep / Change / Try review | `/marketing-team:weekly-review` |
| Brain | Shared memory setup (local or your own Airtable base) | `/marketing-team:setup-brain` |

## One-hour quickstart

1. **Install.** See `docs/SETUP.md` for the exact install path (marketplace once published, or a local/zip
   install with `claude --plugin-dir <folder>`).
2. **Run `/marketing-team:setup`.** About 20-30 minutes. It asks about your business, learns how you actually
   sound from a few real samples (or a quick set of questions if you don't have any), and writes your config.
3. **Get your first week of posts.** The wizard can generate one straight away, or run it any time with the
   week-of-posts skill through `/marketing-team:standup`.

After that, run `/marketing-team:daily-brief` each morning and `/marketing-team:standup` or
`/marketing-team:weekly-review` through the week. See `docs/manager.md` for the daily and weekly routine.

## Requirements

- **Claude Code**, with your own subscription. Everything runs inside it.
- **Python and ffmpeg** are only needed for the video skills (reel and long-form video pipelines). Every other
  module runs with nothing extra installed.
- **Optional connections**, only if you want them: Airtable (for the Brain), Metricool (for scheduling),
  Google Calendar / Drive / Gmail (for the daily brief and outreach drafts), fal.ai and Higgsfield (for image
  and video generation). Nothing breaks if these aren't connected, the affected step just says so and skips.

## Command list

All commands use the `/marketing-team:` prefix.

- `/marketing-team:setup` - the install wizard
- `/marketing-team:setup-brain` - create or adopt the shared Brain
- `/marketing-team:daily-brief` - a short daily brief
- `/marketing-team:standup` - the day's content, blog, and outreach pipeline
- `/marketing-team:weekly-review` - the weekly Keep / Change / Try review
- `/marketing-team:reel` - turn a proven reel into your own version
- `/marketing-team:blog-draft` - research and draft a blog post
- `/marketing-team:post-blog` - publish a drafted post
- `/marketing-team:kill-draft` - drop a draft and log why
- `/marketing-team:lesson` - teach the writer a rule by hand
- `/marketing-team:eval-writer` - regression-check the SEO writer

## Where everything lives

Your settings, voice profile, and Brain all live outside the plugin, under `~/.claude/marketing-team/`, so
they're yours and they survive plugin updates. Full detail in `docs/SETUP.md`.

## Licence

See `docs/LICENSE.md`.

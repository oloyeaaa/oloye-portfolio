---
description: Research a keyword, draft the blog post via the SEO writer agent, optionally generate a cover image and push to the site, and save it for review.
argument-hint: "[--business <slug>] <target keyword>"
allowed-tools: Bash, Read, Write, Grep, Glob
---

# /marketing-team:blog-draft - draft a new SEO blog post

Arguments: **$ARGUMENTS**

## Step 0: Resolve the business

Parse `--business <slug>` from the arguments if present. Everything else is the target keyword. If no
`--business` flag, read `defaultBusiness` from `~/.claude/marketing-team/config.json`. Load
`~/.claude/marketing-team/businesses/<slug>.json`. If that file is missing, tell the user to run
`/marketing-team:setup` and stop. From here on, every reference to "the config" means this resolved JSON
object. Nothing below should use a literal base ID, table ID, field ID, repo path, or domain, all of it comes
from the config.

## Step 0.5: Check for an unresolved regression (safety gate)

Before doing any research or drafting, check the Brain Lessons table (contract at
`${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`, mode from `config.brain.mode`) for an **Active** row whose
Rule starts with `REGRESSION:` and whose Area is `seo`.

- If one exists: **stop immediately.** Tell the user: "The last eval run flagged a regression that hasn't been
  cleared. Run `/marketing-team:eval-writer` to check whether it's fixed, it clears the flag automatically on
  a clean pass." Do not draft.
- If none exists, proceed.

## Steps

1. **Resolve the keyword.** A keyword argument is required in v1 (no keyword backlog table yet). If no keyword
   was passed after stripping `--business <slug>`, tell the user a keyword is required and stop.

2. **Duplicate check.** If `config.site.enabled` is true and a repo is configured, or if local blog drafts
   exist at `~/.claude/marketing-team/brain/<slug>/blog/`, do a quick scan for an existing file whose slug or
   title substring-matches the target keyword. If a match exists, tell the user there's an existing post and
   stop.

3. **Optional SERP research.** If a web-search tool is available (a Firecrawl MCP tool, or WebSearch), search
   the exact keyword, limit 5, source web. For each result note: URL, title, one-line description. Summarise
   in 3 bullets: what the top 5 cover, what they miss, angle the writer should take. If no such tool is
   available, skip this step and note in your final report that research was skipped.

4. **Read active lessons.** Per the Brain contract, read Lessons rows where Active = true and Area is `seo` or
   `general`. Collect each into a plain bullet list. Empty is fine, that just means no lessons block gets
   passed to the writer.

5. **Read the voice profile.** Read `~/.claude/marketing-team/businesses/<slug>.voice.md` if it exists (path
   from `config.voice.profilePath`, resolved relative to the business's folder). If it doesn't exist, proceed
   without it, the writer falls back to `config.brand` alone.

6. **Invoke the seo-writer subagent** (via the Agent tool, `subagent_type: seo-writer`). Brief it with:

   ```
   Business: <config.displayName>
   Language: <config.language>
   Brand: <config.brand as relevant fields: oneLiner, productName, audience, tone, bannedWords, signaturePhrases, cta>
   SEO settings: <config.seo: pillarPath, ctaPath, categories, jargonBanlist>
   Voice profile: <contents of the voice.md file, or "none on file yet">

   Primary keyword: <keyword>

   SERP research (top 5): <as gathered in step 3, or "not available this run">

   What they cover: <summary, if research ran>
   What they miss: <angle, if research ran>

   Active lessons (apply these as hard constraints):
   - <lesson 1>
   - <lesson 2>
   (omit this section entirely if step 4 returned nothing)

   Draft the post. Return only the JSON block per your output format.
   ```

7. **Parse the writer's JSON.** Validate title, slug, body, seoTitle, metaDescription, keywords, category,
   primaryKeyword all exist and are the right shape. If invalid, tell the user and stop.

8. **If `config.site.enabled` is false (the default):**
   - Write the draft to `~/.claude/marketing-team/brain/<slug>/blog/<slug>.md` with frontmatter built from the
     JSON (title, slug, excerpt, seoTitle, metaDescription, keywords, category, primaryKeyword,
     readTimeMinutes, status: review, created: today's date), followed by the body markdown.
   - Log one Brain Content row: Title = the draft title, Type = `blog`, Status = `review`, Body = the excerpt
     (or a short pointer to the file path), Source URL = blank, Created = today.
   - Skip the cover image and git steps entirely.

9. **If `config.site.enabled` is true:**
   - **Cover image (optional):** only run this if the render-room skill is configured with a fal key for this
     business. If it isn't, skip with a note in the final report, don't fail the draft over a missing image.
     If it is configured, craft a prompt from the post's central idea (60-100 words, no hex colour codes,
     16:9) and generate one image via the render-room skill, following that skill's own instructions.
   - Copy the generated image (if any) into `<config.site.repoPath>/<config.site.imagesBlogPath>/<slug>.png`.
   - **Write the draft file** into the repo at a sensible location for the site's blog content (or, if the
     site has no separate content pipeline, write the markdown next to the images path convention used by
     `config.site.imagesBlogPath`). Use the same frontmatter shape as step 8.
   - **Commit and push:**
     ```
     cd "<config.site.repoPath>" && \
       git add -A && \
       git commit -m "Add draft: <slug>" && \
       git push <config.site.gitRemote> <config.site.gitBranch>
     ```
   - Log one Brain Content row: Title = the draft title, Type = `blog`, Status = `review`, Body = the excerpt,
     Source URL = `<config.site.domain><config.site.blogBasePath>/<slug>` (once live), Created = today.

10. **Report** to the user, tight, one screen:
    - Business (only mention if not the default, to avoid noise on the common path)
    - Where the draft landed: local file path, or repo path + pending live URL
    - Title, primary keyword, category, word count estimate
    - How many active lessons were applied
    - Whether SERP research ran, and whether a cover image was generated
    - Next steps: `/marketing-team:post-blog` to publish, `/marketing-team:kill-draft` to bin it.

## Do not

- Do not mark the draft as posted. Only `/marketing-team:post-blog` does that.
- Do not invent stats in the draft.
- Do not fail the whole draft because a cover image couldn't be generated. Skip it and say so.
- Do not hardcode a base ID, table ID, field ID, repo path, or domain anywhere in this flow. If you find
  yourself typing a literal ID, stop, that value should be coming from the resolved business config.

---
description: A short daily brief - today's calendar (if connected), what needs attention, what's waiting, and tomorrow's shape.
---

# /marketing-team:daily-brief

Compile one short brief for the buyer. Plain language, numbers first, no em dashes, no fluff. This command
runs when the buyer runs it; it does not run itself in the background.

## Step 0 - tenant resolution

Parse `--business <slug>` from arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the buyer to run `/marketing-team:setup` first and stop.

## 1. Gather (read-only, never invent a value)

a. **Brain Tasks** (open, i.e. `Status` not `done`). Read via
   `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md` (local `tasks.md` or the buyer's Airtable Tasks table,
   whichever `config.brain.mode` is set to). Note Task, Area, Due.

b. **Active Lessons count**: same source, count rows where `Active` = true. Just the number, not the full
   list, this is a quick pulse check, not the standup's deep pass.

c. **Yesterday's Content rows**: rows from the Content table/file with `Created` = yesterday's date. Note
   Title, Type, Status.

d. **Google Calendar (optional)**: if a Google Calendar MCP is connected, list today's and tomorrow's events.
   If it's not connected, skip this section entirely, don't mention it as missing, it's optional.

If any source is unreachable, say so in one line inside the brief and continue with what you do have. Never
invent a task, an event, or a number.

## 2. Compose the brief

One message, under 200 words, numbers first, plain language, no em dashes:

```
Daily brief: <Day DD Mon>

Today's calendar:
- <HH:MM> <event> (<duration>)
(only if Calendar is connected; omit this block entirely if not)

Needs to move today (1-3 items, tied to <config.brand.oneLiner> / the business's stated focus; if there are
genuinely none, say "Nothing urgent today." and suggest the single most useful next step instead):
1. <item>
2. <item>

Waiting on:
- <open Tasks that are blocking something, or "Nothing waiting.">

Yesterday: <N pieces of content produced, listed briefly, or "Nothing logged yesterday.">

Active lessons: <N> rules the team is applying right now.

Tomorrow's shape: <one line, from tomorrow's calendar if connected, otherwise from open Tasks due tomorrow>
```

Use `config.team.manager` if set (otherwise "the manager") if the brief refers to itself in the first person
at all; keep that to a minimum, this is a report, not a chat.

## 3. Optionally write one Tasks row

If anything in "Needs to move today" is not already an open Task, offer to add it as one. Only write if the
buyer says yes. Use `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md` to log it (Task, Area = `general`,
Status = `todo`, Due, Notes).

## 4. Automation note (only if asked)

This command runs when the buyer runs it, it is not automatic. If the buyer wants it to run on its own every
morning, point them to `${CLAUDE_PLUGIN_ROOT}/docs/manager.md`, which explains wiring it to their own
scheduler (Windows Task Scheduler, cron, or a Claude Code scheduled run). Don't volunteer this unless asked or
unless it clearly comes up.

---
description: Check this machine for the optional tools the media skills need (Python, ffmpeg, Node), and report which features will work and how to unlock the rest. The core marketing team always works.
---

# /marketing-team:doctor

A read-only health check. It tells the buyer which parts of the plugin will work on THIS machine and,
for anything missing, exactly how to fix it. It installs nothing on its own. Plain language, numbers first,
no em dashes, no fluff.

Lead with the honest headline: **the core marketing team needs no tools and always works.** This check is only
about the optional media-generation skills, which shell out to external tools.

## 1. Detect the OS

Work out whether this is Windows, macOS, or Linux (uname / platform). You will tailor the install hints to it.

## 2. Probe for each tool (read-only)

Run these and record present/absent plus the version if present. Adapt the command to the OS if needed
(`command -v` on macOS/Linux/Git Bash; `where` on Windows cmd):

- **Python:** `python --version` or `python3 --version`
- **ffmpeg:** `ffmpeg -version` (first line only)
- **Node.js:** `node --version`
- **A fal.ai key** (for the paid render skills): is `FAL_KEY` set in the environment, or present in
  `${CLAUDE_PLUGIN_ROOT}/skills/render-room/.env`? Report present/absent only, NEVER print the key value.

Do not install anything in this step. This is diagnosis only.

## 3. Report the feature table

Map the results to features and show this table, marking each ✅ works / ⚠️ needs a tool / 💷 needs a paid key:

| Feature | Needs | Status on this machine |
|---|---|---|
| Core team (manager, content, blog writing, outreach, analytics, Brain, lessons) | nothing | ✅ always works |
| `/marketing-team:reel` (transcribe a reel) | Python + ffmpeg | based on the probes |
| render-room / product-ad (AI image and video) | Python + ffmpeg + a fal.ai key (paid) | based on the probes |
| screen-to-reel (b-roll editing) | bash + ffmpeg (Unix or Git Bash) | based on the probes |
| lead-magnet PDF render | Node.js | based on the probes |
| youtube-pipeline | Python + ffmpeg | based on the probes |

Note for the reel command: its Python libraries (yt-dlp, faster-whisper) install themselves automatically on
first run, so the buyer only needs **Python and ffmpeg** present. ffmpeg cannot install itself.

## 4. Install hints for anything missing (tailored to the OS)

Only show the lines for tools that are actually missing.

- **ffmpeg** - Windows: `winget install Gyan.FFmpeg` (or `choco install ffmpeg`); macOS: `brew install ffmpeg`;
  Linux: `sudo apt install ffmpeg`. Then reopen the app so it is on PATH.
- **Python** - Windows: `winget install Python.Python.3.12` (or python.org installer); macOS: `brew install python`;
  Linux: usually preinstalled, else `sudo apt install python3 python3-pip`.
- **Node.js** - Windows: `winget install OpenJS.NodeJS`; macOS: `brew install node`; else nodejs.org.
- **fal.ai key** - only if they want the AI image/video skills. Sign up at fal.ai, create a key, and add it as
  `FAL_KEY` (this is a paid, pay-per-use service). Point them to `skills/render-room/SKILL.md`.

## 5. The bottom line (say this plainly)

- If Python and ffmpeg are present: "The full plugin works on this machine."
- If they are missing: "Your core marketing team works today. The media skills (reels, AI image/video,
  b-roll, PDF magnets) need the tools above first. None of that blocks the writing, blog, outreach, analytics
  or Brain."

Never overstate. If a tool is missing, the feature it powers does not work until it is installed, full stop.

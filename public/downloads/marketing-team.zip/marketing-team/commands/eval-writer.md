---
description: Regression check for the SEO writer agent. Runs it against the business's fixed eval keyword set and scores every draft against the tenant's own rules.
argument-hint: "[--business <slug>] [what changed, e.g. 'loosened the em dash rule']"
allowed-tools: Bash, Read, Write
---

# /marketing-team:eval-writer - regression check for the SEO writer

Arguments: **$ARGUMENTS**

This is a **dry run**. No web search, no image generation, no git push, no draft saved for review. It only
tests whether the writer agent's current rules still produce compliant drafts against this business's own
config.

## Step 0: Resolve the business

Parse `--business <slug>` from the arguments if present. Everything else is a free-text note on what changed.
If no `--business` flag, read `defaultBusiness` from `~/.claude/marketing-team/config.json`. Load
`~/.claude/marketing-team/businesses/<slug>.json`. If that file is missing, tell the user to run
`/marketing-team:setup` and stop.

If `config.seo.evalKeywords` is missing or empty, tell the user this business has no eval keyword set defined
yet (add a handful of representative keywords to `config.seo.evalKeywords` in the tenant config) and stop. A
fixed eval set has to be chosen deliberately, not invented on the fly.

## Steps

1. **Read active Lessons** (Area = `seo` plus `general`), per the Brain contract
   (`${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`). Same as real `/marketing-team:blog-draft`, so the eval
   tests what production actually sees.

2. **Fetch the baseline score.** History lives at `~/.claude/marketing-team/brain/<slug>/eval-history.md`, a
   simple markdown table (create it with a header row if it doesn't exist yet):

   ```
   | Run Date | Passed | Total | Notes |
   |---|---|---|---|
   | 2026-01-01 | 58 | 60 | first baseline |
   ```

   Read the last row as the baseline. If the file doesn't exist or has no rows yet, this run becomes the
   baseline (no comparison, no regression flag).

3. **Invoke the seo-writer subagent once per keyword in `config.seo.evalKeywords`, in parallel** (via the Agent
   tool, `subagent_type: seo-writer`, all in a single message so they run concurrently). Brief each one:

   ```
   Business: <config.displayName>
   Language: <config.language>
   Brand: <config.brand as relevant fields>
   SEO settings: <config.seo: pillarPath, ctaPath, categories, jargonBanlist>
   Voice profile: <contents of the voice.md file, or "none on file yet">

   Primary keyword: <eval keyword>

   No SERP research was run for this evaluation. Draft using your own knowledge of the topic, this run tests
   your drafting rules, not your research.

   Active lessons (apply these as hard constraints):
   - <lesson 1>
   - <lesson 2>
   (omit this section entirely if step 1 returned nothing)

   Draft the post. Return only the JSON block per your output format.
   ```

4. **Score each draft.** For each returned JSON block, write it to a temp file, then run:

   ```
   python "${CLAUDE_PLUGIN_ROOT}/skills/seo-writer/scripts/eval_blog_draft.py" "<draft.json>" "<tenant-config.json>"
   ```

   where `<tenant-config.json>` is the resolved path `~/.claude/marketing-team/businesses/<slug>.json`. Parse
   the `@@EVAL_JSON@@` line. Collect passed/total and the list of failed check names for that keyword.

5. **Aggregate.** Sum passed and total across all drafts. Build a "Failed checks" list formatted as
   `<eval keyword>: <check name> (<detail>)`, one line per failure. If a draft's `ok` came back `false`, treat
   every check for that draft as failed and note the parse error.

6. **Compare to baseline.**
   - If no baseline existed, skip comparison.
   - Otherwise compare this run's passed/total fraction to the baseline's. If this run's fraction is lower,
     mark this run as a regression.

7. **Append one row to `eval-history.md`**: Run Date = today, Passed, Total, Notes = the `$ARGUMENTS` text
   (what changed) plus a one-line recommendation.

8. **On a regression:** write one Active Lessons row, Area = `seo`, Rule = `REGRESSION: <one-line summary of
   what got worse>`, Source = `performance`, Added = today. This is the row `/marketing-team:blog-draft`'s
   Step 0.5 checks for and refuses to run while it's Active.

9. **On a clean pass:** if an Active Lessons row exists with Area = `seo` and Rule starting `REGRESSION:`,
   deactivate it (set Active = false, or delete it depending on the Brain mode).

10. **Report** to the user, tight:
    - Score as a fraction and percentage
    - Comparison to baseline (or "this is the new baseline")
    - Every failed check, grouped by eval keyword, in plain English
    - One clear recommendation: **safe to keep the change** / **regression, do not run blog-draft until fixed**
      / **first baseline established**
    - If a regression was flagged, remind the user `/marketing-team:blog-draft` will refuse to run until a
      clean `/marketing-team:eval-writer` pass clears it.

## Do not

- Do not save any draft for review, or touch the real Content log. This is a dry run.
- Do not change a business's eval keywords casually. If the user asks to change them, do it in the tenant
  config and note it clearly in the next run's Notes field so the score isn't compared across incompatible
  eval sets.
- Do not silently round up a regression to "probably fine". If this run scored lower than baseline, say so
  plainly and name the specific checks that got worse.
- Do not hardcode a base ID, table ID, or field ID. All of it comes from the resolved business config.

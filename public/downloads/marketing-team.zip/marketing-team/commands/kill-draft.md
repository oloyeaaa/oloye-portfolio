---
description: Kill a review-status blog draft, remove its cover image if any, and log the reason as a lesson.
argument-hint: "[--business <slug>] [slug]"
allowed-tools: Bash, Read
---

# /marketing-team:kill-draft - delete a draft blog post

Arguments: **$ARGUMENTS**

## Step 0: Resolve the business

Parse `--business <slug>` from the arguments if present. Everything else is an optional post slug. If no
`--business` flag, read `defaultBusiness` from `~/.claude/marketing-team/config.json`. Load
`~/.claude/marketing-team/businesses/<slug>.json`. If that file is missing, tell the user to run
`/marketing-team:setup` and stop.

## Steps

1. **Find the target draft.** Per the Brain contract, find the Content row with Type = `blog` and Status =
   `review`, matching the given slug if one was passed, otherwise the most recently created one. If nothing is
   found, tell the user and stop.

2. **Show the user the row**: Title, slug, and a short excerpt. Ask: **"why kill it?"** (one line, so patterns
   emerge).

3. **Confirm.** Ask: "Delete this draft and its cover image?" Wait for a clear yes.

4. **Delete the local draft file.**
   - If `config.site.enabled` is false: delete `~/.claude/marketing-team/brain/<slug>/blog/<slug>.md`.
   - If `config.site.enabled` is true: remove the draft file from the repo, and remove the cover image if one
     exists at `<config.site.repoPath>/<config.site.imagesBlogPath>/<slug>.png`:
     ```
     cd "<config.site.repoPath>" && \
       rm -f "<config.site.imagesBlogPath>/<slug>.png" "<draft file path>" && \
       git add -A && \
       git commit -m "Remove killed draft: <slug>" && \
       git push <config.site.gitRemote> <config.site.gitBranch>
     ```
     If nothing was tracked in git yet (draft never pushed), skip the git steps.

5. **Mark the Content row.** Either delete the row or set Status to `killed`, whichever the Brain mode
   supports more cleanly (local markdown: delete the row; Airtable: delete the record, since `killed` isn't in
   the schema's Status enum).

6. **Write ONE Lessons row** (if a reason was given): per the Brain contract, Area = `seo`, Source = `kill
   reason`, Active = true, Added = today. Rewrite the raw reason as a short imperative rule under 100
   characters, specific and actionable, not a restatement of the complaint. Example: "the opening was weak"
   becomes "Don't open with a rhetorical question." If no reason was given, skip this step, don't invent one.

7. **Report**: draft deleted, image removed (if any), and the lesson saved verbatim so the user can confirm it
   was captured correctly.

## Do not

- Do not kill a `posted` draft. Only `review` status.
- Do not skip the "why" question. It's how the lesson gets captured at all.
- Do not delete the image without also removing the Content row.
- Do not write a vague or restated-complaint lesson. Rewrite it as a rule the next draft can actually follow.
- Do not hardcode a base ID, table ID, field ID, or repo path. All of it comes from the resolved business
  config.

---
description: Teach any module a rule directly, without waiting for a kill or a correction to trigger it.
argument-hint: "[--business <slug>] [--area content|seo|outreach|analytics|general] <the lesson, in plain English>"
allowed-tools: Read
---

# /marketing-team:lesson - teach the team something directly

Arguments: **$ARGUMENTS**

## Step 0: Resolve the business

Parse `--business <slug>` from the arguments if present. If no `--business` flag, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file is
missing, tell the user to run `/marketing-team:setup` and stop.

## Steps

1. **Parse `--area <content|seo|outreach|analytics|general>`** from the remaining arguments. Default to
   `general` if not passed. Everything left after removing `--business` and `--area` is the lesson text. If no
   lesson text was passed, ask the user for it and stop. Do not invent one.

2. **Rewrite the input as a short imperative rule** if it isn't already one. "The last post felt too salesy"
   becomes "Don't push the CTA more than once per piece." Keep it under 100 characters where possible.

3. **Check for a near-duplicate.** Read the existing Active Lessons rows for this Area (plus `general`) per
   the Brain contract (`${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`). If one already says roughly the
   same thing, tell the user instead of creating a second row.

4. **Write the Lessons row**: Rule = the rewritten imperative rule, Area = the parsed area, Active = true,
   Source = `manual`, Added = today's date.

5. **Report**: show the exact rule saved, so the user can confirm it was captured the way they meant it. If the
   rewrite changed the meaning, say so and ask if it's right.

## Do not

- Do not soften or generalise the lesson so much it loses the actual instruction.
- Do not create a duplicate of an existing active lesson for the same area.
- Do not hardcode a base ID, table ID, or field ID. All of it comes from the resolved business config.

---
description: Flip a review-status blog draft to posted, and report where it now lives.
argument-hint: "[--business <slug>] [slug]"
allowed-tools: Bash, Read
---

# /marketing-team:post-blog - publish a draft blog post

Arguments: **$ARGUMENTS**

## Step 0: Resolve the business

Parse `--business <slug>` from the arguments if present. Everything else is an optional post slug. If no
`--business` flag, read `defaultBusiness` from `~/.claude/marketing-team/config.json`. Load
`~/.claude/marketing-team/businesses/<slug>.json`. If that file is missing, tell the user to run
`/marketing-team:setup` and stop.

## Steps

1. **Find the target draft.** Per the Brain contract (`${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`), find
   the Content row with Type = `blog` and Status = `review`, matching the given slug if one was passed,
   otherwise the most recently created one. If nothing is found, tell the user and stop.

2. **Show the user the row**: Title, and where the draft file lives (local path, or repo path).

3. **Confirm.** Ask explicitly: "Publish this?" Wait for a clear yes before doing anything else.

4. **If `config.site.enabled` is true:**
   - Confirm the draft file is committed and pushed (it should already be, from `/marketing-team:blog-draft`).
     If it isn't, commit and push it now the same way that command does.
   - Update the Brain Content row: Status = `posted`.
   - Report the live URL: `<config.site.domain><config.site.blogBasePath>/<slug>`.
   - Be honest: this plugin does not deploy or host the buyer's site. Remind them their site build needs to
     read published content from wherever they host it (their own git repo, CMS, or static build pipeline).
     Flipping this status only marks the piece as ready and logs it, it does not trigger a deploy.

5. **If `config.site.enabled` is false:**
   - Update the Brain Content row: Status = `posted`.
   - Tell the user where the markdown file lives:
     `~/.claude/marketing-team/brain/<slug>/blog/<slug>.md`, so they can copy it wherever they publish.

## Do not

- Do not flip the status without an explicit yes.
- Do not touch any field beyond Status (and, where relevant, a Published Date if the Brain mode supports one).
- Do not claim the plugin deployed or published the site. It only marks the content ready and tells the user
  where it lives.
- Do not hardcode a base ID, table ID, field ID, repo path, or domain. All of it comes from the resolved
  business config.

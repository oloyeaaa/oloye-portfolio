---
description: Transcribe an Instagram reel (or video URL) and explain what's being taught, saved as a markdown note
argument-hint: <reel-or-video-url>
---

The user wants to transcribe and understand this reel or video: $ARGUMENTS

This command does not use any brand or tenant config values (no tenant resolution needed); it only reads a
public URL and writes a local note.

Do the following:

1. Run the transcription script (audio download + Whisper transcription):

   ```
   python "${CLAUDE_PLUGIN_ROOT}/skills/reel-pipeline/scripts/reel_transcribe.py" "$ARGUMENTS"
   ```

   Use a generous timeout (e.g. 600000ms) - the first run downloads the Whisper
   model, and transcription on CPU takes time.

2. The script prints a JSON object on a line prefixed with `@@REEL_JSON@@`. Parse it.
   - If `ok` is false: tell the user what failed. If there's a `hint` about login,
     suggest re-running the script with `--cookies-from-browser chrome` (or edge/
     firefox) appended, and confirm they're logged into Instagram in that browser.
     Do NOT add cookies automatically - ask first.

3. On success, read the `transcript` and write a markdown note to a
   `reel-notes/` folder in the current working directory (create it if missing).
   Name the file with a short kebab-case slug derived from the title or topic, e.g.
   `reel-notes/meal-prep-protein-tips.md`. The note must contain:

   ```markdown
   # <concise title of what the reel teaches>

   - **Source:** <url>
   - **Creator:** <uploader>
   - **Duration:** <duration in m:ss>
   - **Transcribed:** <today's date>

   ## What's being taught
   <2-4 sentence plain summary of the core lesson / takeaway>

   ## Key points
   - <the actionable points, steps, or claims, in order>

   ## Full transcript
   > <the raw transcript>
   ```

4. After writing, show the user the summary + key points inline in chat, and tell
   them where the note was saved. Keep it tight, no filler.

---
description: Create or adopt the shared Brain for a business (local markdown files or the buyer's own Airtable base).
---

# /marketing-team:setup-brain

Set up the Brain for one business: the shared memory that every module in The Marketing Team reads and writes.
Full contract: `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`.

## Step 0 - tenant resolution

Parse `--business <slug>` from arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the user to run `/marketing-team:setup` first and stop. Never type a literal ID or brand
value; everything comes from this config.

## Step 1 - create or adopt

If `config.brain.mode` is already set and the Brain for this slug already exists (local files present, or
`config.brain.airtable.baseId` set), tell the user what is already configured and ask if they want to
reinitialise or leave it alone. Do not overwrite existing data without confirmation.

Otherwise ask the buyer one question: **local or Airtable?**

- Local: zero setup, works immediately, good default for most buyers.
- Airtable: their own base, useful if they already live in Airtable or want to view the Brain outside Claude
  Code. Requires the Airtable MCP to be connected.

## Step 2a - local mode

1. Create `~/.claude/marketing-team/brain/<slug>/` if it does not exist.
2. Copy every file from `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/templates/` into that folder:
   `content-log.md`, `lessons.md`, `posts.md`, `leads.md`, `tasks.md`.
3. Create an empty `blog/` subfolder (used when `config.site.enabled` is false).
4. Set `config.brain.mode = "local"` and `config.brain.localPath = "brain"`.

## Step 2b - airtable mode

1. Check that an Airtable MCP is connected (a tool like `create_base` is available). If it is not connected,
   tell the buyer plainly that Airtable is not connected, and fall back to Step 2a (local mode) instead.
2. Create a new base named `<displayName> Brain` using `create_base`. Never reference or reuse any existing
   base.
3. Create the five tables with `create_table`, matching the schema in
   `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`:

   - **Content**: Title (single line text, primary), Type (single select: post, reel, short, long-form,
     week-pack, blog, ad, email), Status (single select: review, approved, posted), Body (long text),
     Source URL (url), Created (date).
   - **Lessons**: Rule (long text, primary), Area (single select: content, seo, outreach, analytics, general),
     Active (checkbox), Source (single line text), Added (date).
   - **Posts**: Content title (single line text, primary), Platform (single select: tiktok, instagram,
     youtube, linkedin, other), Posted date (date), Views (number), Likes (number), Comments (number).
   - **Leads**: Company (single line text, primary), Owner name (single line text), Channel (single line
     text), Email (email), Research notes (long text), Pain (long text), Opener (long text), Status (single
     select: new, contacted, replied, booked, dead), Source URL (url), Added (date).
   - **Tasks**: Task (single line text, primary), Area (single select: content, seo, outreach, analytics,
     general), Status (single select: todo, doing, done), Due (date), Notes (long text).

4. Write the returned base ID and each table ID into `config.brain.airtable`:
   ```
   "brain": {
     "mode": "airtable",
     "localPath": "brain",
     "airtable": {
       "baseId": "<returned base id>",
       "tables": {
         "content": "<returned table id>",
         "lessons": "<returned table id>",
         "posts": "<returned table id>",
         "leads": "<returned table id>",
         "tasks": "<returned table id>"
       }
     }
   }
   ```
   In documentation and examples elsewhere, these placeholders are always written as `YOUR_BRAIN_BASE_ID`,
   `YOUR_CONTENT_TABLE_ID`, `YOUR_LESSONS_TABLE_ID`, `YOUR_POSTS_TABLE_ID`, `YOUR_LEADS_TABLE_ID`,
   `YOUR_TASKS_TABLE_ID`. Only the real IDs returned by the MCP for this buyer's own base get written into
   their local config file.
5. Set `config.brain.mode = "airtable"`.

## Step 3 - finish

Update `config.lastUpdated` to the current date and save the tenant config.

Report back to the user in chat:
- Which mode was set up (local or airtable).
- Where the files (or base) live.
- That every module will now read Active lessons before producing and log a row after.

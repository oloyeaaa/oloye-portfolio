---
description: Set up The Marketing Team for your business - the install wizard (business basics, voice calibration, config, Brain, first content run).
---

# /marketing-team:setup

Run the full setup wizard at `${CLAUDE_PLUGIN_ROOT}/skills/marketing-team-setup/SKILL.md`. Follow it start to
finish, in order: welcome, business basics, voice calibration, write the tenant config and voice profile,
optional module switches, offer the Brain, offer a first content run, then close with the daily/weekly
routine and where everything lives.

## After the wizard: run the machine health check

Once the wizard is done, run the health check so the buyer knows which optional media skills will actually work
on their computer. Follow `${CLAUDE_PLUGIN_ROOT}/commands/doctor.md` (or tell them to run `/marketing-team:doctor`).

Say it plainly: the **core marketing team** (content, blog, outreach, analytics, Brain, lessons) needs no tools
and works right now. The **media skills** (reels, AI image and video, b-roll, PDF lead magnets) are **Advanced**
and need Python, ffmpeg, Node or a paid fal.ai key. The health check lists exactly what is present and what to
install, so nothing fails cryptically later. Do not let a missing media tool read as "the plugin is broken" - it
is not; the core is fully working.

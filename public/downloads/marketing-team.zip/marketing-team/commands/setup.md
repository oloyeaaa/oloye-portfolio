---
description: Set up The Marketing Team for your business - the install wizard (business basics, voice calibration, config, Brain, first content run).
---

# /marketing-team:setup

Run the full setup wizard at `${CLAUDE_PLUGIN_ROOT}/skills/marketing-team-setup/SKILL.md`. Follow it start to
finish, in order: welcome, business basics, voice calibration, write the tenant config and voice profile,
optional module switches, offer the Brain, offer a first content run, then close with the daily/weekly
routine and where everything lives.

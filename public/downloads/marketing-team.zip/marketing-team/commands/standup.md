---
description: Run the team's daily pipeline - lessons first, then content, blog, and outreach passes, a QA gate, and one tight report.
argument-hint: "[content | full]   (content = lessons + content pass only; full = also blog glance + outreach; default = full)"
---

# /marketing-team:standup

Run the team's pipeline for one business, in order. Be concise, plain language, never invent a result. The
main session runs this whole pipeline itself; subagents used inside it cannot spawn further subagents.

## Step 0 - tenant resolution

Parse `--business <slug>` from arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the buyer to run `/marketing-team:setup` first and stop.

Mode from `$ARGUMENTS`: `content` = steps 1-2 only. `full` = all steps. Default = `full`.

## 1. Lessons first

Read every Active Lessons row (all areas) via `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`. Apply every
one as a hard constraint across everything produced in this run, not just its own area. This step always
runs, in both modes.

## 2. Content pass

Propose and draft the day's content:
- Run `${CLAUDE_PLUGIN_ROOT}/skills/week-of-posts/SKILL.md` (or a single post, if that's what's due) using
  `config.brand` and the voice profile at `businesses/<slug>.voice.md`.
- Run the finished draft(s) through `${CLAUDE_PLUGIN_ROOT}/skills/brand-voice/SKILL.md` before logging.
- Log each piece as a Content row via brain-loop, `Status` = `review`.

## 3. Blog glance (full mode only)

If `config.seo.evalKeywords` has entries, or a keyword was passed as an argument, either suggest the best
keyword to write next or hand off to `/marketing-team:blog-draft` for it. If neither exists, skip this step
and say so in the report, don't force a blog post that wasn't asked for.

## 4. Outreach pass (full mode only, and only if enabled)

If `config.outreach.enabled` is `true`, run `${CLAUDE_PLUGIN_ROOT}/skills/outreach/SKILL.md` for one batch
(one business type/area, per that skill's own scope). If `config.outreach.enabled` is `false`, skip this step
entirely and say so plainly in the report, don't nudge the buyer to turn it on mid-run.

## 5. QA gate

Before anything produced today is reported as ready, check every piece against:
- The voice profile (`businesses/<slug>.voice.md`) and `config.brand` (tone, banned words).
- The no-invented-facts rule: no stat, customer result, or claim that wasn't actually provided or verifiably
  true.

Anything that fails either check gets fixed before it's reported, or sent back with a one-line reason why it
didn't make the cut. Track how many pieces needed a fix or got sent back.

## 6. Record and report

1. Write one Tasks row via brain-loop: `Task` = `Standup <date>`, `Area` = `general`, `Status` = `doing`,
   `Notes` = a short summary of what ran and what needs the buyer.
2. Report to the buyer, tight, plain language, no em dashes:
   - What was made (list titles, one line each).
   - What needs the buyer's approval (the Content rows sitting at `review`).
   - Anything QA sent back and why.
   - The one thing to do next.

Use `config.team.manager` (or "the manager" if not named) if the report refers to itself. Never write a
personal name that isn't in `config.team`.

## Degrade gracefully

If the Brain is unreachable at any point, say so, skip the read or write, and keep going with the rest of the
pipeline. Never block the whole standup on one broken step.

---
description: Weekly analytics review - what's working, what to change, what to try next, backed by real numbers when they exist.
argument-hint: "(optional) a focus, e.g. 'reels' or 'instagram'"
---

# /marketing-team:weekly-review

Run the weekly review for one business: check what's aligned, what the numbers say (if there are any yet),
and hand back one clear lever to pull next week. Plain language, no jargon, never invent a number.

## Step 0 - tenant resolution

Parse `--business <slug>` from arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the user to run `/marketing-team:setup` and stop. Never type a literal ID or brand value;
everything comes from this config.

Brain contract: `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`. Read Active Lessons where `Area` is
`analytics` or `general` first, and apply them as hard constraints on this review.

## Step 1 - gather data

Two sources, both optional, never invented:

1. **Metricool (if connected).** If a Metricool MCP tool is available, use it to pull the last 7 days of post
   metrics for the channels listed in `config.channels`. Look up the connected brand/account first, then pull
   analytics by metric for that window. If the MCP is not connected, or the call fails, say so plainly and
   move on. Never fabricate a view count, like count, or engagement figure.
2. **Brain Posts.** Read the Posts table (local `posts.md` or the Airtable `tables.posts`, per
   `config.brain.mode`) for rows from the last 7 days.

**If BOTH sources are empty:** say so in plain terms and switch to a **readiness review** instead of a
performance review. Answer three questions honestly, using whatever the Brain Content/Tasks tables and the
tenant config show:
- Is content actually going out right now (check the Content table for `posted` rows on the channels listed
  in `config.channels.primary`)?
- Are the channels in `config.channels` actually set up and connected (scheduler, Metricool, socials)?
- What is blocking the first post from going out, if nothing has posted yet?

Never invent numbers to fill a gap. If there is no data, the honest output is a readiness check, not a
guess dressed up as an insight.

## Step 2 - review against config

Compare whatever was gathered in Step 1 against `config.brand` and `config.channels`:

- **Alignment.** Does what went out (or what's planned) match `config.brand.oneLiner` and
  `config.brand.audience`? Flag anything off-brand or off-audience.
- **What won (only if real data exists).** Which hooks, formats, or platforms performed best this week,
  using only the pulled Metricool numbers or the Posts table rows. If there isn't enough data to call a
  winner, say that plainly instead of guessing.
- **Cadence and gaps.** Look at what actually went out per channel in `config.channels.primary`.
  Call out missed days, dead channels, or a channel with zero posts.
- **The one number.** Check `config.brand.weeklyMetric` (the buyer's single weekly focus number, e.g. leads,
  bookings, comments on the keyword). If it is set, say whether it moved this week using real data only. If
  it is not set, ask the buyer what their one number is, and offer to save it to
  `config.brand.weeklyMetric` so future reviews can track it automatically.

Apply `$ARGUMENTS` as a focus if one was given (e.g. narrow the review to one platform or format).

## Step 3 - output

Deliver a tight **Keep / Change / Try** review, biggest lever first:
- **Keep** - what's working, don't touch it.
- **Change** - the single biggest thing to fix, with why.
- **Try** - one small experiment for next week.

Keep it short. No walls of text, no invented numbers, no vague advice like "post more" without a reason tied
to what was actually observed.

## Step 4 - write to the Brain

Following the loop contract in `skills/brain-loop/SKILL.md`:

1. Write **ONE** Lessons row: `Area` = `analytics` (or `content` if the lesson is really about the content
   itself), imperative rule under 100 characters, `Active` = true, `Source` = `performance`.
2. Write **ONE** Tasks row: the single top action from the Change/Try section, `Area` = `analytics`,
   `Status` = `todo`.
3. If real metrics were pulled (Metricool connected or Posts rows already present) and `config.brain.mode` is
   `local` or `airtable`, update the matching Posts rows with the pulled numbers (Views, Likes, Comments).
   Skip this step entirely if there was no real data to write; never write a Posts row with a guessed number.
4. If the Brain is unreachable, say so and skip the write. Never block the review on a Brain failure.

## Step 5 - report

Report the full Keep / Change / Try review in chat, state plainly which data sources were used (Metricool
connected or not, Posts rows found or not), and confirm what was written to the Brain.

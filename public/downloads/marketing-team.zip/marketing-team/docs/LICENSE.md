# Licence

The Marketing Team is commercial software. One purchase covers one business.

What you can do:
- Install and run the plugin for your own business, on your own machines.
- Edit any file to fit your business.
- Keep every piece of content, lead list, and document the team produces. Your output is yours.

What you cannot do:
- Resell, re-package, or redistribute the plugin or any part of it.
- Share the files publicly or include them in another product.
- Run it as a service for other businesses without a separate agreement.

Agencies: if you want to run The Marketing Team for clients, ask about an agency licence.

No warranty is given. The plugin drafts and suggests; you review and approve before anything is sent or
published. You are responsible for complying with the marketing and privacy laws that apply to your business.

Final licence wording is set by the seller at purchase. This file is the plain-language summary.

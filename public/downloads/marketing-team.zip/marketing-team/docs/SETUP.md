# Setup

How to install The Marketing Team, what you need first, what the setup wizard actually asks, and how to fix
the most common snags.

## Install

**From a marketplace (once published):** follow the marketplace's own install instructions for the
`marketing-team` plugin.

**Local or zip install (available now):**

1. Get the plugin folder onto your machine (unzip it if it came as a zip).
2. Run:
   ```
   claude --plugin-dir <path-to-the-plugin-folder>
   ```
3. Claude Code loads the plugin for that session. Run `/marketing-team:setup` to get started.

To check the plugin is well-formed before installing it anywhere, you can run
`claude plugin validate <path-to-the-plugin-folder>`.

## Prerequisites

- **Claude Code**, installed and working, with your own subscription. Everything runs inside it.
- **Python and ffmpeg**, but only if you plan to use the video skills (turning a reel or a YouTube video into
  your own version). Every other module, the writer, the SEO writer, outreach, the weekly review, runs with
  nothing extra installed.
- **Nothing else is required.** Airtable, Metricool, Google Calendar/Drive/Gmail, fal.ai, and Higgsfield are
  all optional connections. If one isn't connected, the step that would use it says so plainly and skips,
  nothing breaks.

## The setup wizard, step by step

Run `/marketing-team:setup`. It takes about 20-30 minutes and walks through:

1. **A short welcome** explaining what the team does.
2. **Business basics**: your business name, what you sell and to whom, your main offer, your audience, your
   region, the channels you use, and the one action you want every piece of content to ask for.
3. **Voice calibration**: it asks for 2-3 real samples of how you write or talk, posts, emails, or a voice
   note transcript, and learns your sentence length, energy, and the phrases you actually use. If you don't
   have samples handy, it runs a quick 5-question interview instead and marks the result a draft to refine
   after your first week.
4. **Your config is written**: your settings and your voice profile are saved outside the plugin, so they're
   yours and survive plugin updates.
5. **Optional modules**: it asks if you want outreach turned on (with your target audience and the region's
   compliance rules), whether you have a website to publish blog posts to, and whether you use a scheduler.
   You can also name your team members here, or leave them as plain role labels.
6. **The Brain**: it offers to set up shared memory for the team, local files by default (no accounts needed),
   or your own Airtable base if you already use one.
7. **A first content run**: it offers to turn one idea from the interview into a week of ready-to-post
   captions, right there, so you see it working before you close the session.
8. **A close**: what to run daily and weekly, and exactly where everything lives.

Why it asks all this: every other module reads from what you tell it here. Nothing is hardcoded to any one
business, your config is the single source of truth for your brand, your voice, and what's turned on.

## The Brain: local or Airtable

Every module shares one memory, called the Brain. You choose the mode during setup, or later with
`/marketing-team:setup-brain`.

- **Local (default)**: plain markdown files on your own computer, `~/.claude/marketing-team/brain/<slug>/`.
  Zero setup, works immediately.
- **Airtable**: your own base, created fresh for you, never an existing one. Useful if you already live in
  Airtable or want a shared view outside Claude Code. Needs the Airtable connection to be active in Claude
  Code; if it isn't, setup tells you and falls back to local so you're never stuck.

Full detail in `docs/manager.md` (the loop that keeps every module reading and writing the same memory) and
`docs/brain.md`.

## Per-module opt-ins

Nothing beyond the manager and the content basics is switched on by default:

- **Outreach** stays off until you turn it on in setup (or later, by editing your config or rerunning setup).
  It needs an ICP, an offer, and a compliance mode before it will run at all.
- **Site publishing** stays off until you give it a real repo path. Until then, blog drafts save to
  `~/.claude/marketing-team/brain/<slug>/blog/` and you paste them in yourself.
- **Scheduler** stays `none` until you confirm you use Metricool and it's connected.

## Troubleshooting

- **"Run /marketing-team:setup" keeps appearing.** Your config is missing or the business slug doesn't match.
  Run `/marketing-team:setup` to create it, or check `~/.claude/marketing-team/config.json` has the right
  `defaultBusiness` and that a matching file exists under `~/.claude/marketing-team/businesses/`.
- **Python or ffmpeg missing.** Only the video skills (reel and long-form pipelines) are affected. Everything
  else, writing, SEO, outreach, the weekly review, still works. Install Python 3.10+ and ffmpeg (Windows:
  `winget install Gyan.FFmpeg`; macOS: `brew install ffmpeg`) when you're ready to use them.
- **A connection isn't working** (Airtable, Metricool, Google Calendar, Gmail). The affected step says so
  in plain language and either skips or falls back to a manual alternative (e.g. local Brain instead of
  Airtable, a paste-ready schedule instead of an automatic one). Nothing else in the team is blocked by one
  missing connection.
- **The voice doesn't sound right yet.** If your profile was written from the quickfire questions instead of
  real samples, it's marked as a draft on purpose. Give it a real sample or two after your first week and
  rerun the voice calibration step in setup to sharpen it.

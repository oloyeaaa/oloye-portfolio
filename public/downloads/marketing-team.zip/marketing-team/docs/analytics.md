# Analytics

The weekly review looks at what your team posted, checks it against your brand and your channels, and hands
you back one clear thing to change. It runs on your own numbers when there are numbers, and never makes any
up.

## What it does

Once a week, run the review and it will:

- Pull the last 7 days of post metrics from Metricool, if it's connected.
- Read your own performance log (the Brain's Posts list).
- Check what went out against your one-liner and your audience, so you can see if the content still matches
  who you're actually selling to.
- Say which hooks, formats, or platforms won this week, but only if there's real data to say it from.
- Check your posting cadence against your set-up channels and flag any gaps.
- Check whether the one number you care about most (leads, bookings, comments, whatever you picked) moved
  this week.
- Give you a short **Keep / Change / Try** review, biggest thing first.
- Save one lesson and one task, so next week's content is built on what was actually learned, not forgotten.

## What it needs to start

Nothing. You can run the weekly review the moment you've set up your business. If there's no data yet, it
switches to a readiness check instead: is content going out, are your channels actually connected, and
what's stopping the first post if nothing has gone out yet. It will never invent a view count or a like
count to fill the gap.

## Making it automatic

Connect Metricool and the review pulls real post metrics for you every week, no manual copying of numbers.
Without Metricool, it still works off whatever you've logged in the Brain's Posts list.

## The one number

Tell it the single number you care about most each week (leads, bookings, comments on your keyword, whatever
moves your business forward) and it will save that as your weekly focus. Every future review checks whether
that number moved, and says so plainly, good or bad.

## How lessons bind next week

Every review writes one lesson to the Brain. That lesson gets read by the content team before the next
batch goes out, so a mistake gets caught once and doesn't repeat. This is the same shared memory every part
of your team reads from, so a lesson from a weekly review can change what gets written, scheduled, or sent
next.

# The Brain

The Brain is your team's shared memory. Every part of the team, content, SEO, outreach, analytics, reads from
it and writes to it. That is what makes them feel like one team instead of separate tools.

## Why it matters

Without shared memory, every task starts from zero. You correct something today, and the same mistake happens
again next week because nothing remembered the correction.

With the Brain, a correction becomes a lesson. The next piece of content, the next outreach message, the next
report, all check the lesson list first and follow it. Your team gets sharper every week instead of staying
the same.

## What it stores

Five simple lists:

- **Content**: everything the team has produced, and its status.
- **Lessons**: rules learned from your corrections and from what worked or didn't.
- **Posts**: how published content actually performed.
- **Leads**: people or businesses your outreach has found and contacted.
- **Tasks**: what's next, and who owns it.

## How the loop works

1. Before making anything, the team checks the active lessons and follows them.
2. After making something, the team logs it.
3. When you correct something or kill a piece of work, the team writes down why as a new lesson.
4. If the Brain can't be reached for some reason, the team says so and keeps working. You never lose a
   deliverable because memory failed.

## Two ways to run it

**Local (the default).** Plain files on your own computer. No setup, no accounts, works the moment you
install. Good for most people.

**Airtable.** Your own Airtable base, with the same five lists as tables. Good if you already work in
Airtable, or you want to browse and edit the Brain outside of Claude Code, or you have a team who wants a
shared view.

Both modes store exactly the same information. Switching modes does not change what the team can do.

## Setting it up

Run the setup command and pick local or Airtable when asked. If you pick Airtable but it isn't connected yet,
the team tells you and sets up local instead, so you're never stuck.

## Switching later

You can move from local to Airtable at any time by running the Brain setup again and choosing Airtable. Your
existing lessons and content history stay in the local files; only new entries are added to the fresh
Airtable base going forward.

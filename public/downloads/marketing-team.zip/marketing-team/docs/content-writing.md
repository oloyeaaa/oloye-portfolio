# Content writing

Three skills that write in your voice: a week of posts, a lead magnet, and the voice system both run on.

## brand-voice

What it does: writes or polishes any public copy so it sounds like you. Every other content skill runs its
output through this before it hands anything back.

What it needs: your business config (set up once via `/marketing-team:setup`) and a voice profile. If you
don't have one yet, it asks for three samples of your real writing or talking (a voice note, a text thread,
an email) and builds a profile from that. You confirm it before it's used.

Example asks:
- "Polish this post so it sounds like me."
- "Write this cold email in my voice."
- "Rewrite this caption, it sounds too corporate."

## week-of-posts

What it does: turns one idea into seven ready-to-post captions across a proven weekly mix (a tip, behind
the scenes, a real customer win, your offer, a myth, a question, something local or human). Every post gets
a strong first line, plain words, and hashtags.

What it needs: your business basics (from config), one seed idea (a topic, an offer, or a quick voice
note), and your channels. If you have Metricool connected, it can schedule the week for you and shows the
schedule before it posts anything. If not, you get a paste-ready schedule table.

Example asks:
- "Give me a week of posts about our new opening hours."
- "I don't know what to post, here's a voice note about the business."
- "Fill my content calendar for next week."

## lead-magnet

What it does: turns something you know (a checklist, a short guide, a framework) into a branded PDF you can
give away, plus a caption to promote it and one delivery method.

What it needs: the topic, your audience (from config), and the one outcome the PDF should deliver. If your
config points at a cover image, it uses it; if not, you get a clean typographic cover, never an empty gap
where a photo should be. The call to action comes straight from your config, either a comment keyword or a
link.

Example asks:
- "Turn our onboarding checklist into a lead magnet."
- "Give away our 5-step pricing guide as a PDF."
- "Make a freebie from this framework I use with clients."

## How they fit together

All three read from the same business config, so your wordmark, banned words, tone, and call to action stay
consistent everywhere. Every finished piece is logged so the team's future work learns from what worked and
what got corrected.

# The manager

The manager keeps your marketing team moving without you having to chase it. It runs two things: a short
daily brief, and a standup that actually makes the day's work.

## The daily brief

Run `/marketing-team:daily-brief` any morning. It reads your open tasks, how many lessons the team is
currently applying, and what got made yesterday, and if you've connected Google Calendar, it also shows
today's and tomorrow's events. It reports back in under 200 words: numbers first, plain language, no filler.

It never invents an event, a task, or a number. If a source can't be reached, it says so in one line and gives
you the rest.

This is a command you run, not something that runs itself in the background. See "Making it automatic" below
if you want it to fire on its own.

## The standup

Run `/marketing-team:standup` to make the day's actual work happen. In order:

1. It reads every active lesson first, so today's work doesn't repeat yesterday's mistake.
2. It drafts the day's content in your voice and logs it for your review.
3. If you've set target keywords, it glances at the blog backlog and suggests or drafts the next post.
4. If outreach is turned on, it runs one batch: research, then draft openers, never sent automatically.
5. Everything produced gets checked against your voice profile and a no-invented-facts rule before it's
   reported as ready. Anything that fails gets fixed or sent back with a reason.
6. You get one tight report: what was made, what needs your approval, and the one thing to do next.

Run `/marketing-team:standup content` for just the content pass, or leave it as `full` (the default) for
everything, including the blog glance and outreach.

## Naming your team

By default the team refers to itself plainly: "the manager", "the writer", "the outreach lead", "the
analyst". If you'd rather give them names, set them during `/marketing-team:setup` (or edit `config.team` in
your `~/.claude/marketing-team/businesses/<slug>.json` directly). Every report and every piece of content the
team writes about itself uses whatever's in that config, nothing is hardcoded.

## Making the brief automatic

The daily brief and the standup are commands, they run when you run them. If you want the brief to land on
its own every morning without you typing anything, you wire it to your own scheduler. Three honest options,
pick whichever fits how you already run things:

- **Windows Task Scheduler**: create a daily task that runs a script calling Claude Code with
  `/marketing-team:daily-brief` at whatever time suits you.
- **cron** (macOS/Linux): add a line to your crontab that runs the same command each morning.
- **Claude Code scheduled runs**: if your Claude Code setup supports scheduled or recurring runs, point one at
  `/marketing-team:daily-brief`.

None of these ship configured out of the box, because they depend on your machine and how you already run
scheduled jobs. Set up whichever one matches your existing habits, or just run the command by hand each
morning, plenty of buyers do exactly that.

## Where the manager gets its facts

Everything the manager reports comes from your tenant config
(`~/.claude/marketing-team/businesses/<slug>.json`) and the Brain
(`~/.claude/marketing-team/brain/<slug>/`, or your Airtable base). It never draws on a previous business's
data or a generic template. If your config is missing, it tells you to run `/marketing-team:setup` and stops,
rather than guessing.

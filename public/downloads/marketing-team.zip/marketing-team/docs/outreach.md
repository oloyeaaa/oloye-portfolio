# Outreach

Outreach finds businesses that fit your ideal client, researches each one for real, and writes a short cold
email that earns a reply. It does not send anything on its own. Every email it writes is a draft for you to
read, edit, and send yourself.

## What it does

1. You tell it who to target (your ICP) and what you're offering, once, in setup.
2. It searches for real businesses that match, one type of business and one area at a time.
3. For each one, it looks for a genuine public contact detail (an email, or a social handle if no email is
   public) and one true, specific thing about them worth mentioning.
4. It writes a short, plain email: one true observation about them, the cost of the problem, the plain fix,
   and one low-pressure question that invites a reply.
5. Every lead gets saved to your Leads list with its status, so nothing gets lost or contacted twice.

It never invents a contact detail or a fact about a business. If it can't find a real email, it leaves the
email blank and suggests reaching out by DM instead.

## Draft only, always

This tool does not send email. If you have Gmail connected, it can create drafts sitting in your Gmail
account for you to review and send. Nothing goes out without you clicking send.

## Picking a compliance mode

Cold email rules depend on where you and your prospects are based. Pick the one that matches your situation
when you set this up. If you're not sure, pick "manual" and check with someone who knows your local rules
before you send anything.

**UK (uk-pecr)**
You can cold email limited companies and LLPs. You cannot cold email sole traders or ordinary partnerships,
because under UK rules they count as individuals, not businesses. The tool checks the public companies
register for each prospect. If they're not a Ltd or LLP, it will suggest reaching out by direct message or
phone instead of email. Every email includes who you are and a working opt-out line.

**EU (eu-gdpr)**
Business-to-business email is generally allowed on the basis of legitimate interest, as long as you identify
yourself clearly and give an easy way to opt out. Rules differ a bit by country, and some countries expect
prior consent rather than allowing this basis outright, so the tool will remind you to check the specific
country you're contacting before sending in volume.

**US (us-can-spam)**
You need to identify yourself, include a real postal address, use a subject line that isn't misleading, and
honour any opt-out request within 10 days.

**Manual**
Use this if none of the above fits, or you're not sure which applies. The tool will not check anything for
you, and it will tell you plainly to confirm the law that applies before you send. It still adds an opt-out
line to every email regardless.

## What to expect

This is built for low volume, high relevance, not blasting hundreds of people:

- Around 20 to 40 emails a day at most. This keeps your email account healthy and out of spam folders.
- One email per business, plus at most one follow-up. Then it stops.
- Plain text only. No links, no images, no attachments.
- Every email includes an opt-out line, and anyone who says no goes on a do-not-contact list that's honoured
  on every future run.

Because this is aimed at genuine replies rather than volume, expect a normal week to produce a short list of
real, researched leads rather than hundreds of names. Quality over quantity is the point: a handful of people
who actually reply beats a long list nobody reads.

## Getting started

Run `/marketing-team:setup` and fill in the outreach section: who you're targeting, what you're offering as
the first ask, and your compliance mode. Once that's saved, ask for a prospect list or cold openers and the
outreach skill takes it from there.

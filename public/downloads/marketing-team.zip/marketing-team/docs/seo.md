# SEO writer

The SEO module writes blog posts for your site, in your voice, and keeps a memory of what worked so it gets
better over time.

## The loop, in plain words

1. **Draft.** Run `/marketing-team:blog-draft <keyword>` with a target keyword. It writes a full post: title,
   body, meta description, everything a blog post needs.
2. **Review.** Every draft lands in a "review" state. Nothing goes live automatically.
3. **Post or kill.**
   - `/marketing-team:post-blog` publishes it.
   - `/marketing-team:kill-draft` bins it, and asks why. That "why" becomes a rule the writer follows on every
     future draft.
4. **Every kill teaches the writer.** Say why a draft didn't work once, and it won't make the same mistake
   again. You can also teach a rule directly, any time, with `/marketing-team:lesson`.
5. **The eval gate.** Run `/marketing-team:eval-writer` after any change to your brand settings or voice
   profile. It drafts a handful of test posts and scores them against your own rules. If quality drops, it
   flags the problem and blocks new drafts until you run a clean check again.

## What site publishing needs

Publishing straight to your live site is optional, and needs a git repository for your site (`config.site.
enabled = true`, plus a repo path in your settings). If you turn this on, a draft's cover image and content
get committed and pushed to that repo.

This plugin does not deploy or host your site. Once content is pushed, your own site build (whatever hosts it,
your CMS, static site host, or custom deploy pipeline) needs to pick it up. Posting here marks the content
ready and records it, it doesn't trigger your deploy.

## What runs with nothing configured

By default, `config.site.enabled` is off. In that mode:

- Drafts are saved as plain markdown files on your own computer.
- No git repo, no cover image, no site required.
- You can still draft, review, publish (mark as posted), and kill, all of it just stays local until you're
  ready to copy it to wherever you actually publish.

This means the SEO writer works the moment you install it, with zero setup beyond telling it your brand and
keywords.

## Voice rules

Every draft follows plain rules, no exceptions:

- No em dashes.
- Plain language, no jargon in the opening.
- One clear call to action per post.
- British or US English, matched to your settings.

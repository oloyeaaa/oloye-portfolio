# Video

Three skills plus one command turn videos that already work into your own content, and turn raw recordings
into finished, branded, ready-to-post vertical videos.

## What's included

### `/marketing-team:reel` - transcribe and understand any reel
Give it a reel or video URL. It downloads the audio, transcribes it locally, and writes a short markdown note
explaining what the video teaches: the summary, the key points, and the full transcript. No script writing,
no editing, just a fast way to understand a video before you decide whether to remake it. Nothing leaves your
machine except the audio download itself.

### `reel-pipeline` - make your own version of a reel that's working
Give it a reel that's already getting engagement. It downloads it, transcribes it, and uses Claude to split it
into the parts that make it work (the hook shape, the pacing, the structure) and the parts that are just that
creator's content (their picks, their examples, their claims). It asks you to fill those parts with your own
content, then writes your version: three hook options, a full script, and a shot list biased toward screen
recordings if you're camera-shy. It will not invent your opinions. If you don't give it something, it flags
the gap instead of making something up.

The output also works for **YouTube Shorts**: same 9:16 format, same length, post it to both.

### `youtube-pipeline` - make your own long-form version of a YouTube video
The long-form counterpart. Give it a YouTube video that performs, it reverse-engineers it the same way, and
writes a full narration script for a 16:9 long-form video: paste-ready for a voice-cloning tool like
ElevenLabs, with a synced screen-recording plan, chapters, three title options, and a description. No talking
head required.

### `screen-to-reel` - turn a raw recording into a finished vertical video
Give it a screen recording or any landscape clip. It reframes it to 9:16, burns on branded captions (a top
bar with your name, a bottom caption bar with your accent colour), adds an optional scroll-pan reveal of the
finished result, appends a call-to-action end card, stitches everything together with crossfades, and embeds
share metadata. It hands back the caption, hashtags, and cover guidance to post with. Your brand colour and
name come from your setup config, not a fixed look.

## How they fit together
```
UNDERSTAND A VIDEO   →  /marketing-team:reel
MAKE YOUR VERSION     →  reel-pipeline (short-form)  or  youtube-pipeline (long-form)
RECORD               →  you, screen recording against the shot list
EDIT TO FINISHED VIDEO →  screen-to-reel
POST                 →  your own scheduler, or by hand
```

## Prerequisites

- **Python 3.10 or newer**, on your PATH.
- **ffmpeg** and **ffprobe**, on your PATH (used by every video step: reframing, captions, stitching).
- **A one-time Whisper model download**, about 2GB. The first time you transcribe anything, the reel and
  YouTube pipelines pull down PyTorch and the local Whisper model. This only happens once and needs a stable
  connection and some patience; after that, transcription runs offline.
- **`ANTHROPIC_API_KEY`** in the `reel-pipeline` skill's own `.env` file (copy `.env.example` to `.env` and
  fill it in). This key powers the script writing and the video reverse-engineering.
- **Instagram cookies (optional, only for reels)**: most Instagram reels will not download without a logged-in
  session. You export your own cookies once from a browser extension and point the pipeline at the file.
  **Account-risk warning:** this uses a real, logged-in Instagram session. Heavy or automated download
  traffic through that account can get it flagged or rate-limited. If you plan to run this often, use a
  secondary account, not your main business one.

## Local file vs URL: which path is safe

- **A video you already have on your machine** (a screen recording, an exported clip) never leaves it except
  for the one Claude call that writes the script or reads the captions. This is the safest path, and it's how
  `screen-to-reel` normally works: you record, then it processes locally.
- **A URL** (an Instagram reel or YouTube video) has to be downloaded first. Public YouTube videos download
  with no login needed. Instagram reels usually need your cookies (see above), which means that download runs
  under your logged-in identity. Only point these tools at content you're allowed to remake, and treat the
  Instagram cookie step as the one part of this system that carries account risk.

## Voice rules for anything these skills write publicly
No em dashes. Plain language. No jargon. Say what the video does for the person watching it, not what
technology it uses.

# Visuals: images, motion, and video ads

Three of your team's skills generate real images and video, and they spend real money on your own
accounts when they do. This page explains what each one is for, what it costs, and the one rule that
applies to all of them.

## The one rule: confirm before you spend

Every paid step (a video render, an upscale, a full ad) tells you the estimated cost and the prompt
first, and waits for your yes before it runs. Images are pennies, so those just run. Nothing spends
money silently. If you ever see a render start without being asked first, that's a bug, not a feature.

## The three tools

**Render Room** (`render-room`)
Your general-purpose image and video generator. Give it a rough idea and it writes a strong prompt, picks
a model, and generates an image, edits an image, turns an image into a short video clip, or upscales a
video. Runs on your own fal.ai account and API key. This is the engine the other two lean on.
- Costs money on: your fal.ai account.
- Typical cost: an image is pennies. A short video clip is roughly 25 to 60 cents. An upscale is roughly
  20 to 40 cents.

**Motion Design** (`motion-design`)
Takes a logo or a single product image and turns it into a short animated motion piece: a logo reveal, a
kinetic promo, a brand sting. Walks you through a quick brief, builds a storyboard for you to approve,
then renders the final clip.
- Costs money on: your own Higgsfield account and credits.
- Typical cost: shown to you as a credit estimate before the render, based on your Higgsfield plan.

**Product Ad** (`product-ad`)
Takes a product photo or a store link and builds a finished short-form ad: either a cinematic story ad
(moody, premium, model plus product plus a branded end card) or a UGC-style ad (an AI creator talking to
camera). Builds the stills, animates each beat, assembles the clips with transitions, adds your branded
end card, and logs the real cost and time to your Brain.
- Costs money on: your fal.ai account (it uses Render Room under the hood).
- Typical cost: a short cinematic ad with a few beats is roughly $8 to $15 and takes about 15 to 25
  minutes end to end. Numbers vary with how many beats you use.

## How to pick the right one

If you're not sure which tool fits, the **asset-routing** skill sorts it for you:

- A still image or logo you want to move → Motion Design.
- A product photo or store link you want turned into a finished ad → Product Ad.
- A rough idea you want turned into an image or clip, or something you want upscaled → Render Room.
- Footage you already recorded on your screen → screen-to-reel (see the content docs).

If a job needs more than one step, the usual order is: Render Room builds or improves the raw asset,
Motion Design animates a still, Product Ad assembles the finished piece.

## Setup you need once

- A fal.ai account and API key, for Render Room and Product Ad. Put the key in your own `.env` file, never
  paste it into chat.
- A Higgsfield account with credits, for Motion Design.
- `ffmpeg` installed and on your system PATH, for Product Ad's assembly step.

Everything these tools produce is saved to your own output folder and, when you keep it, logged to your
Brain so the team remembers what was made and why.

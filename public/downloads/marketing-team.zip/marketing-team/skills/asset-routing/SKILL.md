---
name: asset-routing
description: >-
  Routing skill for the paid-generation visual/video tools. Use whenever a visual or video ask could
  match more than one tool: "make me a video", "animate this", "turn this into an ad", "generate an
  image", "I have a product/logo/screen recording, what do I use". Reads the request and points to the
  right one of motion-design, product-ad, render-room, or screen-to-reel before any generation runs, so
  the buyer doesn't burn money on the wrong tool.
---

# Asset routing - which video tool for which job

The content engine ships four tools that all touch images or video. They do not overlap as much as it
looks. Use this skill to pick one before any generation runs, so tools never fight over one job and the
buyer doesn't spend money on the wrong path.

## The one-line rule

- **You have a still image or a logo and want it to move** → `motion-design`.
- **You have a product (photo or store link) and want a finished ad** → `product-ad`.
- **You have a rough idea and want to generate an image or clip from scratch, or upscale one** → `render-room`.
- **You already recorded your screen and want it posted as a branded vertical** → `screen-to-reel`.

## Longer version

| Tool | Input | Output | Reach for it when |
|---|---|---|---|
| `render-room` | A text idea, or an image + reference images | One image, one image-to-video clip, or an upscale | You need a raw asset built or enhanced. It is the engine the others lean on. Pay-per-use on the buyer's own fal key, cost confirmed first. |
| `motion-design` | A logo or a single product image | A short animated motion piece | You want a static brand asset to animate. Runs on the buyer's own Higgsfield connection. |
| `product-ad` | A product photo or a store URL | A finished cinematic or creator-style ad with a branded end-card | You want the whole ad, not a raw clip: stills, animated beats, assembly, end-card, and a logged time + cost. |
| `screen-to-reel` | A raw screen recording or any landscape clip | A branded, captioned 9:16 vertical with an end-card | The footage already exists and you just need it posted-ready. |

## Order of operations, if a job needs more than one

A common chain: `render-room` builds or upscales the raw asset → `motion-design` animates a still →
`product-ad` assembles the finished ad → `screen-to-reel` handles any screen-capture piece separately.

Do not run two of them on the same job at the same time expecting them to merge. Pick the one whose
**output** matches what the buyer actually wants to hand over, and only step back to an earlier tool if
you are missing an input it needs.

## Cost warning (always say this before routing to a paid step)

`render-room`, and anything that calls it (so `product-ad`, and `motion-design` when it generates a
video), spend real money on the buyer's own fal key or Higgsfield connection. Every paid step asks first
and logs the real number. Never inflate those numbers when they get reused as proof of what the tool
costs.

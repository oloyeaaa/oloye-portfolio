---
name: brain-loop
description: Use whenever any module needs to read or write the team's shared memory (the Brain) - reading active lessons before producing content, logging a finished piece, recording a lead, updating a task, or capturing a lesson from a kill or correction. Trigger on "log to the brain", "check lessons", "what has the team produced", "save this lead", "add a task", or any module about to produce content, leads, posts, or tasks.
---

# Brain loop

The Brain is the shared memory for every module in The Marketing Team. It is not one module's private
notebook: content, SEO, outreach, and analytics all read and write the same five tables so the team gets
sharper every week instead of starting cold every run.

This file is the ONE contract. Every skill, command, and agent that touches the Brain points here instead of
re-describing the rules.

## Step 0 - tenant resolution (do this first, every time)

Parse `--business <slug>` from arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the user to run `/marketing-team:setup` and stop. Never type a literal ID or brand value;
everything comes from this config, including `config.brain.mode` and, for airtable mode,
`config.brain.airtable`.

## The loop contract

Every module that produces or reads content, leads, posts, or tasks obeys this:

1. **Before producing:** read Lessons rows where `Active` = true and `Area` matches the module's area (plus
   `general`). Apply every kept lesson as a hard constraint on the output.
2. **After producing:** log one row to the matching table (Content, Leads, Posts, or Tasks).
3. **When something is killed or corrected:** write one Lessons row. Keep it an imperative rule, under 100
   characters, `Active` = true.
4. **Degrade gracefully:** if the Brain is unreachable (no local files yet, Airtable not connected, a read or
   write fails), say so in the output, skip the logging step, and never block the deliverable on a Brain
   failure.

## The schema (same columns in both modes)

### Content
| Column | Notes |
|---|---|
| Title | `<topic> (<format>)` |
| Type | post / reel / short / long-form / week-pack / blog / ad / email |
| Status | review / approved / posted |
| Body | the script, caption, or draft copy |
| Source URL | the proven piece it was modelled on, if any |
| Created | date |

### Lessons
| Column | Notes |
|---|---|
| Rule | the lesson, imperative, one line, under 100 characters |
| Area | content / seo / outreach / analytics / general |
| Active | checkbox, only Active rows are applied |
| Source | kill reason / manual / performance |
| Added | date |

### Posts
| Column | Notes |
|---|---|
| Content title | which piece went out |
| Platform | tiktok / instagram / youtube / etc |
| Posted date | date |
| Views | number |
| Likes | number |
| Comments | number |

### Leads
| Column | Notes |
|---|---|
| Company | the business name |
| Owner name | contact person |
| Channel | how they were found or reached |
| Email | contact email if known |
| Research notes | what was learned about them |
| Pain | the problem the offer solves for them |
| Opener | the drafted first line |
| Status | new / contacted / replied / booked / dead |
| Source URL | where they were found |
| Added | date |

### Tasks
| Column | Notes |
|---|---|
| Task | one line |
| Area | content / seo / outreach / analytics / general |
| Status | todo / doing / done |
| Due | date, optional |
| Notes | free text |

## Mode 1: local (default, zero dependencies)

Files live at `~/.claude/marketing-team/brain/<slug>/`:

```
~/.claude/marketing-team/brain/<slug>/
  content-log.md
  lessons.md
  posts.md
  leads.md
  tasks.md
  blog/            (blog drafts land here when config.site.enabled is false)
```

If this folder does not exist yet, tell the user to run `/marketing-team:setup-brain` and treat the Brain as
unreachable for this run (degrade gracefully, do not block).

### Exact markdown table format

Every local Brain file is a pipe table with a fixed header row and a separator row, so every module reads and
writes it identically. Append new rows at the bottom. Never reorder or rename columns.

**content-log.md**
```
| Title | Type | Status | Body | Source URL | Created |
|---|---|---|---|---|---|
| <topic> (<format>) | post | review | <the copy> | <url or blank> | 2026-01-01 |
```

**lessons.md**
```
| Rule | Area | Active | Source | Added |
|---|---|---|---|---|
| <imperative rule, under 100 chars> | content | true | kill reason | 2026-01-01 |
```

**posts.md**
```
| Content title | Platform | Posted date | Views | Likes | Comments |
|---|---|---|---|---|---|
| <title from content-log.md> | tiktok | 2026-01-01 | 0 | 0 | 0 |
```

**leads.md**
```
| Company | Owner name | Channel | Email | Research notes | Pain | Opener | Status | Source URL | Added |
|---|---|---|---|---|---|---|---|---|---|
| <company> | <owner> | instagram | <email or blank> | <notes> | <pain point> | <opener line> | new | <url> | 2026-01-01 |
```

**tasks.md**
```
| Task | Area | Status | Due | Notes |
|---|---|---|---|---|
| <task> | content | todo | | <notes> |
```

To read: parse the pipe table, skip the header and separator rows, filter as needed (e.g. `Active` = true and
`Area` in the module's set). To write: append one new row to the bottom of the table in the same format.
Never touch the header or separator rows.

Multiline text (a script or a week of captions) breaks a pipe table. When writing a cell: replace every
newline with `<br>` and every `|` with `\|`. When reading a cell back: reverse it. If the body is longer than
about 500 characters, save it instead as `content/<kebab-title>.md` next to the tables and put that relative
path in the Body cell.

**One writer at a time.** Local mode has no locking. Do a fresh read of a file immediately before appending
to it, and do not run two commands that write the same Brain in parallel. If a read shows the file changed
since you planned the work (for example a new Active lesson appeared), apply the new state before writing.

## Mode 2: airtable

IDs are read from `config.brain.airtable` at run time (`baseId` and a `tables` map with the table IDs for
Content, Lessons, Posts, Leads, Tasks). Never hardcode an ID; always read it from the tenant config.

`/marketing-team:setup-brain` creates the buyer's OWN base via the Airtable MCP (`create_base` +
`create_table`), then writes the returned IDs back into the config. Never reference any existing base, and
never assume a base already exists.

Placeholders in examples always look like this (never a real ID):

```
baseId:  YOUR_BRAIN_BASE_ID
tables:
  content:  YOUR_CONTENT_TABLE_ID
  lessons:  YOUR_LESSONS_TABLE_ID
  posts:    YOUR_POSTS_TABLE_ID
  leads:    YOUR_LEADS_TABLE_ID
  tasks:    YOUR_TASKS_TABLE_ID
```

Reading lessons before producing (airtable mode):
1. `list_records` (or the equivalent MCP tool) on the Lessons table (`tables.lessons`), filtering `Active` =
   true and `Area` in the module's set plus `general`.
2. Apply every kept row as a hard constraint on the output.

Logging after producing (airtable mode):
1. Create one record in the matching table (`tables.content`, `tables.leads`, `tables.posts`, or
   `tables.tasks`) using the columns above. Use `typecast: true` if a select value might not already exist as
   an option.

If the Airtable MCP is not connected, or a call fails, say so in the output, skip the read or write, and fall
back to treating the module's work as ungated by lessons (never block the deliverable).

## Single source of truth

This file is the only place the Brain contract lives. Every other skill, command, and agent references it by
path (`skills/brain-loop/SKILL.md`) instead of restating the rules. If the contract changes, it changes here
once.

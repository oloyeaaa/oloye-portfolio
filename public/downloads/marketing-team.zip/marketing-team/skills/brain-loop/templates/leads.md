| Company | Owner name | Channel | Email | Research notes | Pain | Opener | Status | Source URL | Added |
|---|---|---|---|---|---|---|---|---|---|
<!-- | Riverside Bakery | Jane Miller | instagram | jane@riversidebakery.example | Family bakery, posts daily, no online ordering | Losing weekend walk-in sales to queue length | Saw your queue photo, ever thought about pre-orders before the rush | new | https://instagram.com/riversidebakery | 2026-01-05 | -->

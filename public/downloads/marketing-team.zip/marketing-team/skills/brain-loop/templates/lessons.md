| Rule | Area | Active | Source | Added |
|---|---|---|---|---|
<!-- | Never use the word "artisanal" in captions | content | true | manual | 2026-01-05 | -->

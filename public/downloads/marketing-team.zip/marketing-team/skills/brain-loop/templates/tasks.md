| Task | Area | Status | Due | Notes |
|---|---|---|---|---|
<!-- | Review this week's post pack before Friday | content | todo | 2026-01-09 | Check hooks against lessons.md first | -->

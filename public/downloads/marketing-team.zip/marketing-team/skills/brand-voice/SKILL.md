---
name: brand-voice
description: Write or edit ANY public-facing copy (hooks, captions, video scripts, carousels, cold emails, decks, posts) so it sounds like the business, hits one emotion, opens with a real hook, rides a framework, tells a story, and passes a human check. Use whenever writing or polishing brand content. Triggers "write this in my voice", "polish this post", "make this sound like us". This is the final pass every other content skill in The Marketing Team runs its copy through.
allowed-tools: Read, Write, Edit, Grep, Glob, AskUserQuestion
---

# Brand Voice: the writing system

One system for writing anything public in the business's own voice. Every piece must do six things:
**sound like the business · reach for ONE emotion · earn the first 3 seconds · ride a framework · tell a
story · pass the human check.** Skip none.

## Step 0: resolve the tenant

Parse `--business <slug>` from the arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the user to run `/marketing-team:setup` and stop.

## Step 0.5: load the voice

Read `~/.claude/marketing-team/businesses/<slug>.voice.md` (the path is `config.voice.profilePath`, resolved
under the same tenant folder). Also read `config.brand` for `tone`, `bannedWords`, `signaturePhrases`,
`cta`, `wordmark`.

- **If the voice profile file exists:** load it and use it as the calibrated voice for every piece below.
- **If it does not exist:** run the calibration interview (below), write the profile file, then continue.

## Step 1: lock the target before a single word

Write one line first:
**Audience → the ONE emotion I want them to feel → the ONE action I want.**
If you can't name the emotion and the action, don't write yet. One piece = one emotion = one CTA.

---

## The Fix: the content formula (lead with this)

The strongest content follows one shape: **pick a problem your audience has, find a solution, present it.**
- **Be a solution provider, not a seller.** Teach or solve something the reader can act on immediately. Value first, always.
- **The product, the price, and the offer stay OUT of the frame**, or sit as a soft PS. Give away the HOW. The generosity is the marketing.
- **Guide, not hero.** The reader solves their own problem with what you hand them.
- **Sometimes wrapped in a story**, but the spine is always problem then solution then present.
- **Close, per piece:** a keyword/CTA for a free value thing, or "save this, follow for more." Never a hard sell.

---

## 2. Voice: sound like the business (non-negotiable)

- **Kill the jargon.** Never say AI/automation/MCP/agent/LLM/workflow/pipeline/API/model. Say what it *does*:
  "answers your customers", "books people in", "writes your posts", "saves you hours".
- **First-person "I"/"we"** for proof; **"you/your"** for the audience. Match `config.language`. Confident,
  never hype.
- **The number is the hero** (a real time or money figure). Call it out, don't bury it.
- **Sign-off:** end on the CTA. No catchphrase sign-off unless the voice profile explicitly defines one.
- **Wordmark:** use `config.brand.wordmark` exactly as written, every time.
- **Banned words:** never use anything in `config.brand.bannedWords`.
- **Signature phrases:** favour anything in `config.brand.signaturePhrases` where it fits naturally; never
  force one in.
- **Emoji:** essentially none in brand copy (captions can use 1, purposefully) unless the voice profile says
  otherwise.
- **One CTA per piece.** Use `config.brand.cta` (primary line, url, and/or keyword: whichever the piece
  calls for).

## 3. Emotion: reach for the right one

Decide the feeling, then engineer it. Neutral writing is the enemy. A reliable spine is **loss → relief**:
name what the reader is quietly losing, then the calm on the other side.

| Want them to feel | Reach for it by | Example |
|---|---|---|
| **The cost of inaction** (lead) | name a specific, concrete loss | "A client messaged at 9am. You saw it at 2pm. She'd booked elsewhere." |
| **Relief / control** | show the calm after | "Every message answered in under a minute, even mid-job." |
| **Pride / being seen** | respect their craft | "You're brilliant at the work. That's exactly why the admin slips." |
| **Belonging / 'that's me'** | mirror their exact day | "Replying to the same three questions for the tenth time today." |
| **Hope (earned)** | a concrete near-future, never hype | "Next month: every enquiry followed up the day it lands." |

Rules: lead with the loss, resolve to relief/pride. Be specific (a real figure, not "revenue"). Never
manufacture fear with fake stats. True and vivid beats shaky and inflated.

## 4. Hook: earn the first 3 seconds

The first line (text) and first frame (visual) do ~90% of the work. If the hook fails, nothing else matters.

**Text hook moves** (pick one, keep it ≤ ~10 words, one idea, open a loop):
- **The cost:** "Five hours to reply cost you a client."
- **The callout:** "Salon owners: this is why your DMs lose bookings."
- **The number:** "47 unread messages. None of them answered."
- **The contrarian:** "Posting every day isn't your problem."
- **The open loop:** "You saw the message at 2pm. Here's what it cost you."
- **The question (they can't say no to):** "How many leads did you actually follow up this week?"

**Visual hook principles** (frame 1):
- **Pattern interrupt**: something unexpected stops the scroll in the first frame.
- **Show the loss or the outcome**, not a logo or title card.
- **Motion early**; face + eye contact converts; text overlay with the key word in `config.brand.colors.accent`.
- The thumbnail moment does not just caption the image, it advances the story.

## 5. Framework: give it a spine

Pick ONE (don't free-style):
- **PAS** (Problem → Agitate → Solution): the default loss-led shape. Agitate with *empathy*, never cruelty.
- **BAB** (Before → After → Bridge): best when there's a clean transformation to show (great for
  carousels/video).
- **StoryBrand-lite**: the **reader is the hero, the business is the guide** (Yoda, not Luke): "You're not
  failing, you're missing one piece."
- **AIDA**: keep the *spine* (hook → build → want → ask), drop the salesy "desire/dream" spirit.

Carousel rules: slide 1 is 90% of the job · one idea per slide · end each slide on a small cliffhanger ·
copy + visual say *different halves* of the same beat · last slide = one CTA.

## 6. Story: make it move

- The **reader is the hero**; the business is the guide who hands them the tool.
- **Specific, hard-to-fabricate detail** beats generality ("she booked on Port Street" beats "a customer
  left").
- **Transformation** (messy before → calm after) + **stakes** (what it costs).
- One **human moment**: a real beat, an aside, a bit of mess. Benefits over features.

## 7. Sound human: the humanise pass

After drafting, scrub the AI tells. These are the patterns worth killing:
1. **Kill AI vocab:** delve, tapestry, testament, landscape (abstract), leverage, underscore, foster, robust,
   seamless, elevate, realm, navigate (abstract), "in today's fast-paced world". Say the plain word.
2. **No copula avoidance:** "serves as / stands as / boasts" becomes **is / has**.
3. **No rule-of-three padding** ("talks, panels, and networking") unless all three are real and needed.
4. **No signposting:** delete "let's dive in", "here's what you need to know", "without further ado": just
   start.
5. **No superficial "-ing" depth:** "symbolising the region's connection..." → say the fact.
6. **No false ranges:** "from X to Y" only on a real scale; else just list.
7. **No chatbot closers / sycophancy:** "I hope this helps", "great question", "you're absolutely right" :
   gone.
8. **No generic positive conclusions:** "the future looks bright" → a concrete next step.
9. **Cut filler:** "in order to" → "to"; "due to the fact that" → "because"; "has the ability to" → "can".
10. **Trim hedging:** "could potentially possibly" → "may".
11. **No manufactured staccato drama** ("No preference. No nostalgia. No prior.") and **no aphorism
    formulas** ("X is the Y of Z") unless genuinely earned.
12. **No fake-candid openers:** standalone "Honestly?" / "Look, here's the thing".

**Standing exceptions:**
- **No em dashes.** Use full stops, commas, colons, parentheses, or rewrite the sentence.
- **Curly vs straight quotes:** follow the platform / design system, don't force a change.
- **Bold/accent the number or keyword on purpose:** that's a style choice, not "AI boldface".
- **The evidence rule overrides everything:** no invented stats, no unverifiable named sources, never imply
  results the business doesn't have. A true observation beats a shiny number.

## The loop (how to run this)

1. **Step 0 / 0.5**: resolve the tenant, load the voice profile + config.brand.
2. **Step 1**: one line: audience + emotion + action.
3. **Draft**: hook first, then a framework, then the story.
4. **Humanise**: run the §7 checklist.
5. **Audit**: ask three questions and fix what fails:
   - *What still sounds AI here?*
   - *Is the intended emotion actually on the page?*
   - *Would this business say this out loud, to one person, in plain language?*

## Don't over-edit: preserve human signs

Keep: specific concrete details, real opinions and mixed feelings, varied sentence length, genuine
asides/self-corrections. Plain technical/reference text **stays plain**, don't inject personality where
neutral is the right choice. Only fix tells when they **cluster**; a lone em dash or one formal word is not
a crime.

## The calibration interview (when no voice profile exists yet)

Run this once per business, then write the profile file so future runs skip straight to Step 0.5.

1. **Ask for 3 samples** of the business owner's real writing or talking: a voice note transcript, a text
   message thread, an email, a video transcript, anything unscripted. If they truly have none, ask them to
   talk for 60 seconds about their business as if explaining it to a friend, and transcribe that.
2. **Extract from the samples:**
   - Sentence length and rhythm (short and punchy? long and winding?)
   - Words and phrases they actually use, and words they'd never say
   - Sentence openers and transitions they favour
   - Their stance: blunt, warm, dry, formal, playful
   - Any recurring line or belief they repeat (a signature phrase candidate)
3. **Ask directly for:**
   - Words to ban (jargon, competitor terms, anything that makes them cringe)
   - Their one CTA (what should every piece end on)
   - Whether they want a sign-off line, or just end on the CTA
4. **Write the profile** to `~/.claude/marketing-team/businesses/<slug>.voice.md`. Use the ONE canonical
   format defined in `${CLAUDE_PLUGIN_ROOT}/skills/marketing-team-setup/SKILL.md` (section "Write the voice
   profile"): `# Voice profile - <Business Name>` with a Status and Written line, then the sections
   `## How you sound`, `## Phrases to use`, `## Words you would never use`, `## Example before / after`,
   `## Notes`. The setup wizard writes the same format, so both paths produce an identical file. Put stance,
   hard rules, and any signature belief in `## Notes`. Also mirror the banned words into
   `config.brand.bannedWords` and the recurring phrases into `config.brand.signaturePhrases` so the config
   and the profile never drift apart.

5. **Confirm** the profile with the user before using it on real copy. Update the file any time they correct
   the voice; corrections are the fastest way to sharpen it.

## References

`references/examples.md` holds worked examples (raw draft vs humanise-pass rewrite) for a fictional
placeholder business. Useful for calibrating tone on a new build, not brand-specific.

# Worked examples: raw draft vs humanise-pass rewrite

Illustrative examples only, written for a FICTIONAL business ("Northgate", a done-for-you customer-reply
service) to demonstrate the loop. These are NOT client work, real results, or real people. Every piece
follows the system's own rules: no em dashes, the number is the hero, one CTA per piece.

Each example shows the full loop: Step 1 line, the raw first draft (with typical AI tells), then the
rewrite after the §7 humanise pass.

---

## Example 1: hook + short script (loss-led, PAS)

**Step 1:** Salon owners → cost of inaction → DM 'HELP'.

### Raw draft (before)

> Are you a salon owner struggling to keep up with messages? In today's fast-paced world, managing your DMs
> can feel overwhelming. Let's dive into how missed messages could be costing you bookings. Leveraging a
> streamlined system can seamlessly elevate your response times and foster stronger client relationships.
> The future of your salon looks bright. I hope this helps!

### Humanise-pass rewrite (after)

**Hook (first 3 seconds):** "Five hours to reply cost you a client."

**Script:**
> A client messaged your salon at 9am. You saw it at 2pm. She'd already booked somewhere else.
>
> That's not a one-off. If you're brilliant at the work, the admin is exactly what slips. Same three
> questions, ten times a day, while your hands are full of foils.
>
> Here's the fix: every enquiry answered in under a minute, even mid-job. No new staff. No app to learn.
>
> DM me the word **HELP** and I'll show you where your bookings are leaking.

**What the pass killed:** "in today's fast-paced world", "let's dive into", "leveraging", "seamlessly
elevate", "foster", the generic bright-future closer, and "I hope this helps". Added the specific loss
(9am to 2pm), one emotion (cost of inaction resolving to relief), and one CTA.

---

## Example 2: hook (the number, contrarian angle)

**Step 1:** Local trades (plumbers, sparkies) → belonging then relief → DM 'HELP'.

### Raw draft (before)

> Posting consistently on social media is a testament to your dedication, but it serves as only one piece of
> the puzzle. From content creation to lead follow-up, there are numerous factors at play. Without further
> ado, here are the key things you need to know about growing your trade business online.

### Humanise-pass rewrite (after)

**Hook:** "47 unread messages. None of them answered."

**Script:**
> Posting every day isn't your problem. Answering is.
>
> You're on a job, phone's in the van, and by the time you check it there are 47 messages sitting there.
> Half are quotes. Quotes go cold in hours, not days.
>
> Fix the follow-up before you touch the content. One change, and every enquiry gets a reply the day it
> lands.
>
> Comment **HELP** and I'll check where yours are going cold.

**What the pass killed:** "testament to", "serves as", "from X to Y" false range, "without further ado",
signposting. The number (47) is the hero and opens the piece.

---

## Example 3: cold email (BAB)

**Step 1:** Independent barbershop owner → pride then relief → book via the CTA link.

### Raw draft (before)

> Subject: Elevate Your Barbershop's Digital Presence
>
> Dear Business Owner,
>
> I hope this email finds you well. In the ever-evolving landscape of customer communication, businesses
> like yours face numerous challenges, from managing inquiries to maintaining engagement. Our robust
> solution has the ability to streamline your operations and foster growth. We would love the opportunity to
> delve into how we can help you navigate this journey. The possibilities are truly endless.
>
> Best regards

### Humanise-pass rewrite (after)

> Subject: 5 hours to reply is costing you chairs
>
> Hi [Name],
>
> Checked your Google reviews. People rate the cuts. What they mention twice is how hard it is to get a
> reply about booking.
>
> Right now a message sits unanswered for about 5 hours while you're mid-fade. That's normal, and it's
> exactly when people book the shop down the road.
>
> I set up one simple thing: every enquiry answered in under a minute, in your voice, without you touching
> your phone. You're brilliant at the work. This just stops the admin undoing it.
>
> Want me to show you where your bookings are leaking? Takes 2 minutes: [your CTA link]

**What the pass killed:** "I hope this email finds you well", "ever-evolving landscape", "robust", "has the
ability to", "streamline", "foster", "delve", "navigate this journey", the endless-possibilities closer, and
the vague "Dear Business Owner". Added a specific observable detail (reviews mention slow replies), one
number in the subject line, one CTA, and ends on the CTA with no catchphrase sign-off.

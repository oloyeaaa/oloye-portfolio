---
name: lead-magnet
description: Turn any owned IP (a skill, framework, checklist, or topic) into a branded, sendable lead magnet (a short PDF) in minutes, with a promo caption and a delivery method. Use when the user says "give away X", "make a lead magnet", "turn this into a freebie/download/guide/cheat sheet".
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---

> **Advanced skill - requires setup.** This skill uses external tools that are NOT part of the no-terminal core: Node.js (for the PDF render). It will not
> run on a machine without them. Run `/marketing-team:doctor` first to check this computer and get the install
> steps. The core marketing team (content, blog, outreach, analytics, Brain) needs none of this.

## Preflight (do this first)
Confirm the required tools are available (Node.js (for the PDF render)). If any is missing, tell the buyer exactly what to install,
or point them to `/marketing-team:doctor`, and STOP. Do not proceed into a cryptic tool error.

# Lead Magnet builder

Goal: turn "give away X" into a branded PDF a prospect actually wants, plus the caption to promote it and
the way to deliver it. Fast, repeatable, on brand. This is how a business's own IP becomes list-building
fuel.

## When to use

"give away", "lead magnet", "freebie", "downloadable", "make X into a guide / cheat sheet / one-pager".

## Step 0: resolve the tenant

Parse `--business <slug>` from the arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the user to run `/marketing-team:setup` and stop.

## Requirements

- **Node** with **`playwright-core`** and a Chromium build (the one Playwright installs on first use).
  Override the browser path with the `CHROME` env var if needed.
- **Internet at render time**: the template loads Google Fonts (Space Grotesk + Inter).
- The **`brand-voice`** skill (all copy goes through it).
- `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md` for the Brain logging step. If the Brain is
  unreachable, skip logging and say so; never block the deliverable.

## Inputs (only ask if unclear)

- **Which IP or topic** (e.g. a checklist, a framework, a short guide).
- **ICP:** default to `config.brand.audience`.
- **The ONE outcome** the magnet delivers. The title is the promise, not the topic.

## Rules (non-negotiable)

- **Speak from the Brain.** Follow `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`: read Active Lessons
  where Area = `content` (plus `general`) before writing, apply them as hard constraints; the "Log to the
  Brain" step below is the memory half (Type = `lead-magnet`).
- Write all copy with the **`brand-voice`** skill. **NO em dashes.** Result-led: time saved or money made,
  whatever the business's real outcome is.
- **Brand tokens from config:** `config.brand.colors.accent` for the accent colour, `config.brand.wordmark`
  for the wordmark text (rendered with the accent colour on the trailing mark if the wordmark ends in a
  punctuation character, otherwise plain). Fonts stay Space Grotesk + Inter (template default), base
  `#0E0F12`, paper `#F5F6F7` unless the business config sets its own.
- **Cover image is OPTIONAL.** If `config.brand` points at an image path the business owns, copy it into the
  magnet folder as `cover.jpg` and use the `cover has-photo` variant. If no image is configured, use the
  `cover no-photo` variant (clean typographic cover, never ship empty space at the top waiting for a photo
  that isn't there).
- **Evidence rule:** nothing invented. Real, usable value only. If a number is cited it must be true and
  sourced.
- **CTA from `config.brand.cta`.** If `config.brand.cta.keyword` is set, use the keyword pill ("Comment
  `<keyword>`"). If it is empty, use the link variant (`config.brand.cta.primary` as the line,
  `config.brand.cta.url` as the link). No CTA the business didn't configure.
- **ONE wordmark per page** (top-left only). No second/sign-off wordmark at the bottom of any page.
- **Genuinely useful and tight.** One value page if it can be. Never pad to look bigger.

## Process

1. **Scope it:** IP + ICP + ONE outcome. Write the one-line promise first.
2. **Pull the value** from the source IP (a skill, a note, a transcript, whatever the business names). Keep
   only what delivers the outcome. Cut the rest.
3. **Build the file:** copy `assets/template.html` into the output folder. If a cover image is configured,
   also copy it into that folder as `cover.jpg` and switch the cover `<div>` class to `cover has-photo`
   (restore the `.cover-img` / `.cover-fade` divs from the commented-out version in the template if you
   removed them). Fill the `[BRACKETS]`: cover (eyebrow + title + subtitle), one or more value pages, CTA
   page. Do not restyle it. Add a value page by duplicating a `.page.paper` block.
4. **Render** (paths relative to the skill folder, or use absolute paths):
   - PDF (the deliverable): `node ${CLAUDE_PLUGIN_ROOT}/skills/lead-magnet/scripts/render.cjs "<path>/<slug>.html" "<path>/<slug>.pdf" --pdf`
   - PNG preview to check it: `node ${CLAUDE_PLUGIN_ROOT}/skills/lead-magnet/scripts/render.cjs "<path>/<slug>.html" "<path>/<slug>.png" --full --width 800`
   - Read the PNG. Confirm it fits each A4 page, reads cleanly, and has zero em dashes.
5. **Promote + deliver:** write a short promo caption (`brand-voice`) and pick ONE delivery method (below).
   State it.
6. **Log to the Brain:** follow `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md` and add one Content row
   (Title = the magnet title, Type = `lead-magnet`, Status = `review`, Body = the promo caption, Source URL =
   the file path, Created = today). **If the Brain is unreachable:** print the row as text so the user can
   log it manually, and say the log was not written.
7. **Output:** the PDF path, the PNG preview, the caption, and the delivery method.

## Output location

`~/.claude/marketing-team/brain/<slug>/lead-magnets/<kebab-slug>/`

## Template

`assets/template.html` is the branded A4 scaffold: typographic or photo cover, paper value pages, dark CTA.
Duplicate and fill the `[BRACKETS]`. Keep the styling fixed for brand consistency. It is multi-page (each
`.page` is one A4 sheet); add or remove value pages as the content needs.

## Delivery options (pick one and say which)

- **Comment keyword auto-reply** (if `config.brand.cta.keyword` is set): send the PDF when someone comments
  the keyword on the relevant post.
- **Direct attach** in DMs, WhatsApp, or email.
- **Link delivery** (if no keyword is configured): the CTA link points to wherever the business hosts the
  download.

## Good lead-magnet checklist (before shipping)

- The title is a promise, not a topic.
- A stranger gets one real win in under 5 minutes of reading.
- It sounds like the business (brand-voice), zero em dashes.
- Cover has a photo only if one is configured; otherwise a clean typographic cover, no empty space.
- CTA matches `config.brand.cta` exactly. One wordmark per page.
- Branded: wordmark, accent colour, consistent fonts. Looks premium.

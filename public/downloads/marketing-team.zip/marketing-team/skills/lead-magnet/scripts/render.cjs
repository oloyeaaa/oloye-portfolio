#!/usr/bin/env node
/*
 * HTML -> PNG (element screenshot) or PDF renderer used by the lead-magnet skill.
 *
 * Usage:
 *   node render.cjs <input.html> <output.(png|pdf)> [options]
 *   node render.cjs --all <dir> [options]        # every *.html in dir -> same-name output
 *
 * Options:
 *   --selector <sel>   element to screenshot for PNG (default ".frame")
 *   --full             full-page screenshot instead of an element
 *   --pdf              PDF mode (also auto-on if output ends with .pdf)
 *   --scale <n>        deviceScaleFactor for PNG (default 2)
 *   --width <n>        viewport width (default 1080)
 *   --height <n>       viewport height (default 1920)
 *
 * Requires Node with playwright-core and a local Chromium install (the one Playwright installs
 * on first use, or set CHROME to an explicit chrome.exe / chrome binary path).
 */
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright-core');

function findChrome() {
  if (process.env.CHROME) return process.env.CHROME;
  const base = path.join(process.env.LOCALAPPDATA || process.env.HOME || '', 'ms-playwright');
  try {
    const dirs = fs.readdirSync(base).filter((d) => /^chromium-\d+$/.test(d)).sort((a, b) => Number(b.split('-')[1]) - Number(a.split('-')[1]));
    for (const d of dirs) {
      const candidates = [
        path.join(base, d, 'chrome-win64', 'chrome.exe'),
        path.join(base, d, 'chrome-linux', 'chrome'),
        path.join(base, d, 'chrome-mac', 'Chromium.app', 'Contents', 'MacOS', 'Chromium'),
      ];
      for (const exe of candidates) if (fs.existsSync(exe)) return exe;
    }
  } catch {}
  return undefined; // let Playwright fall back to its own bundled Chromium
}
const CHROME = findChrome();

function arg(name, def) {
  const i = process.argv.indexOf(name);
  return i !== -1 ? (process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true) : def;
}

(async () => {
  const all = arg('--all', null);
  const selector = arg('--selector', '.frame');
  const full = process.argv.includes('--full');
  const transparent = process.argv.includes('--transparent');
  const scale = Number(arg('--scale', 2));
  const width = Number(arg('--width', 1080));
  const height = Number(arg('--height', 1920));

  // collect jobs: [{html, out, pdf}]
  const jobs = [];
  if (all) {
    const dir = path.resolve(all);
    const pdf = process.argv.includes('--pdf');
    for (const f of fs.readdirSync(dir).filter((f) => f.endsWith('.html'))) {
      jobs.push({ html: path.join(dir, f), out: path.join(dir, f.replace(/\.html$/, pdf ? '.pdf' : '.png')), pdf });
    }
  } else {
    const input = process.argv[2];
    const output = process.argv[3];
    if (!input || !output || input.startsWith('--')) {
      console.error('Usage: node render.cjs <input.html> <output.(png|pdf)> [options]  |  --all <dir> [options]');
      process.exit(1);
    }
    const pdf = process.argv.includes('--pdf') || output.toLowerCase().endsWith('.pdf');
    jobs.push({ html: path.resolve(input), out: path.resolve(output), pdf });
  }

  const browser = await chromium.launch(CHROME ? { executablePath: CHROME } : {});
  const page = await browser.newPage({ viewport: { width, height }, deviceScaleFactor: scale });
  for (const j of jobs) {
    await page.goto('file:///' + j.html.split(path.sep).join('/'), { waitUntil: 'networkidle' });
    try { await page.evaluate(() => document.fonts.ready); } catch {}
    await page.waitForTimeout(600);
    fs.mkdirSync(path.dirname(j.out), { recursive: true });
    if (j.pdf) {
      await page.pdf({ path: j.out, printBackground: true, preferCSSPageSize: true });
    } else if (full) {
      await page.screenshot({ path: j.out, fullPage: true, omitBackground: transparent });
    } else {
      const el = await page.$(selector);
      if (!el) throw new Error(`selector "${selector}" not found in ${j.html}`);
      await el.screenshot({ path: j.out, omitBackground: transparent });
    }
    console.log('rendered', path.basename(j.out));
  }
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });

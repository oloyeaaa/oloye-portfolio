---
name: marketing-team-setup
description: The install wizard for The Marketing Team. Interviews a new buyer on their business, calibrates their writing voice, and writes their tenant config and voice profile. Use whenever a buyer runs /marketing-team:setup, says "set up my marketing team", "get started", "install", or has no config file yet at ~/.claude/marketing-team/businesses/<slug>.json.
allowed-tools: Read, Write, Edit, Grep, Glob, AskUserQuestion
---

# Marketing Team setup wizard

This is the whole install story. A stranger with Claude Code and no context should finish this wizard with a
working config, a calibrated voice profile, and (ideally) a first week of posts in hand, in under an hour.

Do this as a conversation, not a form dump. Ask a few questions at a time, confirm what you heard, move on.
Never invent an answer on the buyer's behalf. If they skip something, write a sensible placeholder and say so.

**How to ask (hard rule).** Whenever a question has answers you can enumerate (a choice, a yes/no, a
pick-several), ask it with the AskUserQuestion tool so the buyer gets an interactive popup with options to
tap, not a wall of chat text. Batch related choices into one call (up to 4 questions per popup), use
`multiSelect` where several answers can be true (channels), and rely on the built-in "Other" option for
anything you did not list. Keep genuinely open-ended asks (their business name, their one-liner, pasted
writing samples) as plain chat questions; never force free text through a fake option list. Each step below
says which mode it uses.

## Step 0 - check for an existing setup

Read `~/.claude/marketing-team/config.json`. If it already has a `defaultBusiness` and
`~/.claude/marketing-team/businesses/<slug>.json` exists, tell the buyer they already have a team set up for
that business, show the display name, and ask what to do as an AskUserQuestion popup with options
"Reconfigure it", "Add a second business", and "Leave it as it is". Do not overwrite an existing config
without a clear yes.

## a. Welcome

Open with one short paragraph, plain language, no jargon:

> The Marketing Team gives your business a working marketing department inside Claude Code. A manager keeps
> things moving, a writer handles your posts and blog, an outreach lead finds and messages new prospects, and
> a weekly review looks at what worked. Everyone shares one Brain, so a correction you make today gets
> remembered next week. This setup takes about 20-30 minutes and ends with your first piece of content ready
> to post.

## b. Business basics interview

Two passes. **Pass one, plain chat:** ask for the open-ended facts in one short message: business name, the
one-liner (what you sell and to whom), the main offer, and the audience (items 1-4 below). **Pass two, one
AskUserQuestion popup** with up to 4 questions: region (options: UK, US, EU, Other), channels used today
(`multiSelect: true`; options: TikTok, Instagram, YouTube, Facebook — "Other" catches LinkedIn etc), and the
primary CTA action (options: book a call, message us, visit the site, comment a keyword). Follow up in chat
only for the CTA's URL and keyword if they picked one.

Ask for (the full list being gathered):

1. **Business name** (becomes `displayName`; slug = kebab-case of it, e.g. "Corner Bloom Florist" →
   `corner-bloom-florist`).
2. **One-liner**: what you sell, and to whom, in one plain sentence → `brand.oneLiner`.
3. **Main offer**: the thing you most want to sell right now → `brand.productName`.
4. **Audience**: who you serve, one line → `brand.audience`.
5. **Region**: sets `region`, `language` (British English for UK/Ireland, US English for the US, plain English
   otherwise - ask if genuinely unclear), and the default `outreach.complianceMode` (`uk-pecr` for UK,
   `eu-gdpr` for EU, `us-can-spam` for US, `manual` for anywhere else - tell them this is a default, not legal
   advice, and they can change it).
6. **Channels used today**: which platforms they actually post on or want to → `channels.primary` (array,
   lowercase: tiktok, instagram, youtube, linkedin, facebook, etc).
7. **Primary CTA**: what should every piece of content ask people to do? Get the action (e.g. "book a call",
   "message us", "visit the site"), the URL, and, if they want a comment-to-get-it giveaway mechanic, a
   keyword → `brand.cta.primary`, `brand.cta.url`, `brand.cta.keyword` (leave blank if they don't want one).

Confirm the summary back in a few lines before moving on.

## c. Voice calibration

Explain in one line: "Now I'll learn how you actually sound, so nothing this team writes sounds like a
robot." This reuses the same calibration method as the brand's own voice system, genericised for any buyer.

**Open with one AskUserQuestion popup**: "How should I learn your voice?" with options "Paste real posts or
messages I've written (Recommended)" and "Ask me 5 quick questions instead". The samples themselves and the
quickfire answers are always plain chat; never put them behind options.

**If they choose samples, ask for 2-3 real ones.** Any of:
- A few real social posts or captions they've written
- A couple of real emails or messages to customers
- A voice-note transcript (paste the text, or dictate and let them paste it)

If they provide samples, extract and write up:
- **Sentence length and rhythm**: short and punchy, or longer and conversational?
- **Energy**: calm and plain, upbeat, blunt, warm, formal?
- **Phrases they actually use**: real recurring words or turns of phrase, quoted directly from the samples.
- **Words they would never use**: jargon, corporate phrases, or tone that doesn't fit, either named by the
  buyer or obviously absent/avoided across the samples.

**If they have no samples**, run this 5-question quickfire instead, one at a time:
1. "How would you tell a mate what your business does, in one breath?"
2. "What annoys you about ads or marketing in your industry?"
3. "What's a phrase you say all the time when you're talking about the business?"
4. "If a customer asked you a question right now, how would you actually reply, word for word?"
5. "What's one word or phrase you'd never want your business to sound like it's saying?"

Use their real answers as the sample text and mark the resulting profile **"draft, refine after first
week"** in the header.

### Write the voice profile

Write `~/.claude/marketing-team/businesses/<slug>.voice.md` in this format:

```markdown
# Voice profile - <Business Name>

Status: <calibrated from real samples | draft, refine after first week>
Written: <date>

## How you sound
- Sentence length: <short and direct | longer, conversational | mixed>
- Energy: <e.g. calm and plain, upbeat, blunt and confident, warm>
- Formality: <casual | plain professional | formal>

## Phrases to use
- "<real phrase 1>"
- "<real phrase 2>"
- "<real phrase 3>"

## Words you would never use
- <banned word/phrase 1>
- <banned word/phrase 2>

## Example before / after
**Generic AI version:** "<a bland, jargon-y sentence about the business>"
**In your voice:** "<the same idea, rewritten in the calibrated voice>"

## Notes
<any other calibration notes, e.g. always leads with a number, never uses emoji, always ends on the CTA>
```

Every piece of public copy this team produces gets checked against this file (via `skills/brand-voice`).
This format is the ONE canonical voice profile shape; `skills/brand-voice` writes the same format when it
calibrates a voice outside setup.

**Mirror the voice into the config.** From the calibration, also fill these config fields so the config and
the profile never drift apart:
- `brand.tone`: 2-4 plain words from "How you sound" (e.g. `["short", "warm", "plain"]`).
- `brand.bannedWords`: the "Words you would never use" list (replace the template's placeholder examples).
- `brand.signaturePhrases`: the "Phrases to use" list.
- `brand.colors.accent`: ask once, "Got a brand colour? Give me the hex if you know it, or skip." Keep the
  template default if skipped.

## d. Write the tenant files

1. Copy `${CLAUDE_PLUGIN_ROOT}/skills/marketing-team-setup/templates/business.template.json` to
   `~/.claude/marketing-team/businesses/<slug>.json` and fill in every field gathered above. Leave any
   not-yet-configured module (`site`, `outreach`) at its template defaults (`enabled: false`) unless the buyer
   opts in during step e below. Set `voice.profilePath` to `<slug>.voice.md` and `lastUpdated` to today.
2. Create or update `~/.claude/marketing-team/config.json`:
   ```json
   { "defaultBusiness": "<slug>" }
   ```
   If this is a second business for the same buyer, keep the existing `defaultBusiness` unless they ask to
   switch it, and just make sure the new `businesses/<slug>.json` exists.

Confirm both files were written and tell the buyer exactly where they live.

## e. Optional module switches

Ask these as **one AskUserQuestion popup** (4 questions: outreach yes/no, site/blog "publish to my site" /
"save drafts for me", scheduler "Metricool" / "I post by hand", team names "name them" / "keep it simple").
Follow up in plain chat only where a yes needs details (the outreach ICP and offer, the site paths, the
chosen names). Buyer can skip any and turn it on later by rerunning setup or editing the config:

**Outreach.** "Do you want this team finding and messaging new prospects for you?" If yes:
- Set `outreach.enabled = true`.
- `outreach.icp`: who they want to reach, one line.
- `outreach.offer`: the low-pressure first ask (e.g. "a free quick rundown").
- `outreach.complianceMode`: confirm the region-based default from step b, or let them change it
  (`uk-pecr`, `eu-gdpr`, `us-can-spam`, `manual`). Tell them plainly this is a default, not legal advice.

**Site / blog.** "Do you have a website where you want blog posts published automatically, or should drafts
just be saved for you to paste in yourself?" If they have a repo:
- `site.enabled = true`, and collect `site.domain`, `site.blogBasePath`, `site.repoPath` (a local path on
  their machine), `site.imagesBlogPath`, `site.gitRemote`, `site.gitBranch`.
- If not, leave `site.enabled = false`. Blog drafts land in `~/.claude/marketing-team/brain/<slug>/blog/`
  instead, and that's completely fine, tell them so.

**Scheduler.** "Do you use Metricool to schedule posts, or do you post by hand?" Set `channels.scheduler` to
`metricool` (only if the Metricool MCP is connected, otherwise say it isn't connected yet and default to
`none`) or `none`.

**Name your team (optional).** "Want to give your team members names, or keep it simple as 'the manager',
'the writer', and so on?" If they want names, fill in `team.manager`, `team.writer`, `team.outreach`,
`team.analyst` with whatever they choose. Otherwise leave the template defaults (`the manager`, `the writer`,
`the outreach lead`, `the analyst`). These names are used anywhere the team refers to itself in chat.

Save the updated config after this step.

## f. Offer the Brain

Explain in one line: "Your team needs somewhere to remember things, a shared Brain." Then ask as an
AskUserQuestion popup: "Set up your team's memory now?" with options "Yes, local files (Recommended, no
accounts needed)", "Yes, my own Airtable base", and "Later". On a yes, hand off to the
`/marketing-team:setup-brain` flow with their choice. If they say later, note
that every module degrades gracefully without a Brain, it just won't remember anything between runs yet.

## g. Offer the first content run

Ask as an AskUserQuestion popup: "Want to see this working right now?" with options "Yes, turn one idea into
a week of posts (Recommended)" and "I'll try it myself later". If yes, take one idea from the interview
(their main offer, or something they mentioned) and run the `week-of-posts` skill with it. Show the result
in chat.

## Close

End with a short, plain summary:

```
You're set up. Here's what runs day to day:

Daily:  /marketing-team:daily-brief   - a short brief on what needs attention today
Weekly: /marketing-team:weekly-review - checks what's working, what to change
        /marketing-team:standup       - makes the week's content and outreach

Everything lives here:
- Your settings:     ~/.claude/marketing-team/businesses/<slug>.json
- Your voice:        ~/.claude/marketing-team/businesses/<slug>.voice.md
- Your team's memory: ~/.claude/marketing-team/brain/<slug>/ (or your Airtable base)

Run /marketing-team:daily-brief any morning to see it in action.
```

If a name was set for the team in step e, use it here instead of the generic role labels.

---
name: outreach
description: Find leads, build a prospect list, and write cold openers for the business's outreach. Use for "find me leads", "build a prospect list", "write cold openers", "outreach", "who should I contact", "run outreach", "cold email".
---

# Outreach - the engine

Finds the right prospects, researches each one for real, and writes a short cold opener that earns a reply,
not a sale. Low volume and genuinely personal is the whole edge. Never invent a fact, a pain point, or a
contact detail.

## Step 0 - resolve the tenant

Parse `--business <slug>` from the arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the user to run `/marketing-team:setup` and stop.

Check gates before doing anything else:
- `config.outreach.enabled` must be `true`.
- `config.outreach.icp`, `config.outreach.offer`, and `config.outreach.complianceMode` must all be filled in.

If any gate fails, tell the buyer outreach isn't set up yet and send them to `/marketing-team:setup` (or, if
outreach is enabled but a field is blank, tell them exactly which field to fill in there). Stop, do not
proceed with placeholder values.

## Step 0.5 - load lessons and voice

Read Active Lessons where `Area` = `outreach` or `general` via `skills/brain-loop/SKILL.md`. Apply every one
as a hard constraint before writing a single opener. Also read `config.brand` (displayName, wordmark, tone,
bannedWords) - this is where sign-off and voice come from, never a name baked into this file.

## Who we're looking for (ICP)

Read `config.outreach.icp` for the verticals this business actually targets, and `config.outreach.region`
for where to search. Qualify every prospect on **observable pain**, not "do they have X":

- Enquiries/DMs answered slowly, or only in person ("DM to book")
- Missed-call / after-hours gaps
- Fiddly or missing online booking
- Patchy, inconsistent posting; the owner is clearly doing everything themselves

A specific, *observable* pain makes a better opener than a generic one. Skip chains/franchises, businesses
with an in-house marketing team, and anything with no public presence to research.

## Collect leads (web search, never invent)

Work one business type + city/area per run. For each prospect, collect:

- Business name, owner/manager name if publicly listed, their own website (confirmed, not guessed)
- **One real public email** found on their site, Google Maps listing, or socials (prefer the owner or a
  hello@/info@ address). If none exists publicly, leave Email blank and put their social handle in Channel - 
  DM is a valid route, never guess or fabricate an email.
- A one-line **pain** observation: why they're a fit, based on what you can actually see
- The **source URL**

Never invent or guess a contact detail or a fact about the business. Blank is fine; a fabricated line is not.

## Research each lead

Skim their site and socials for **one specific, true detail** to reference in the opener: a real service they
offer, a "DM to book" line, evidence of slow replies, no online booking, a recent post. One real detail you
can defend beats five guesses.

## Write the opener - the 4-line framework

Keep this framework exactly as proven. The job of the email is to earn a **reply**, not book a call.
~60-80 words, plain text, no links, no images, one ask.

- **Subject:** 2-4 words, lowercase, personal. Examples: `quick one about {business}`, `saw your reviews`,
  `{business} - missed enquiries?`. Never use "free", "AI", "grow", or "boost" in the subject.
- **Line 1 - observation:** one specific, TRUE thing about *them*. First word is about them, never "I/we".
- **Line 2 - the cost:** the pain it implies, framed as lost bookings or lost customers.
- **Line 3 - the fix, plain:** the outcome in plain words, not a feature list. Pull the actual offer wording
  from `config.outreach.offer`.
- **Line 4 - the interest CTA:** one soft, low-pressure ask for a reply, not a call booking. Use
  `config.outreach.offer` to phrase it (e.g. "happy to send a short, no-charge rundown - worth a reply?").
- **Sign-off:** `config.displayName` (plus a one-line role/description only if `config.brand` defines
  one). Never invent a persona name, and never use any sign-off not sourced from config.
- **Opt-out (required in every opener, email AND DM):** "Not relevant? Reply 'no' and I won't message again."

**DM openers** (prospects routed away from email): same four lines, same opt-out, but NO subject line, and
keep it a touch shorter since it lands in a chat window.

Never fake a detail. One specific, defensible line beats five guesses.

## Compliance - apply the section that matches `config.outreach.complianceMode`

Only apply the one section matching the buyer's configured mode. Never mix modes.

### If `complianceMode` = `uk-pecr`

- Cold email is limited to **limited companies and LLPs**. Sole traders and ordinary partnerships count as
  *individuals* under UK PECR, so they cannot be cold-emailed on this basis.
- Check Companies House (or equivalent public register) for each prospect before drafting an email. If the
  business is not registered as a Ltd or LLP, route them to DM or phone instead: set Channel to their social
  handle, leave Email blank, do not draft a cold email for them.
- Every email must carry sender identity (who's writing, what business) and the opt-out line.
- Lawful basis is legitimate interest for B2B - note this basis was used when logging the lead.

### If `complianceMode` = `eu-gdpr`

- B2B outreach relies on legitimate interest as the lawful basis.
- Every email needs clear sender identity and an easy, working opt-out.
- Honour every objection immediately and permanently - add them to the do-not-contact list the moment they
  object, no exceptions.
- **Soft warning:** member states vary in how they apply B2B email rules, and some require prior consent
  rather than allowing legitimate interest. Tell the buyer to check the specific rules for the country they're
  contacting before sending at volume.

### If `complianceMode` = `us-can-spam`

- Every email needs clear sender identity, a valid postal address, and a working opt-out that is honoured
  within 10 days of a request.
- No deceptive or misleading subject lines - the subject must reflect the actual content of the email.

### If `complianceMode` = `manual`

- Warn the buyer plainly, in the output: they must confirm the applicable local law themselves before sending
  anything from this list. This skill has not checked compliance for their jurisdiction.
- Still require the opt-out line on every email regardless of what they confirm.

## Deliverability caps (kept, non-negotiable)

- Plain text only. No links, no images, no attachments, no tracking pixels.
- 20-40 sends per day maximum.
- One contact per business. One initial email plus **at most one** follow-up, then stop.
- Ask a real question so replies come back - reply rate is the signal that keeps the sender's inbox healthy.
- Always keep and honour a do-not-contact list: anyone who has said no, or already been contacted, is skipped
  on every future run.

## Output - log to the Brain

Write one Leads row per prospect via `skills/brain-loop/SKILL.md`: Company, Owner name, Channel, Email,
Research notes, Pain, Opener, Status = `new` (the schema's first stage; a filled Opener cell is what marks
the opener as ready), Source URL, Added.

**Optional - Gmail drafts.** If the Gmail MCP is connected, offer to create a draft for each ready opener.
Drafts only, never send. If the MCP isn't connected, skip this offer and say so.

## When the buyer corrects an opener

If the buyer edits, rejects, or corrects an opener (wrong tone, wrong pain point, bad subject line, anything),
write one Lessons row via `skills/brain-loop/SKILL.md`: an imperative rule under 100 characters, `Area` =
`outreach`, `Active` = true, `Source` = the correction. Apply it on every future run.

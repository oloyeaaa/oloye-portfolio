---
name: product-ad
description: Turn a product (image or store URL) into a finished short-form video ad on the buyer's own fal.ai stack, either a CINEMATIC story ad (moody, premium, model + product + end card) or a HUMAN UGC ad (AI creator talking to camera). Builds stills with nano-banana, animates beats with Veo 3 (native audio), assembles with ffmpeg (crossfades + branded end card), then logs the real time + cost to the Brain. Use for "make an ad for this product", "UGC ad", "cinematic product ad", "turn this product into a video", "make a video ad for [brand]".
---

# Product Ad - the UGC / cinematic ad pipeline

A short-form product ad pipeline: a 20–30s cinematic or UGC-style ad in roughly 15–25 minutes, on the
buyer's own fal stack, for single-digit-to-low-double-digit dollars depending on beat count. This skill
uses the **render-room** engine for fal calls and **ffmpeg** for assembly.

## Step 0 - tenant resolution

Parse `--business <slug>` from arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If
missing, tell the user to run `/marketing-team:setup` and stop. End-card wordmark, accent colour, and
CTA all come from `config.brand` (`wordmark`, `colors.accent`, `cta.primary`) - never hardcode a brand
value.

## When to use this vs motion-design
- **product-ad** (this skill) = the fal stack: UGC and product story ads with native audio (nano-banana stills, Veo 3 animation, ffmpeg assembly).
- **motion-design** = Higgsfield motion graphics generated from a logo or product image. Use that skill for logo animations and kinetic-graphics promos.

## Log to the Brain
Follow the loop contract at `skills/brain-loop/SKILL.md`: before producing, read Active lessons
(Area=content or general) and apply them as hard constraints. After the ad is assembled and the buyer
keeps it, log one Content row: Type=`ad`, Status=`review`, Body=a short description of the ad plus the
real cost and render time (e.g. "cinematic 3-beat ad, ~$9.50, ~20 min"), Source URL=blank unless modelled
on something. Degrade gracefully if the Brain is unreachable - never block delivery on a logging failure.

## Inputs to get first
- **Product image** - a clean product shot (local path or public URL). If only a store URL, scrape it
  (Firecrawl) and pick the hero product image.
- **Brand context** - name, price, vibe. Default name/vibe/tone to `config.brand` if the user doesn't
  give one.
- **Mode** - `cinematic` (story ad) or `ugc` (human creator talking). Default to asking which.
- **Budget nod** - video gen is the paid part; Veo 3 dominates. State the estimate and confirm before paid
  steps. This spends real money on the buyer's own fal key.

## Engine + key
- fal engine: `python ${CLAUDE_PLUGIN_ROOT}/skills/render-room/render_room.py <cmd> --model <slug> ...`
- Requires: the **render-room** skill installed, Python 3, ffmpeg on PATH, and a fal.ai account.
- Key: use the `FAL_KEY` environment variable. If it is not set, ask the user where their fal key
  lives and load it into the process from there. Never echo, print, or put the key value on a
  command line.
- Parse the `@@RENDER_JSON@@` line; use `files` (local) / `urls` (fal-hosted) from it.
- Output root: `~/.claude/marketing-team/output/<slug>/product-ads/` - pass `--out` on every render_room
  call so files land in the right buyer's folder.

## Proven model slugs (verify on fal.ai/models; they drift)
- Image (stills): `fal-ai/nano-banana`  (`--arg aspect_ratio=9:16`)
- Image edit w/ product ref: `fal-ai/nano-banana/edit` - **pass `--image` TWICE** (model needs `image_urls`),
  or pass a **public URL** (local upload sometimes 403s).
- Human/talking + cinematic motion (native audio): `fal-ai/veo3/image-to-video`  (`--arg duration=8s --arg generate_audio=true`)
- Cheap product motion: `fal-ai/kling-video/v2.1/standard/image-to-video`  (`--arg duration=5`)

## MODE A - Cinematic story ad (3 beats)
1. **Beat 1 (hero):** `image` nano-banana - the model/scene (e.g. "confident subject, fitted outfit, neon rain
   street, cinematic grade, 9:16"). Show it; lock the look before animating.
2. **Beat 2 (product):** `edit` nano-banana/edit with the real product image as ref - place the EXACT product in
   a dark cinematic scene (raking light, smoke, reflection, label crisp).
3. **Beat 1 + 2 + 3 animate:** `video` veo3/image-to-video from each still. Beat 1 = confident walk (no
   dialogue, ambient). Beat 2 = slow push-in on bottle/product. Beat 3 = animate the hero again → turn-to-camera close.
4. **End card:** ffmpeg `drawtext` (see below).
5. **Assemble** with crossfades (see below).

## MODE B - Human UGC ad
1. `image` nano-banana OR `edit` (with product ref so they hold the REAL product) - a photoreal creator holding
   the product, authentic phone-selfie look ("imperfect skin, grainy phone camera, not glossy"). Less crisp = more real.
2. `video` veo3/image-to-video from that still - they talk a short line to camera (native audio). Walking or static.
3. Optional: add burned captions via ffmpeg drawtext.

## End card (ffmpeg)
Pull wordmark and CTA text from `config.brand.wordmark` and `config.brand.cta.primary`; pull the accent
colour from `config.brand.colors.accent`.
```
FONT="C\:/Windows/Fonts/georgia.ttf"
ffmpeg -y -f lavfi -i color=c=0x0A0A0A:s=720x1280:d=3.5:r=24 -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 \
 -vf "drawtext=fontfile='$FONT':text='<BRAND WORDMARK>':fontcolor=<ACCENT HEX>:fontsize=86:x=(w-text_w)/2:y=520, drawtext=fontfile='$FONT':text='<CTA / TAGLINE>':fontcolor=white:fontsize=30:x=(w-text_w)/2:y=640, fade=in:0:12" \
 -c:v libx264 -pix_fmt yuv420p -r 24 -c:a aac -shortest endcard.mp4
```

## Assemble with crossfades (ffmpeg)
All clips 720x1280 @ 24fps. Chain xfade (video) + acrossfade (audio); offset = running_length - overlap.
```
ffmpeg -y -i b1.mp4 -i b2.mp4 -i b3.mp4 -i endcard.mp4 -filter_complex \
 "[0:v]scale=720:1280,setsar=1,fps=24,format=yuv420p[v0];\
  [1:v]scale=720:1280,setsar=1,fps=24,format=yuv420p[v1];\
  [2:v]scale=720:1280,setsar=1,fps=24,format=yuv420p[v2];\
  [3:v]scale=720:1280,setsar=1,fps=24,format=yuv420p[v3];\
  [v0][v1]xfade=transition=fade:duration=0.7:offset=7.3[x1];[x1][v2]xfade=transition=fade:duration=0.7:offset=14.6[x2];\
  [x2][v3]xfade=transition=dissolve:duration=0.9:offset=21.9[v];\
  [0:a][1:a]acrossfade=d=0.7[a1];[a1][2:a]acrossfade=d=0.7[a2];[a2][3:a]acrossfade=d=0.9[a]" \
 -map "[v]" -map "[a]" -c:v libx264 -pix_fmt yuv420p -c:a aac -movflags +faststart final.mp4
```
Compute the offsets from YOUR actual clip durations (probe each with `ffprobe`), do not reuse the
example numbers blindly:
- `offset_1 = duration(clip_1) - crossfade_1`
- `offset_n = offset_(n-1) + duration(clip_n) - crossfade_n` (cumulative: each new offset adds the
  next clip's duration minus that transition's crossfade).
The 7.3 / 14.6 / 21.9 above are illustrative example values for roughly 8s beats with 0.7s fades and a
0.9s dissolve into the end card - recompute for your own clips.
Add a single music bed (replace disjointed per-beat audio): generate a track (fal/Higgsfield) and
`-stream_loop`/`amix` it under the video at low volume with an end fade.

## Cost + time (set expectations, confirm before paid)
- Veo 3 i2v (8s, audio) ≈ ~$4 each - THE cost driver, keep beats few/short.
- nano-banana still ≈ ~$0.04; Kling 5s ≈ ~$0.30.
- A 3-beat cinematic ad ≈ **~$10, ~20 min**, all illustrative. Always state the estimate and get a yes
  before video renders - this is real money on the buyer's own fal key.

## Worked example (for your own reference, adapt the numbers)
A 3-beat, 9:16, ~25s cinematic ad for a fragrance-style product: Beat 1 hero walk, Beat 2 product
push-in, Beat 3 turn-to-camera close, then the branded end card. Roughly 20 minutes end to end, low
double-digit dollars in fal spend, entirely on the buyer's own account. Use this shape as a template, not
a fixed script - the beats, mood, and cost scale with the product and the mode chosen.

## Hybrid option: a UGC service + brand-wrap (for high-volume product ads)
For high-volume PRODUCT ads you do not have to hand-build every clip on this stack. A common hybrid:
1. **Claude writes the script** from the product angle notes (stick to claims you can defend, no false claims).
2. **Run it in a UGC/dropship tool** on the right SKU (it provides the presenter + product + captions).
3. **Brand-wrap the raw export** with one command (your frame + mark + wordmark + tagline + handle + grade + end-card).
Use THIS stack (below) for branded/hero pieces the UGC tool can't do.

## FIRST: which brand is this for? (firewall)
If the buyer runs more than one brand, keep them **separate - never mix**. Declare the entity before you
build, and apply only that brand's voice, colours, and marks from its own tenant config
(`~/.claude/marketing-team/businesses/<slug>.json`).

## Apply the brand identity (use for branded content)
When making content for a specific brand, apply its identity from `config.brand`:
- **Colours:** `config.brand.colors.accent` with a sensible base/paper/accent ratio (e.g. ~60/30/10).
- **Fonts:** whatever display + body font the buyer has specified, otherwise a clean system font.
- **Wordmark + CTA:** `config.brand.wordmark` and `config.brand.cta.primary` - your own, not a template
  name.
- End-cards/captions: brand bg, accent, display headline, accent CTA pill, mark + wordmark.
- **Logo pack (use real files, not drawtext) when available:** overlay the business's real logo/mark file
  on the end-card at low opacity, bottom-right, if the buyer has one on disk.

### Branded end-card (ffmpeg - overlay a real mark)
```
BG=0x123D30; ACCENT=<config.brand.colors.accent>; PAPER=0xF5F1E8   # sub the tenant's colours
MARK="<path to the business's logo file, if they have one>"
FONT="C\:/Windows/Fonts/segoeui.ttf"           # sub their display font if installed
ffmpeg -y -f lavfi -i color=c=$BG:s=720x1280:d=3.5:r=24 -i "$MARK" \
 -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 \
 -filter_complex "[1:v]scale=220:-1[m];[0:v][m]overlay=(W-w)/2:360[bg];\
  [bg]drawtext=fontfile='$FONT':text='<tagline from config.brand>':fontcolor=$PAPER:fontsize=44:x=(w-text_w)/2:y=640,\
  drawtext=fontfile='$FONT':text='<CTA from config.brand.cta.primary>':fontcolor=$ACCENT:fontsize=26:x=(w-text_w)/2:y=720,\
  fade=in:0:12[v]" \
 -map "[v]" -map 2:a -c:v libx264 -pix_fmt yuv420p -r 24 -c:a aac -shortest endcard.mp4
```

## Quality bar
Show the product accurately; premium not "AI slop"; for human UGC make it less crisp / authentic. Tie to a
business outcome, not vanity. Honesty: no fake testimonials, no claimed client results.

## Output location
Default: `~/.claude/marketing-team/output/<slug>/product-ads/<yyyymmdd-topic>/`, with a short README
(beats, models, the final mp4, time + cost). Keep a numbered file per stage.

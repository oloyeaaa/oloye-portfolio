---
name: reel-pipeline
description: Take an Instagram reel that's already getting engagement and make your OWN version, same concept and proven format, your own content and take. Downloads the reel, transcribes it locally (Whisper), uses Claude vision to reverse-engineer it into structure (keep) vs swappable content slots (replace), asks you to fill the slots with your own picks/opinions, then writes the script in YOUR voice with 3 hook options and a low-face shot list. Never invents your opinions. Use for "make my version of this reel", "break down / reverse-engineer this reel", "same reel but my take", "give me a shot list from this reel".
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, Skill
---

# Reel Pipeline - a proven reel becomes YOUR version

You find a reel on your topic that's already getting engagement. This makes your own version: **same concept and same proven format, your content and your take.** Example: her reel lists her 5 best MCPs, yours lists YOUR 5, in the same format that's already working.

**One output, two platforms.** The 9:16 short-form output serves **both Instagram Reels and YouTube Shorts** (same aspect, same length, same format). Make it once, post to both. This is the default short-form path. (Long-form 16:9 YouTube is the separate `youtube-pipeline`, and ElevenLabs caps narration at 5000 chars there.) When logging to the Brain's Content table, a piece bound for both can carry Type `reel` and note the cross-post in Body.

It returns:
- **`hook_options`** - 3 opening lines using the same mechanic as the original, in your voice.
- **`tailored_script`** - the reel's proven structure, filled with YOUR content, in your voice.
- **`shot_list`** - numbered shots (duration, framing, what to do, on-screen text, notes), biased to low-face / screen-demo since you're camera-shy.
- **`caption_suggestion`** - caption with one CTA.
- **`missing`** - anything it needed from you and didn't get (it flags gaps, it does NOT invent your opinions).

## Step 0 - tenant resolution (do this first, every time)

Parse `--business <slug>` from arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the user to run `/marketing-team:setup` and stop. Never type a literal brand value, CTA, or
ID; everything (wordmark, colors, CTA, voice profile path, Brain mode) comes from this config.

## The core idea (why this is not a rewriter)
The reel is a **format you fill with your own content**, not a template to repurpose into a different niche. Stage 4 splits the reel into:
- **STRUCTURE** you keep (hook shape, pacing, shot sequence, CTA placement).
- **SWAPPABLE SLOTS** you replace (the picks, claims, examples, tools it names).

Then it asks you to fill the slots with your own, and only then writes the script. It will never fabricate your picks or opinions; an unfilled slot becomes a visible `[NEEDS FROM YOU: ...]` and lands in `missing`.

## When to use
"make my version of this reel", "same reel but my take", "break down / reverse-engineer this reel", "give me a shot list from this reel".

## What it needs (one-time setup)
Tools on PATH: **ffmpeg** + **ffprobe**, and Python 3.10+.

```bash
cd ${CLAUDE_PLUGIN_ROOT}/skills/reel-pipeline/scripts
pip install -r requirements.txt        # yt-dlp, anthropic, openai-whisper, python-dotenv, rich
cp .env.example .env                   # then add your ANTHROPIC_API_KEY
```

**Heads up on install size:** `openai-whisper` pulls in PyTorch (a 2GB+ download, the install takes minutes), and the first transcription downloads the Whisper model itself (~150MB for `base`). Budget disk space and time for the first run.

`.env` keys:
- `ANTHROPIC_API_KEY` - required (script writing + vision analysis).
- `WHISPER_MODEL` - `base` (fast, default), bump to `small`/`medium` if transcripts come out rough on names/jargon.
- `IG_COOKIES_PATH` - path to an Instagram `cookies.txt` (Netscape format). **Needed for most reels** - Instagram blocks anonymous downloads fast.

### Instagram cookies (do this once, most reels fail without it)
1. Install the "Get cookies.txt LOCALLY" browser extension.
2. Log into instagram.com in that browser.
3. Export cookies for instagram.com, save the file into `scripts/` (e.g. `cookies.txt`).
4. Point `IG_COOKIES_PATH` at it in `.env` (e.g. `IG_COOKIES_PATH=./cookies.txt`).

**Account-risk warning:** cookies come from a real, logged-in Instagram account. Heavy or automated download
traffic through that session can get the account flagged or rate-limited by Instagram. Use a secondary
account if you plan to run this often, not your main business account.

## Write the tenant's voice rules before generating (do this every run)

`generate_script.py` writes in a built-in fallback voice unless a `voice-rules.txt` file sits next to it. Before
running Phase B (or the quick full run), write that file from the tenant's own voice profile so the engine
writes in THEIR voice, not the fallback:

1. Read `~/.claude/marketing-team/businesses/<slug>.voice.md` (the voice profile from the setup interview).
   If it does not exist yet, run the calibration interview from the `brand-voice` skill first and write it.
2. Copy (or distill) that profile's rules into
   `${CLAUDE_PLUGIN_ROOT}/skills/reel-pipeline/scripts/voice-rules.txt` as plain text before calling
   `generate_script.py` or `generate_youtube.py`. Overwrite it each run so it always reflects the current
   tenant (this skill can serve more than one business).
3. If the voice profile is missing and the interview cannot run right now, proceed with the script's built-in
   fallback voice and say so in the output.

## How to run it (two phases, this is the whole point)

Always run from the `scripts/` directory so `.env` and relative `output/` resolve.

### Phase A, reverse-engineer the reel and see what it needs from you
```bash
cd ${CLAUDE_PLUGIN_ROOT}/skills/reel-pipeline/scripts
python main.py "https://www.instagram.com/reel/XXXXXXX/" --analyze-only
```
This downloads, transcribes, and breaks the reel into structure + swappable slots. It prints the topic, the hook (verbatim + why it works), the format, and **exactly what content it needs from you** for each slot. It writes `output/<id>/fill_template.json`.

### Phase B, you supply your content, it writes your version
As the skill, **read the printed slots to the user and get their own picks/take/CTA** (this is the point of the tool, their content, not invented content). The CTA should default to `config.brand.cta.primary` / `config.brand.cta.keyword` unless the user gives a different one for this piece. Write their answers into the `mine` / `my_take` / `cta` fields of a fill file, then:
```bash
python generate_script.py output/<id>/transcript.json output/<id>/timeline.json "the creator's angle/audience/energy" --fill output/<id>/fill.json
```
Output prints and saves to `output/<id>/tailored_output.json`.

`fill.json` shape (only the `mine` fields matter, keyed by `slot_id`):
```json
{
  "topic": "using Claude with an MCP to run your social media",
  "my_take": "everyone shows Metricool; mine is different and does more",
  "cta": "<config.brand.cta.primary, e.g. comment TOOLS and I'll send you the setup>",
  "slots": {
    "connector_tool": {"mine": "Airtable MCP, my content brain not just a scheduler"},
    "prompt_use_case_1": {"mine": "ask Claude to pull my best posts and write 5 more"}
  }
}
```

### Quick full run (only if you already have the fills, or it's a test)
```bash
python main.py "<url>" --brief "the creator's angle" --fill output/<id>/fill.json
```

### Then polish for public
After generation, run the `tailored_script`, `hook_options` and `caption_suggestion` through the **`brand-voice`** skill for the final public-ready pass. `generate_script.py` bakes in the core voice rules (sharpened above by the tenant's `voice-rules.txt`), but `brand-voice` is the canonical system (audience-aware jargon, humanise pass, emotion check).

### Then deliver the finished script

Default to a clean local markdown file: write the hooks, script, shot list, and caption to a well-formatted
`.md` file (or straight into the chat) and tell the user where it is. Only deliver as a **Google Doc** if
BOTH are true: the Google Drive MCP is connected, AND the buyer says they want it as a Doc. In that case,
build clean HTML (h1 title, h2 sections for Hooks / Script / Shot list table / Caption) and create the doc
with `mcp__(your Google Drive MCP)__create_file` using `contentMimeType: "text/html"` and
`textContent: "<the html>"` (HTML auto-converts to a Doc with real headings, bold, and a table). Title format:
`Reel Script - <topic> (<config.brand.wordmark>)`. Return the `viewUrl` as a clickable link. The `.json` stays
as the working copy either way.

## The Brain loop (memory + learning)
Canonical spec for all content tools: `skills/brain-loop/SKILL.md`. This pipeline implements it in full below,
mirroring `/marketing-team:blog-draft`.

### LEARNING - read Active lessons and inject them (before generating)
Before the generate step, follow `skills/brain-loop/SKILL.md` Step 0 + the loop contract to pull Lessons rows
where `Active` = true and `Area` in {`content`, `general`} (either local markdown or Airtable mode, per
`config.brain.mode`). Write the `Rule` strings to `output/<id>/lessons.json` (a JSON array) and pass
`--lessons output/<id>/lessons.json` to `main.py` / `generate_script.py`. They are injected as HARD
CONSTRAINTS. This is the same ledger the SEO writer and outreach modules read, so a lesson learned anywhere
sharpens everything.

### MEMORY - log every script to the Content table (after delivery)
After the script is delivered (Google Doc or local file), log ONE Content row per `skills/brain-loop/SKILL.md`:
- Title: `<topic> (reel)`
- Type: `reel`
- Status: `review`
- Body: the hook + a one-line provenance (source URL, shot count, CTA, giveaway) + the local file path or Doc link
- Source URL: the reel it was modelled on
This gives a searchable record of every script (dedup, a library, feeds the Posts table + metrics later).
Before generating, you MAY check Content for the source URL to avoid remaking the same reel twice.

### CAPTURE a lesson
When the buyer gives feedback on a script ("the hook was weak", "too long"), write it to the Lessons table
(`Area` = `content`, `Active` = true) per `skills/brain-loop/SKILL.md` so every future reel and YouTube script
applies it. Same table, same loop. If the Brain is unreachable, say so and skip logging, never block the work.

**Do not invent the creator's opinions.** If they give a URL but no picks, run Phase A and ask them for their content. Only skip the ask if they explicitly say it's a test.

## The 5 stages (each re-runnable alone)
1. `download.py` , yt-dlp pulls the reel.
2. `extract.py` , ffmpeg pulls the audio + scene-change frames (real cut points, not fixed intervals).
3. `transcribe.py` , local Whisper transcribes the audio.
4. `analyze.py` , Claude vision reverse-engineers the reel into topic + hook + structure + **swappable slots**.
5. `generate_script.py` , Claude writes the script in the creator's voice, filling slots with THEIR content, 3 hook options, low-face shot list. Flags anything missing instead of inventing it.

## Shared engine (also powers `youtube-pipeline`)
Stages 1-4 are platform-agnostic. This same `scripts/` folder is the engine for the **`youtube-pipeline`** skill (long-form 16:9, ElevenLabs voiceover, zero face) via `--platform youtube`, which swaps stage 5 to `generate_youtube.py`. `generate_youtube.py` imports `VOICE_RULES` and `_strip_em_dashes` from `generate_script.py`. So: this is the ONE canonical copy for both reel and YouTube. Do not fork it; changing a front stage changes both platforms (verify both).

## Built-in guardrails (already handled)
- **Em dashes are stripped** from all generated copy (brand rule: no em dashes in public copy).
- **Truncation guard**: if the script response ever hits the token limit it raises a clear error instead of a cryptic JSON crash. `max_tokens` is set to 8000.
- **Windows UTF-8**: stdout/stderr forced to UTF-8 so the progress bar never crashes on cp1252.
- Every stage that needs the API key loads `.env` on its own, so stages run standalone.

## Common failures + fixes
- **`yt-dlp failed` / download blocked** → supply `IG_COOKIES_PATH` (private/rate-limited), or `pip install -U yt-dlp` (Instagram changed layout), or wait out a rate limit.
- **Messy transcript** (garbled names/jargon) → raise `WHISPER_MODEL` to `small` or `medium` in `.env`.
- **`ANTHROPIC_API_KEY` KeyError** → you ran a stage without a `.env` present in the working dir; `cd scripts` first, or create `.env`.
- **ffmpeg not found** → install ffmpeg and make sure `ffmpeg`/`ffprobe` are on PATH.

## Notes
- Everything runs locally except the two Claude calls (vision analysis + script). Nothing is posted or published.
- Output is a *starting point structured on a proven reel*, not a copy - the tailored script deliberately rewrites the message for the brief.

## Where this sits in the content chain
This skill is the FRONT half (pre-production: the script). It hands off to the back half (post-production: the video).
```
FIND / LEARN     →  /marketing-team:reel (quick transcribe + explain)  OR  reel-pipeline --analyze-only (deep)
REMAKE SCRIPT    →  reel-pipeline  →  brand-voice (public polish)
RECORD           →  you (screen recording), or your own talking-head tool if you have one
EDIT TO VIDEO    →  screen-to-reel  (raw recording → finished branded 9:16 reel)
POST / SCHEDULE  →  your scheduler / social MCP if connected
```
**Next step after this skill:** record your screen against the `shot_list`, then run **`screen-to-reel`** to turn the recording into the posted vertical video. The `caption_suggestion` here feeds that post.

## Packaging note (if you ever distribute this skill)
Before sharing or packaging a copy of this skill for anyone else, read `scripts/DISTRIBUTION-EXCLUDE.md`. It lists everything that must never ship in a distributed copy (`.env`, `cookies.txt`, `voice-rules.txt`, `output/`, `gen_err.txt`, `__pycache__`, downloaded reels).

"""
Stage 5: Given the original transcript + reverse-engineered timeline (structure +
swappable slots), plus the user's OWN content for those slots, generate a script
in the user's voice and a concrete recording shot list for their own version.

Key rule: the user makes videos on the SAME topic with THEIR OWN take. We keep the
reel's proven structure and drop the user's content into the swappable slots. We NEVER
invent the user's opinions/picks. If a slot has no fill, we leave a clearly marked
placeholder rather than fabricate.
"""
import json
import os
from anthropic import Anthropic

MODEL = os.environ.get("REEL_PIPELINE_MODEL", "claude-sonnet-4-6")

# Compact distillation of the brand-voice writing system (the universal rules).
# The jargon rule is deliberately audience-aware: tool names that ARE the subject
# of the video stay; hollow corporate hype does not.
#
# This is the FALLBACK voice. To make the engine write in YOUR voice, drop a
# plain-text file of your own rules at `voice-rules.txt` next to this script
# (or point REEL_PIPELINE_VOICE_RULES at any file). If none is found, these
# built-in rules are used, so behaviour is unchanged out of the box.
_DEFAULT_VOICE_RULES = """VOICE (write the script and caption in this voice):
- Plain, confident, spoken British. Conversational, not corporate. Say it like you'd say it out loud to one person.
- The number is the hero. Lead with a concrete number or outcome wherever there is one ("saves 3 hours", "47 replies").
- Result-led: people don't buy the tool, they buy what it gives them (time saved, money made). Tie picks to the outcome for the viewer.
- One CTA only, at the end. End on the CTA. NEVER a sign-off catchphrase ("that's a wrap", "hope this helps").
- NO em dashes, ever. Use full stops, commas, colons, parentheses, or rewrite.
- Kill hollow hype and corporate jargon (leverage, seamless, robust, elevate, "in today's fast-paced world", "let's dive in"). BUT keep the specific tool/tech names that ARE the subject of the video; those are the point, not jargon.
- No AI-writing tells: no rule-of-three padding, no "serves as/boasts" (use is/has), no signposting, no generic positive conclusions. Say the plain thing.
- No invented facts, stats, named sources, or implied results. Only use what the user actually gave you.
- Lightly opinionated is good. Real opinion beats safe filler."""


def _load_voice_rules() -> str:
    """Return the buyer's own voice rules if a voice-rules file exists, else the built-in default.
    Looks at REEL_PIPELINE_VOICE_RULES (a path), then voice-rules.txt next to this script."""
    from pathlib import Path
    candidates = []
    env_path = os.environ.get("REEL_PIPELINE_VOICE_RULES")
    if env_path:
        candidates.append(Path(env_path))
    candidates.append(Path(__file__).resolve().parent / "voice-rules.txt")
    for p in candidates:
        try:
            if p.is_file():
                text = p.read_text(encoding="utf-8").strip()
                if text:
                    return text
        except OSError:
            pass
    return _DEFAULT_VOICE_RULES


VOICE_RULES = _load_voice_rules()

SYSTEM_PROMPT = f"""You are a short-form video scriptwriter writing in ONE specific creator's voice.

The creator found a reel on their topic that is already getting engagement, and wants to make \
their OWN version: same concept and same proven format, but their own content and their own take. \
You will be given:
1. The original reel's transcript.
2. A reverse-engineered breakdown: the topic, the hook, the reusable STRUCTURE, and the SWAPPABLE SLOTS \
   (the specific content pieces the creator replaces with their own).
3. The creator's OWN content for those slots (their picks, their take, their CTA).

Your job:
A. KEEP the reel's proven structure: the hook shape, the pacing, the shot sequence, the CTA placement. \
   Do not copy the original's wording; reuse the FORMAT.
B. FILL the slots with the creator's supplied content. This is the hard rule: use ONLY what the creator gave you. \
   NEVER invent the creator's opinions, picks, tools, numbers, or examples. If a slot has no supplied content, \
   write the literal placeholder "[NEEDS FROM YOU: <what to supply>]" in its place. Do not fabricate to fill a gap.
C. Write it all in the creator's voice below.
D. Give THREE distinct hook options (the hook is what drives the engagement they are copying), each using the \
   same underlying mechanic as the original but in the creator's voice and about the creator's content.
E. Build the shot list biased toward LOW-FACE formats. The creator is camera-shy. Prefer screen recordings, \
   b-roll, and text-overlay shots that demonstrate the content; use talking-head only where it genuinely lands \
   harder (the hook and the CTA). Say what to screen-record specifically.

{VOICE_RULES}

Respond with ONLY valid JSON, no markdown fences, no preamble. Schema:
{{
  "hook_options": [string, string, string],  // 3 alternative opening lines, best first
  "tailored_script": string,                  // the full spoken script using hook_options[0]
  "shot_list": [
    {{"shot_number": number, "duration_sec": number, "shot_type": string,
     "what_to_do": string, "on_screen_text": string|null, "recording_note": string}}
  ],
  "caption_suggestion": string,
  "missing": [string]                          // any slots the creator did not supply (empty list if none)
}}
"""


def call_json(client, system: str, user_content: str, schema: dict, max_tokens: int) -> dict:
    """Get structured output from the model via tool-use. Anthropic constrains generation to valid
    JSON matching `schema`, so the malformed-JSON failures of hand-parsed text output cannot happen.
    Returns the tool input as a Python dict (already parsed and schema-validated)."""
    resp = client.messages.create(
        model=MODEL,
        max_tokens=max_tokens,
        system=system,
        tools=[{"name": "emit", "description": "Return the finished result in the required structure.", "input_schema": schema}],
        tool_choice={"type": "tool", "name": "emit"},
        messages=[{"role": "user", "content": user_content}],
    )
    if resp.stop_reason == "max_tokens":
        raise RuntimeError(
            f"Generation hit the max_tokens limit ({max_tokens}) and the structured output was cut off. Raise max_tokens."
        )
    for block in resp.content:
        if getattr(block, "type", None) == "tool_use":
            return block.input
    raise RuntimeError("Model did not return a tool_use block. Raw: " + str(resp.content)[:500])


# Structured-output schema for the reel result (forces valid JSON).
REEL_SCHEMA = {
    "type": "object",
    "properties": {
        "hook_options": {"type": "array", "items": {"type": "string"}, "description": "3 alternative opening lines, best first"},
        "tailored_script": {"type": "string", "description": "full spoken script using hook_options[0]"},
        "shot_list": {"type": "array", "items": {"type": "object", "properties": {
            "shot_number": {"type": "number"}, "duration_sec": {"type": "number"}, "shot_type": {"type": "string"},
            "what_to_do": {"type": "string"}, "on_screen_text": {"type": ["string", "null"]}, "recording_note": {"type": "string"},
        }, "required": ["shot_number", "duration_sec", "shot_type", "what_to_do", "recording_note"]}},
        "caption_suggestion": {"type": "string"},
        "missing": {"type": "array", "items": {"type": "string"}, "description": "slots the creator did not supply; [] if none"},
    },
    "required": ["hook_options", "tailored_script", "shot_list", "caption_suggestion", "missing"],
}


def _strip_em_dashes(obj):
    """Recursively replace em/en dashes with commas in all string values.
    Brand rule: public copy never uses em dashes."""
    if isinstance(obj, str):
        return obj.replace(" — ", ", ").replace(" – ", ", ").replace("—", ", ").replace("–", ", ")
    if isinstance(obj, list):
        return [_strip_em_dashes(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _strip_em_dashes(v) for k, v in obj.items()}
    return obj


def _lessons_block(lessons: list[str] | None) -> str:
    """Format learned lessons as hard constraints. Shared with the youtube generator.
    Lessons come from the Brain's Lessons table (Active rows), read by the skill before generating."""
    if not lessons:
        return ""
    bullets = "\n".join(f"- {l}" for l in lessons)
    return (
        "\n\nLEARNED LESSONS (apply ALL of these as HARD CONSTRAINTS, they come from past feedback "
        "and performance data, they override style preferences):\n" + bullets
    )


def generate_tailored_script(
    original_transcript: str,
    timeline: dict,
    user_brief: str,
    api_key: str,
    fills: dict | None = None,
    lessons: list[str] | None = None,
) -> dict:
    client = Anthropic(api_key=api_key)

    fills = fills or {}
    fills_block = json.dumps(fills, indent=2) if fills else "(none supplied yet)"

    user_content = f"""ORIGINAL TRANSCRIPT:
{original_transcript}

REVERSE-ENGINEERED BREAKDOWN (topic, hook, structure, swappable slots):
{json.dumps(timeline, indent=2)}

THE CREATOR'S BRIEF (their angle / audience / energy):
{user_brief}

THE CREATOR'S OWN CONTENT FOR THE SLOTS (use ONLY this, never invent more):
{fills_block}{_lessons_block(lessons)}

Produce the JSON described in the system prompt. Remember: keep the structure, fill the slots with the \
creator's content only, three hook options, low-face shot list, the creator's voice."""

    return _strip_em_dashes(call_json(client, SYSTEM_PROMPT, user_content, REEL_SCHEMA, max_tokens=8000))


if __name__ == "__main__":
    import sys, os, argparse
    from pathlib import Path
    from dotenv import load_dotenv
    load_dotenv()

    parser = argparse.ArgumentParser(description="Generate tailored script from saved artifacts")
    parser.add_argument("transcript_json", help="path to transcript.json")
    parser.add_argument("timeline_json", help="path to timeline.json")
    parser.add_argument("brief", help="the creator's brief / angle")
    parser.add_argument("--fill", help="path to fill.json with the creator's slot content", default=None)
    parser.add_argument("--lessons", help="path to a JSON array of learned lessons (strings) to apply as hard constraints", default=None)
    args = parser.parse_args()

    transcript = json.loads(Path(args.transcript_json).read_text())["text"]
    timeline = json.loads(Path(args.timeline_json).read_text())
    fills = json.loads(Path(args.fill).read_text()) if args.fill else None
    lessons = json.loads(Path(args.lessons).read_text()) if args.lessons else None

    result = generate_tailored_script(
        transcript, timeline, args.brief, os.environ["ANTHROPIC_API_KEY"], fills=fills, lessons=lessons
    )
    print(json.dumps(result, indent=2))

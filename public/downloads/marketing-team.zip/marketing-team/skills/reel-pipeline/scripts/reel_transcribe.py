#!/usr/bin/env python3
"""
Download an Instagram reel (or most yt-dlp-supported video URLs), extract the
audio, and transcribe it with faster-whisper.

Outputs a single JSON object to stdout:
    {"ok": true, "title": ..., "uploader": ..., "url": ..., "duration": ...,
     "transcript": "..."}
or on failure:
    {"ok": false, "error": "...", "hint": "..."}

Usage:
    python reel_transcribe.py <url> [--model base] [--cookies-from-browser chrome]
"""
import sys
import os
import json
import glob
import tempfile
import argparse
import subprocess
import shutil
import importlib


def emit(obj):
    """Print one JSON object to stdout and exit."""
    print("\n@@REEL_JSON@@" + json.dumps(obj))
    sys.exit(0 if obj.get("ok") else 1)


def _have(module):
    try:
        importlib.import_module(module)
        return True
    except ImportError:
        return False


def ensure_deps():
    """Make the script work on a clean install: auto-install the Python packages it
    needs (yt-dlp, faster-whisper) and check for the ffmpeg system binary. Keeps the
    'no terminal' promise - the buyer never has to pip install anything by hand."""
    for module, package in (("yt_dlp", "yt-dlp"), ("faster_whisper", "faster-whisper")):
        if _have(module):
            continue
        sys.stderr.write("Installing missing dependency: %s ...\n" % package)
        sys.stderr.flush()
        subprocess.run([sys.executable, "-m", "pip", "install", "--quiet",
                        "--disable-pip-version-check", package],
                       capture_output=True, text=True)
        importlib.invalidate_caches()
        if not _have(module):
            emit({"ok": False,
                  "error": "Could not auto-install %s." % package,
                  "hint": "Run: \"%s\" -m pip install %s" % (sys.executable, package)})
    if shutil.which("ffmpeg") is None:
        emit({"ok": False,
              "error": "ffmpeg is not installed or not on PATH.",
              "hint": "Install ffmpeg then retry - Windows: 'winget install Gyan.FFmpeg' "
                      "or 'choco install ffmpeg'; macOS: 'brew install ffmpeg'; "
                      "Linux: 'sudo apt install ffmpeg'."})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("--model", default="base",
                    help="whisper model size: tiny|base|small|medium|large-v3")
    ap.add_argument("--cookies-from-browser", default=None,
                    help="e.g. chrome / edge / firefox — for login-gated reels")
    args = ap.parse_args()

    ensure_deps()

    workdir = tempfile.mkdtemp(prefix="reel_")
    out_template = os.path.join(workdir, "audio.%(ext)s")

    # --- 1. Download audio via yt-dlp ---
    dl_cmd = [
        sys.executable, "-m", "yt_dlp",
        "-f", "bestaudio/best",
        "-x", "--audio-format", "mp3",
        "--write-info-json",
        "--no-playlist",
        "-o", out_template,
        args.url,
    ]
    if args.cookies_from_browser:
        dl_cmd += ["--cookies-from-browser", args.cookies_from_browser]

    proc = subprocess.run(dl_cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout or "").strip()
        hint = ""
        low = err.lower()
        if "login" in low or "rate-limit" in low or "cookies" in low or "private" in low or "not available" in low:
            hint = ("Instagram likely requires login. Re-run with "
                    "--cookies-from-browser chrome (or edge/firefox), and make "
                    "sure you're logged into Instagram in that browser.")
        emit({"ok": False, "error": err[-1500:], "hint": hint})

    audio_files = glob.glob(os.path.join(workdir, "audio.mp3"))
    if not audio_files:
        any_audio = glob.glob(os.path.join(workdir, "audio.*"))
        audio_files = [f for f in any_audio if not f.endswith(".json")]
    if not audio_files:
        emit({"ok": False, "error": "Audio file not produced by yt-dlp.", "hint": ""})
    audio_path = audio_files[0]

    # --- metadata ---
    meta = {}
    info_files = glob.glob(os.path.join(workdir, "*.info.json"))
    if info_files:
        try:
            with open(info_files[0], "r", encoding="utf-8") as fh:
                meta = json.load(fh)
        except Exception:
            meta = {}

    # --- 2. Transcribe via faster-whisper ---
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        emit({"ok": False,
              "error": "faster-whisper not installed.",
              "hint": "Run: pip install faster-whisper"})

    model = WhisperModel(args.model, device="cpu", compute_type="int8")
    segments, info = model.transcribe(audio_path, vad_filter=True)
    transcript = " ".join(seg.text.strip() for seg in segments).strip()

    emit({
        "ok": True,
        "title": meta.get("title") or meta.get("fulltitle") or "",
        "uploader": meta.get("uploader") or meta.get("channel") or "",
        "url": meta.get("webpage_url") or args.url,
        "duration": meta.get("duration"),
        "language": getattr(info, "language", None),
        "transcript": transcript,
    })


if __name__ == "__main__":
    main()

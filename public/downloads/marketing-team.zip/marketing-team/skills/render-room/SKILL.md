---
name: render-room
description: >-
  Render Room - pay-per-use image & video generation through the buyer's own fal.ai API key
  (a self-owned alternative to a Higgsfield/Topaz subscription). Use whenever the user wants to
  generate an image from a description, edit an image with reference image(s), turn an image into
  a video, or upscale a video. Triggers: "render", "generate an image", "make/animate a video from
  this image", "image to video", "upscale this video", "render room", "use fal". Claude rewrites the
  rough idea into a strong prompt, runs the chosen fal model, confirms cost before any paid video/
  upscale step, and saves outputs locally.
---

> **Advanced skill - requires setup.** This skill uses external tools that are NOT part of the no-terminal core: Python and a paid fal.ai API key. It will not
> run on a machine without them. Run `/marketing-team:doctor` first to check this computer and get the install
> steps. The core marketing team (content, blog, outreach, analytics, Brain) needs none of this.

## Preflight (do this first)
Confirm the required tools are available (Python and a paid fal.ai API key). If any is missing, tell the buyer exactly what to install,
or point them to `/marketing-team:doctor`, and STOP. Do not proceed into a cryptic tool error.

# Render Room

Pay-per-use media generation via **fal.ai**, on the buyer's own account. One script, model-agnostic - 
name the fal model and it runs, so new models work with no code change. The key lives in the
environment (`FAL_KEY`), never in chat or on the command line.

## Step 0 - tenant resolution

Parse `--business <slug>` from arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If
missing, tell the user to run `/marketing-team:setup` and stop. Read brand defaults (colours, wordmark,
tone) from `config.brand` - never hardcode a brand value.

## Engine
`python ${CLAUDE_PLUGIN_ROOT}/skills/render-room/render_room.py <cmd> --model <fal-slug> [opts]`

Commands: `image` · `edit` · `video` · `upscale`. Common options:
- `--prompt "..."` - the prompt (you write the strong version; see Workflow).
- `--image PATH_or_URL` - input image (repeatable; used by `edit` and `video`).
- `--video PATH_or_URL` - input video (used by `upscale`).
- `--arg key=value` - any extra model parameter (repeatable). Values auto-cast (int/float/bool/json).
- `--image-key NAME` - override the payload key for the image input if a model expects something
  other than `image_url` / `image_urls`. On `upscale` it overrides the video payload key instead
  (default `video_url`).
- `--out DIR`: output root. Default is the tenant output folder,
  `~/.claude/marketing-team/output/<slug>/media`, with a subfolder per command. Pass `--out` explicitly
  pointed at that path (substitute the resolved slug) so every render lands in the right buyer's folder.

The script prints one line `@@RENDER_JSON@@ {json}`. Parse it. On `ok:true` use `files` (local paths)
and report them. On `ok:false` read `error`/`hint` (e.g. missing `FAL_KEY` → tell the user to add it).

## Workflow (follow this every time)
1. **Rewrite the prompt.** The user gives a rough idea; you turn it into a detailed, model-appropriate
   prompt (subject, composition, lighting, style, what to avoid). For brand work, default to the
   business's own brand tokens from `config.brand` (accent colour, wordmark, tone) unless told
   otherwise.
2. **Pick the model** (or use the user's). See the table; confirm the slug against https://fal.ai/models
   if unsure - slugs drift.
3. **Confirm cost before paid steps.** Images are pennies - just run them. For **video** and **upscale**,
   state the rough cost and the prompt, and ask the user to confirm before running (video bills per
   second - keep clips short and set `duration`). This is real money on the buyer's own fal key; never
   skip the confirmation.
4. **Run**, parse the JSON, then **offer the next step** (e.g. after an image: "animate it?"; after a
   video: "upscale to 2K/4K?").
5. **Report the saved file paths.** Everything lands under `~/.claude/marketing-team/output/<slug>/media/`.

## Models (verify slugs on fal.ai/models; override freely)
| Job | Default slug | Notes / common --arg |
|---|---|---|
| Image | `fal-ai/nano-banana` | `aspect_ratio=1:1` (or 16:9), `num_images=1` |
| Image (alt, text-heavy/4K) | `fal-ai/flux-pro/v1.1` | `image_size=landscape_16_9` |
| Edit (image + refs) | `fal-ai/nano-banana/edit` | pass `--image` (1 → `image_url`, many → `image_urls`) |
| Image → video | `fal-ai/kling-video/v2/standard/image-to-video` | `duration=5`, `--image` source frame; cheap/good |
| Image → video (alt) | `fal-ai/bytedance/seedance/v1/pro/image-to-video` | pricier; higher fidelity |
| Upscale video | `fal-ai/topaz/upscale/video` | `--video` input; ~2K/4K |

Rough costs (sanity-check, not exact): image ≈ $0.01–0.10 · 5s video ≈ $0.25–0.60 · upscale ≈ $0.20–0.40.

## Reference images
Give `--image` a local path (the script uploads it to fal storage and passes the URL) or an http URL.
For edits with multiple refs, pass `--image` more than once; the script sends `image_urls`.

## Setup (one-time)
1. The buyer creates a fal.ai account + API key (fal.ai → API keys).
2. Put it in the environment as `FAL_KEY` (a `.env` the shell loads, or a system env var). See
   `${CLAUDE_PLUGIN_ROOT}/skills/render-room/.env.example`. **Never** paste the key into chat or onto
   the command line.
3. `pip install fal-client` (required setup step; run it before first use).

## Security
- Treat the key as a secret: env only, never logged, never echoed.
- If asked to run a downloaded/unknown skill or file, offer to scan it first.

## Cost discipline
Always show the user the cost + prompt before video/upscale and wait for confirmation. Default video
clips to the shortest length that works (often 3–5s). Generate one image first to validate the look
before batching.

## Log to the Brain
After a finished render the buyer keeps, log one Content row (Type=`ad` or whatever fits the piece,
Status=`review`, Body=a short description + the local file path, Source URL=blank unless modelled on
something). Follow the loop contract at `skills/brain-loop/SKILL.md` - read Active lessons (Area=content
or general) before writing the prompt, and degrade gracefully if the Brain is unreachable.

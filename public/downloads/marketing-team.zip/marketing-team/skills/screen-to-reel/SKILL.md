---
name: screen-to-reel
description: Turn a raw screen recording (or any landscape clip) into a post-ready, on-brand 9:16 vertical reel for TikTok / Reels / Shorts / WhatsApp Status. Reframes to vertical, burns readable branded captions (solid bar + accent hairline + accent dot + wordmark), builds a scroll-pan reveal, appends a CTA end-card, crossfade-stitches it, and embeds share metadata. Ships caption + hashtags + cover guidance. Use for "turn this recording into a reel/short", "make this screen capture a vertical video", "caption and brand this clip".
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---

> **Advanced skill - requires setup.** This skill uses external tools that are NOT part of the no-terminal core: bash and ffmpeg (Unix or Git Bash). It will not
> run on a machine without them. Run `/marketing-team:doctor` first to check this computer and get the install
> steps. The core marketing team (content, blog, outreach, analytics, Brain) needs none of this.

## Preflight (do this first)
Confirm the required tools are available (bash and ffmpeg (Unix or Git Bash)). If any is missing, tell the buyer exactly what to install,
or point them to `/marketing-team:doctor`, and STOP. Do not proceed into a cryptic tool error.

# Screen → Reel - a raw recording becomes a post-ready vertical video

Give it a screen recording (or any clip). It returns a polished 9:16 video: reframed, captioned in your brand, with a reveal and a CTA end-card, crossfaded together, metadata embedded, plus the caption and hashtags to post with.

Tools needed: **ffmpeg** + **ffprobe** on PATH. Helper scripts live in `scripts/`. Brand values come from the tenant config, not a baked-in brand.

## Step 0 - tenant resolution (do this first, every time)

Parse `--business <slug>` from arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the user to run `/marketing-team:setup` and stop. Before calling any script below, set the
brand env vars FROM THAT CONFIG (see "Brand config" below): `WORDMARK` = `config.brand.wordmark`,
`ACCENT` = `config.brand.colors.accent`. Never type a literal brand value.

## When to use
"turn this recording into a reel / short / status", "make this screen capture vertical", "caption and brand this clip", "add a CTA end-card".

## The signature look (what makes it read on a phone)
- **9:16, 1080x1920, 30fps.**
- **Top bar** (opaque) hides the source browser/app chrome and any messy source captions, and carries the **wordmark** (name in white, full-stop in the accent colour).
- **Bottom caption bar**: a near-solid panel with an **accent hairline** on top and an **accent dot** leading each line, white text. Captions are legible over ANY background (this is the fix for "captions you can't read").
- **Accent + base + display font** are the only brand levers. One accent, used sparingly.

There is no baked-in brand. If no env vars are set, the scripts fall back to a neutral accent and no wordmark
(see each script's own default). Always set them from the tenant config before running.

## Brand config (env vars, set these from `config.brand` before running any script)
```
ACCENT=<config.brand.colors.accent>   BASE=0x0E0F12   TEXTCOL=0xF5F6F7
FONT=_fonts/sg.ttf        # display TTF (Space Grotesk by default)
DOTFONT=_fonts/dot.ttf    # any TTF containing ● (Arial/Segoe work)
WORDMARK=<config.brand.wordmark>      # trailing accent dot added automatically; empty = none
```
Get the fonts once (Space Grotesk is OFL, safe to use):
```
mkdir -p _fonts
curl -sL "https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/spacegrotesk/SpaceGrotesk%5Bwght%5D.ttf" -o _fonts/sg.ttf
cp /c/Windows/Fonts/arial.ttf _fonts/dot.ttf    # or any TTF with the ● glyph
```

## The pipeline (each step is one helper or one command)

**Audio note:** every pipeline step drops audio (`-an`) by design, since these reels are caption-driven; to keep narration, remove `-an` from each step's command and re-add an audio map in the xfade-stitch step (step 5).

### 1. Reframe to vertical (recording-specific - do this by eye)
A landscape recording squeezed into 9:16 looks tiny. Crop a tall strip from the action and scale to fill, speeding up dead time. Example (crop a centre strip, ~9x speed):
```
ffmpeg -i raw.mp4 -vf "crop=608:1080:656:0,scale=1080:1920,setpts=PTS/9,fps=30" -an reframed.mp4
```
Tune `crop=W:H:X:Y` to the part of the screen that matters, and `setpts=PTS/N` to hit your target length. Aim for 30-45s.

### 2. Branded captions  →  `scripts/caption-bar.sh`
Write a captions file, one line per beat: `START|END|TEXT` (seconds). Keep lines short.
```
0|10|I briefed my AI team
10|22|The writer drafts the copy
22|33|<you> designs it
33|46|The builder ships the site
```
Then (with `ACCENT`/`WORDMARK` exported from the tenant config first):
```
bash scripts/caption-bar.sh reframed.mp4 captioned.mp4 captions.txt
```
Time captions to what is happening on screen (read frames if unsure: `ffmpeg -ss T -i in.mp4 -frames:v 1 f.png`).

### 3. (Optional) scroll-pan reveal  →  `scripts/scroll-pan.sh`
Show the finished result by panning a full-page screenshot. Take a tall screenshot with any full-page screenshot tool, then:
```
bash scripts/scroll-pan.sh page-tall.png reveal.mp4 7
```
End the pan on the last real content so there is no blank scroll at the tail.

### 4. CTA end-card (2s)
Append a short branded CTA so every video ends on one action. Drive ONE action from `config.brand.cta` (e.g. "Comment '<config.brand.cta.keyword>'"). Self-contained fallback, needs only ffmpeg and the fonts from setup:
```
ffmpeg -f lavfi -i "color=c=0x0E0F12:s=1080x1920:d=2:r=30" \
  -vf "drawtext=fontfile=_fonts/sg.ttf:text='<CTA line 1>':fontcolor=0xF5F6F7:fontsize=88:x=(w-text_w)/2:y=(h-text_h)/2-80,drawtext=fontfile=_fonts/sg.ttf:text='<CTA line 2>':fontcolor=<config.brand.colors.accent>:fontsize=56:x=(w-text_w)/2:y=(h-text_h)/2+60" \
  -an endcard.mp4
```
Swap the two text lines and the accent hex for the tenant's CTA and brand colour. Any 1080x1920 clip works as an end-card if a buyer has their own animated end-card tooling; that is outside this skill.

### 5. Crossfade-stitch  →  `scripts/xfade-stitch.sh`
Trim each piece to length first, then dissolve them together (1s):
```
bash scripts/xfade-stitch.sh stitched.mp4 1 captioned.mp4 reveal.mp4 endcard.mp4
```
(Pass clips already trimmed to the length you want; the script dissolves whatever it is given.)

### 6. Metadata + faststart  →  `scripts/tag.sh`
```
bash scripts/tag.sh stitched.mp4 final.mp4 "Title here" "<the CTA line>" "<config.brand.wordmark>"
```
`faststart` moves the moov atom to the front so playback starts instantly (protects early watch-through). The
fifth argument (author) defaults to the `AUTHOR` env var if omitted; pass `config.brand.wordmark` explicitly
so the file metadata carries the right brand.

After the final video is done, log it to the Content table per `skills/brain-loop/SKILL.md` (Type `reel` or
`short`, Body = caption + hashtags + provenance) so the log+learn step runs.

## What to post with it (this is what actually moves the algorithm)
TikTok/Reels strip most file metadata. Reach is driven by: **caption text** (it OCRs the video too), **hashtags**, the **first 1.5s**, the **cover**, and **early engagement**. So always hand back:
- **Caption**: benefit-led, ends on the comment trigger from `config.brand.cta`.
- **Hashtags**: ~6 relevant, not 15 random.
- **Cover**: pick a frame showing the payoff + 3-4 word text overlay.
- **Pinned comment**: restate the CTA; reply to every trigger comment (spikes comments = more reach).

## Quality rules
- Captions short and timed to the action. One idea per beat.
- One accent colour only. No em dashes. No fabricated stats, no fake testimonials.
- Keep it 30-45s; open on motion, not a static title.
- Re-encode when crossfading (stream-copy concat breaks on dissimilar clips); `-crf 18`.

## Templates (named video types)
Reusable formats built on this pipeline live in `templates/`. Read the template, then run the steps.
- **`templates/team-build.md`** - "Team Build": a team builds a real deliverable live → reveal → give away the outcome. Swap the *angle* (the hook framing: Cost / Time / POV / Face) and the *subject* (website, landing page, lead magnet, automation).

## Make it yours
Set `ACCENT`, `BASE`, `FONT`, `WORDMARK` from `config.brand` and the whole look retargets. The structure stays the same.

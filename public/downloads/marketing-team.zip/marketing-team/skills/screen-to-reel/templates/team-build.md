# Video type: "Team Build"

A repeatable format: **something real gets built live on screen → reveal the finished result → give away
what did it, or point at the CTA.** Same structure every time; swap the *angle* (the hook) and the *subject*
(what gets built). Built on the `screen-to-reel` pipeline.

> **Prerequisites (not included):** this template assumes only the self-contained ffmpeg drawtext hook/end-card
> fallback described in `../SKILL.md` (step 4) and any full-page screenshot tool for the reveal. If you have
> your own animation tooling (Remotion, After Effects, etc.) for a fancier hook or end-card, swap it in; that
> layer is not part of this skill.

## Why it works
- Proof, not claims: people watch the thing get built.
- Your process is the differentiator (idea → copy → design → build), so it shows the brand's edge.
- Ends on one CTA (comment trigger, DM, or link) → engagement + lead capture in one move.

## The fixed structure (4 beats, ~30-35s)
1. **Hook (2.5s)** - a scroll-stopping angle + cover. A drawtext title card or your own animated intro.
2. **Build (~20s)** - screen recording of the build, sped up, with branded captions narrating each step. `caption-bar.sh`.
3. **Reveal (~5-7s)** - scroll-pan over the finished result. `scroll-pan.sh`.
4. **CTA end-card (2s)** - the tenant's CTA from `config.brand.cta`. Drawtext fallback in `../SKILL.md` step 4.

Then `xfade-stitch.sh` (0.5s dissolves) + `tag.sh`.

## The two things you swap

### Angle (the hook)
Pick whichever framing fits the build:
| angle | example line |
|---|---|
| Cost | "I stopped paying for [X]. Here's what does it instead." |
| Time | "A [thing] in minutes, not weeks." |
| POV | "POV: watch this get built start to finish." |
| Face (optional) | on camera for the hook only, then cut to the build, if the tenant records themselves. |

Keep it one emotion, no em dashes, no fabricated stats.

### Subject (what gets built)
website · landing page · lead magnet · cold-email sequence · a mini automation · a dashboard. The build
captions stay step-shaped: `briefed → [step] → [step] → shipped`. The end-card CTA matches the giveaway or
offer for this piece.

## Make one (commands)
```bash
# from the video working folder; fonts in _fonts/ (see ../SKILL.md); brand env vars set from config.brand
# 1. hook + cover (a drawtext title card, or your own tool)
ffmpeg -f lavfi -i "color=c=0x0E0F12:s=1080x1920:d=2.5:r=30" \
  -vf "drawtext=fontfile=_fonts/sg.ttf:text='<hook line>':fontcolor=0xF5F6F7:fontsize=80:x=(w-text_w)/2:y=(h-text_h)/2" \
  -an hook.mp4

# 2. reframe raw recording -> vertical (tune crop/speed), then speed the build for pace
ffmpeg -i raw.mp4 -vf "crop=608:1080:656:0,scale=1080:1920,setpts=PTS/9,fps=30" -an reframed.mp4
ffmpeg -i reframed.mp4 -vf "setpts=PTS/1.8,fps=30" -an -t 22.5 build-fast.mp4   # ~22s keeps it punchy

# 3. branded captions (captions.txt: START|END|TEXT, scaled to the sped clip)
bash scripts/caption-bar.sh build-fast.mp4 build-cap.mp4 captions.txt

# 4. reveal + 5. stitch + 6. tag
bash scripts/scroll-pan.sh page-tall.png reveal.mp4 7
bash scripts/xfade-stitch.sh out.mp4 0.5 hook.mp4 build-cap.mp4 reveal.mp4 endcard.mp4
bash scripts/tag.sh out.mp4 final.mp4 "Title" "<the CTA line>" "<config.brand.wordmark>"
```

## Caption beats (website subject, ~22s sped build)
```
0|5.5|I briefed the plan
5.5|12.2|The copy gets drafted
12.2|18.3|The design comes together
18.3|23|It ships
```
Re-time for other subjects/speeds; keep them in sync with the on-screen action.

## Post-with kit (always hand this back)
- **Caption** ending on the comment trigger from `config.brand.cta`.
- **~6 relevant hashtags**, the **cover** (the hook frame), and a **pinned comment** restating the CTA. Reply to every trigger comment (sends the freebie + spikes comments).

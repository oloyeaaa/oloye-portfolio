---
name: seo-writer
description: Use whenever the user wants a new SEO blog post for their site, wants to draft, publish, or kill a blog post, or wants to check the writer agent for a quality regression. Trigger on "write a blog post", "draft an article for my site", "publish that draft", "kill that draft", "teach the writer a rule", or "check the blog writer for regressions".
---

# SEO writer

This skill is the entry point for the SEO module of The Marketing Team. It writes, reviews, publishes, and
kills blog drafts for the buyer's site, keeping a running list of lessons so the writer gets sharper with every
correction.

## What it does

- Drafts a full SEO blog post from one target keyword, in the business's own brand voice.
- Optionally researches the keyword first (if a web-search tool is connected).
- Optionally generates a cover image and pushes the post to the buyer's own site repo (only if
  `config.site.enabled` is true).
- Defaults to writing drafts locally for review if no site repo is configured.
- Runs a regression check against a fixed set of eval keywords before letting new drafts through, if the last
  check found a problem.

## How it's used

Run the commands, not this skill directly:

- `/marketing-team:blog-draft <keyword>` - draft a new post.
- `/marketing-team:post-blog [slug]` - publish a review-status draft.
- `/marketing-team:kill-draft [slug]` - bin a draft and log why.
- `/marketing-team:lesson <text>` - teach any module a rule directly.
- `/marketing-team:eval-writer` - regression check for the writer agent.

The actual drafting is done by `agents/seo-writer.md`, briefed each run with the tenant's `config.brand`,
`config.seo`, and voice profile. See that file for the full craft rules (structure, SEO limits, voice).

## The regression gate

`/marketing-team:eval-writer` scores drafts with `skills/seo-writer/scripts/eval_blog_draft.py` against the
tenant's own config (jargon banlist, categories, pillar path, CTA path). A score drop from the last baseline
writes an Active `REGRESSION:` lesson (Area = seo). `/marketing-team:blog-draft` checks for that lesson before
every run and refuses to draft while it's active. A clean `/marketing-team:eval-writer` pass clears it.

## Requirements

- `config.seo.evalKeywords` must be set (a handful of representative keywords) before `/marketing-team:eval-
  writer` can run. This is chosen deliberately per business, not invented on the fly.
- Everything else works out of the box with `config.site.enabled = false` (the default): drafts land at
  `~/.claude/marketing-team/brain/<slug>/blog/<slug>.md`.

Full Brain contract: `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`.

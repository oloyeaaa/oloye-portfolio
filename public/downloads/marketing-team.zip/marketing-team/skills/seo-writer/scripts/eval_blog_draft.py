#!/usr/bin/env python3
"""Score one SEO writer draft JSON against the rules stated in agents/seo-writer.md,
using the tenant's own config for the values that are business-specific
(jargon banlist, categories, pillar path, CTA path).

Usage: python eval_blog_draft.py <path-to-draft.json> <path-to-tenant-config.json>
Prints one line: @@EVAL_JSON@@ {...}

Checks that have no configured value in the tenant config (empty list / empty
string) skip-pass: they are recorded as passed with a note, since there is
nothing to check against for this tenant.
"""
import json
import re
import sys

EM_DASH = "—"


def check(name, passed, detail=""):
    return {"name": name, "passed": bool(passed), "detail": detail}


def first_sentence(body: str) -> str:
    m = re.search(r"[.?!]", body.strip())
    return body.strip()[: m.end()] if m else body.strip()


def run_checks(draft: dict, config: dict):
    checks = []
    seo_cfg = config.get("seo", {}) or {}

    # 1. title <= 70
    title = draft.get("title", "") or ""
    checks.append(check(
        "title_max_70_chars",
        bool(title) and len(title) <= 70,
        f"len={len(title)}",
    ))

    # 2. slug kebab-case, 3-6 words
    slug = draft.get("slug", "") or ""
    slug_words = slug.split("-") if slug else []
    slug_ok = bool(re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", slug)) and 3 <= len(slug_words) <= 6
    checks.append(check("slug_kebab_case_3_to_6_words", slug_ok, f"slug={slug!r}"))

    # 3. seoTitle <= 60
    seo_title = draft.get("seoTitle", "") or ""
    checks.append(check(
        "seo_title_max_60_chars",
        bool(seo_title) and len(seo_title) <= 60,
        f"len={len(seo_title)}",
    ))

    # 4. metaDescription 130-170
    meta_desc = draft.get("metaDescription", "") or ""
    checks.append(check(
        "meta_description_130_to_170_chars",
        bool(meta_desc) and 130 <= len(meta_desc) <= 170,
        f"len={len(meta_desc)}",
    ))

    # 5. body >= 600 words
    body = draft.get("body", "") or ""
    word_count = len(body.split())
    checks.append(check("body_min_600_words", word_count >= 600, f"words={word_count}"))

    # 6. no em dash in body
    checks.append(check("no_em_dash", EM_DASH not in body, f"count={body.count(EM_DASH)}"))

    # 7. no jargon banlist words in first 100 words (skip-pass if list empty)
    jargon_banlist = [w.lower() for w in (seo_cfg.get("jargonBanlist") or [])]
    if jargon_banlist:
        first_100_words = " ".join(body.split()[:100]).lower()
        jargon_hits = [w for w in jargon_banlist if re.search(rf"\b{re.escape(w)}\b", first_100_words)]
        checks.append(check("no_jargon_in_first_100_words", not jargon_hits, f"hits={jargon_hits}"))
    else:
        checks.append(check("no_jargon_in_first_100_words", True, "skip-pass: jargonBanlist empty"))

    # 8. links to pillarPath (skip-pass if empty)
    pillar_path = seo_cfg.get("pillarPath") or ""
    if pillar_path:
        checks.append(check("links_to_pillar", pillar_path in body, f"pillarPath={pillar_path!r}"))
    else:
        checks.append(check("links_to_pillar", True, "skip-pass: pillarPath empty"))

    # 9. links to ctaPath (skip-pass if empty)
    cta_path = seo_cfg.get("ctaPath") or ""
    if cta_path:
        checks.append(check("links_to_cta", cta_path in body, f"ctaPath={cta_path!r}"))
    else:
        checks.append(check("links_to_cta", True, "skip-pass: ctaPath empty"))

    # 10. no question opener
    opener = first_sentence(body)
    checks.append(check("no_question_opener", not opener.rstrip().endswith("?"), f"opener={opener[:60]!r}"))

    # 11. category in config.seo.categories (skip-pass if empty)
    categories = seo_cfg.get("categories") or []
    category = draft.get("category", "") or ""
    if categories:
        checks.append(check("category_valid", category in categories, f"category={category!r}"))
    else:
        checks.append(check("category_valid", True, "skip-pass: categories empty"))

    # 12. keywords 4-8
    keywords = draft.get("keywords", []) or []
    checks.append(check("keywords_count_4_to_8", 4 <= len(keywords) <= 8, f"count={len(keywords)}"))

    return checks


def main():
    if len(sys.argv) != 3:
        print(json.dumps({
            "ok": False,
            "error": "usage: eval_blog_draft.py <path-to-draft.json> <path-to-tenant-config.json>",
        }))
        sys.exit(1)

    draft_path = sys.argv[1]
    config_path = sys.argv[2]

    try:
        with open(draft_path, "r", encoding="utf-8") as f:
            draft = json.load(f)
    except Exception as e:
        print(f"@@EVAL_JSON@@ {json.dumps({'ok': False, 'error': f'draft: {e}'})}")
        sys.exit(1)

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
    except Exception as e:
        print(f"@@EVAL_JSON@@ {json.dumps({'ok': False, 'error': f'config: {e}'})}")
        sys.exit(1)

    checks = run_checks(draft, config)
    passed = sum(1 for c in checks if c["passed"])
    total = len(checks)
    result = {
        "ok": True,
        "slug": draft.get("slug", ""),
        "primaryKeyword": draft.get("primaryKeyword", ""),
        "passed": passed,
        "total": total,
        "checks": checks,
    }
    print(f"@@EVAL_JSON@@ {json.dumps(result)}")


if __name__ == "__main__":
    main()

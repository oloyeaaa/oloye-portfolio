---
name: week-of-posts
description: Turn one idea (or a quick voice note) into a week of ready-to-post social media captions in the business's voice, with hashtags, optionally scheduled to its channels. Use for "a week of posts", "write my social posts", "content for the week", "post pack", "I don't know what to post", "fill my content calendar".
allowed-tools: Read, Write, Edit, Grep, Glob, AskUserQuestion
---

# Week of Posts: a week of posts in 5 minutes

"I know I should post but I never do, and I don't know what to say." Give one idea about the business (typed
or a voice note) and get a week of posts in its voice, ready to copy-paste, optionally scheduled.

## Step 0: resolve the tenant

Parse `--business <slug>` from the arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the user to run `/marketing-team:setup` and stop.

## What I need

1. **The business:** what it does, who for, its town or market. Pull from `config.brand.oneLiner` and
   `config.brand.audience`; only ask if missing.
2. **One seed:** a topic, an offer, a story, a question, or just "I don't know, here's what we do". A voice
   note is perfect.
3. **Channels:** from `config.channels.primary`; confirm once if not already set.

## What I make (the weekly mix)

7 posts across a proven mix so it's never samey:
1. A quick tip the customers actually want
2. Behind the scenes (a real moment)
3. A customer win / before-after (only if true)
4. What the business does + a clear next step (the soft offer)
5. A myth or mistake in the trade
6. A question that gets comments
7. Something human / local (the town, the team)

Each post: a scroll-stopping first line, plain words (no jargon), one clear point, ~5 relevant hashtags. In
the business's voice, for its customers, never generic AI mush.

## Speak from the Brain

Follow the brain-loop contract at `${CLAUDE_PLUGIN_ROOT}/skills/brain-loop/SKILL.md`:
1. **Before writing:** read Active Lessons where Area = `content` (plus `general`) and apply every one as a
   hard constraint.
2. **After writing:** log one Content row (Title = `<seed topic> (week-pack)`, Type = `week-pack`, Status =
   `review`, Body = the 7 posts following the contract's long-body rule (in local mode a week of posts is
   always over the ~500 character limit, so save it as `content/<kebab-title>.md` and put that path in the
   Body cell), Source URL = blank unless one exists, Created = today).
3. If the Brain is unreachable, say so, skip logging, and never block delivery of the posts.

## What I do

1. Confirm business + vibe + channels (once).
2. Write the 7 posts, labelled by day + type.
3. **Giveaway line (conditional):** if `config.brand.cta.keyword` is set, close one post (usually the tip or
   the offer post) with "Comment `<keyword>` and I'll send you..." pointing at whatever the business wants to
   give away. If `config.brand.cta.keyword` is empty, skip the giveaway line entirely, use
   `config.brand.cta.primary` / `config.brand.cta.url` instead.
4. **(Optional) Schedule them.** If `config.channels.scheduler` is `metricool` AND the Metricool MCP is
   connected, propose a day-by-day schedule and use the Metricool tools to create the scheduled posts. Show
   the schedule first; never post without a yes. If the scheduler is not `metricool`, or the MCP is not
   connected, output a paste-ready schedule table instead (day, time, channel, post) so the posts can be
   pasted into any scheduler by hand.
5. **Deliver as one document.** Compile all 7 posts into a single markdown file under
   `~/.claude/marketing-team/brain/<slug>/posts-<date>.md` (or the equivalent Airtable/Brain location if
   `config.brain.mode` is `airtable`), and print the full pack in chat.

## Guardrails

- Never invent a customer result, review, or stat. If a post needs proof that doesn't exist, swap it for one
  that's true.
- Match `config.language` (e.g. British English, plain). No jargon, no emoji spam, no "in today's fast-paced
  world".
- One point per post. Scannable. The business's voice, not a robot's.
- Before delivery, run the finished pack through the `brand-voice` skill.

## Give it away (conditional on config.brand.cta.keyword)

If `config.brand.cta.keyword` is set, use it as the trigger word for whichever post carries the giveaway
line. If it is empty, skip the giveaway block entirely and rely on the standard CTA.

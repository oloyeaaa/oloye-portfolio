---
name: youtube-pipeline
description: Take a YouTube video that already performs and make your OWN long-form 16:9 version, narrated in your ElevenLabs voice over screen recordings, ZERO talking head. Downloads + transcribes (Whisper) + Claude-vision reverse-engineers the video into structure (keep) vs swappable content slots (replace), asks you to fill the slots with your own content, then writes a long-form narration voiceover script (paste-ready for ElevenLabs) plus a synced screen-recording plan, chapters, 3 titles, and a description. Never invents your opinions. Use for "make my version of this youtube video", "turn this youtube video into my own", "reverse-engineer this youtube tutorial", "youtube script from this video".
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, Skill
---

# YouTube Pipeline - a proven YouTube video becomes YOUR long-form version

The long-form counterpart to `reel-pipeline`. You find a YouTube video on your topic that performs. This makes your own **long-form 16:9 tutorial**: same concept and proven structure, your content and take, **narrated in your ElevenLabs voice over screen recordings**. No face, ever.

It returns:
- **`title_options`** - 3 searchable + curiosity YouTube titles.
- **`sections`** - each a chapter: the **narration** (voiceover) plus the exact **screen recording** to capture and any on-screen text, synced.
- **`narration_full`** - all the narration joined, clean, **paste straight into ElevenLabs** with your cloned voice.
- **`chapters`** - YouTube chapter list.
- **`youtube_description`** - description with one CTA.
- **`missing`** - anything it needed from you and didn't get (it flags gaps, never invents your opinions).

## Step 0 - tenant resolution (do this first, every time)

Parse `--business <slug>` from arguments. If absent, read `defaultBusiness` from
`~/.claude/marketing-team/config.json`. Load `~/.claude/marketing-team/businesses/<slug>.json`. If that file
is missing, tell the user to run `/marketing-team:setup` and stop. Never type a literal brand value, CTA, or
ID; everything comes from this config.

## Prerequisites
This skill does not ship its own engine code. It reuses `reel-pipeline`'s engine, which ships in this same
plugin:
1. Check the long-form generator exists: `${CLAUDE_PLUGIN_ROOT}/skills/reel-pipeline/scripts/generate_youtube.py`.
2. Install the engine's Python dependencies once: `pip install -r ${CLAUDE_PLUGIN_ROOT}/skills/reel-pipeline/scripts/requirements.txt`.

## Shared engine (do NOT duplicate)
This skill reuses the `reel-pipeline` engine. All scripts live at
`${CLAUDE_PLUGIN_ROOT}/skills/reel-pipeline/scripts/`. The only difference is `--platform youtube`, which
swaps the final stage to `generate_youtube.py` (long-form narration voiceover instead of a to-camera reel
script). Edit the engine in `reel-pipeline/scripts/`, never fork a second copy.

## Setup (one-time)
Same as reel-pipeline. ffmpeg + ffprobe on PATH, Python 3.10+, and `ANTHROPIC_API_KEY` in
`reel-pipeline/scripts/.env`. **No Instagram cookies needed** (YouTube downloads are public). yt-dlp handles YouTube natively.

## Write the tenant's voice rules before generating (do this every run)
Same mechanism as `reel-pipeline`: before generating, write
`${CLAUDE_PLUGIN_ROOT}/skills/reel-pipeline/scripts/voice-rules.txt` from
`~/.claude/marketing-team/businesses/<slug>.voice.md` so the shared engine narrates in the tenant's own voice.
If no voice profile exists yet, run the calibration interview from the `brand-voice` skill first, or fall back
to the engine's built-in default voice and say so.

## How to run it (two phases)
Run from the shared scripts dir:
```bash
cd ${CLAUDE_PLUGIN_ROOT}/skills/reel-pipeline/scripts
```
PowerShell equivalent:
```powershell
Set-Location "$env:CLAUDE_PLUGIN_ROOT\skills\reel-pipeline\scripts"
```

### Phase A - reverse-engineer the video, see what it needs from you
```bash
python main.py "<youtube url>" --platform youtube --analyze-only
```
Downloads, transcribes, and breaks the video into structure + swappable slots. Prints the topic, hook, format, and exactly what content it needs from you. Writes `output/<id>/fill_template.json`.

> Long videos take time: Whisper runs locally on CPU, and a multi-minute video can take several minutes to transcribe. Frame extraction is capped at 40 scene frames, so the vision cost stays bounded.

### Phase B - you supply your content, it writes your long-form script
Read the printed slots to the user, get their own picks/take/CTA (the CTA should default to
`config.brand.cta.primary` / `config.brand.cta.keyword` unless they want something different for this piece),
write them into a fill file's `mine`/`my_take`/`cta` fields, then:
```bash
python generate_youtube.py output/<id>/transcript.json output/<id>/timeline.json "the creator's angle/audience" --fill output/<id>/fill.json > output/<id>/youtube_output.json
```
Note: the standalone `generate_youtube.py` prints the JSON to stdout, so the redirection above is what writes `youtube_output.json`. Only the full `main.py` run saves the file itself.
Or a full run in one go:
```bash
python main.py "<youtube url>" --platform youtube --brief "the creator's angle" --fill output/<id>/fill.json
```
The `main.py` route saves `output/<id>/youtube_output.json` itself; the standalone `generate_youtube.py` route relies on the stdout redirection shown above.

### Then the voiceover (ElevenLabs, you do this)
Take `narration_full` and paste it into ElevenLabs, generate with your cloned voice, and drop the audio into your editor. The `sections` tell you which screen recording lines up with which part of the narration.

### Learning - read Active lessons and inject them (before generating)
Same shared ledger as `reel-pipeline`, contract at `skills/brain-loop/SKILL.md`. Before the generate step:
read Lessons rows where `Active` = true and `Area` in {`content`, `general`} (local or Airtable mode, per
`config.brain.mode`). Write the `Rule` strings to `output/<id>/lessons.json` and pass
`--lessons output/<id>/lessons.json` to `main.py`/`generate_youtube.py`. Injected as hard constraints.

### Then polish + deliver
1. Run the narration + titles + description through the **`brand-voice`** skill for the public pass.
2. Default delivery: a clean local markdown file (titles, narration, screen plan, chapters, description),
   saved and pointed at in chat. Only deliver as a formatted **Google Doc** if BOTH the Google Drive MCP is
   connected AND the buyer asks for it: build clean HTML (h1 title, h2 sections: Titles / Narration for
   ElevenLabs / Screen plan table / Chapters / Description) and create it with
   `mcp__(your Google Drive MCP)__create_file` (`contentMimeType: "text/html"`, `textContent: "<html>"`).
   Title it `YouTube Script - <topic> (<config.brand.wordmark>)`. Return the `viewUrl`. The `.json` stays as
   the working copy either way.

### Memory - log to the Content table (after delivery)
Log ONE Content row per `skills/brain-loop/SKILL.md`:
- Title: `<topic> (youtube)`
- Type: `long-form`
- Status: `review`
- Body: `narration_full` + one-line provenance (source URL, section count, CTA) + the local file path or Doc link
- Source URL: the video it was modelled on

The memory + learning loop is documented in full at `skills/brain-loop/SKILL.md`; the mechanism is identical
across skills, this is the same shared engine and the same shared Brain.

## Where this sits in the content chain
```
FIND / LEARN     →  a YouTube video that performs
REMAKE SCRIPT    →  youtube-pipeline (this)  →  brand-voice (polish)
NARRATE          →  ElevenLabs (your cloned voice) from narration_full
RECORD           →  you (screen recordings per the sections)
EDIT TO VIDEO    →  your editor: VO track + screen recordings + on-screen text
PUBLISH          →  YouTube (title + chapters + description all provided)
```
No talking head anywhere. You provide screen recordings; ElevenLabs provides the voice.

## Guardrails (inherited from the shared engine)
- Never invents your opinions. Unfilled slot → `[NEEDS FROM YOU: ...]` + listed in `missing`.
- Em dashes stripped from all output. `max_tokens=12000` with a truncation guard (long-form is longer).
- Voice: core brand-voice rules baked into the generator (sharpened by the tenant's `voice-rules.txt`);
  `brand-voice` skill is the canonical public pass.

## Common failures + fixes
- **Whisper very slow / stalls** on a long video → normal on CPU. Let it run, or trim the source, or raise timeout. Do not raise `WHISPER_MODEL` for speed (bigger = slower); only raise it for accuracy.
- **`yt-dlp failed`** → `pip install -U yt-dlp` (YouTube changed layout), or the video is private/age-gated.
- **ffmpeg not found** → install ffmpeg, ensure `ffmpeg`/`ffprobe` on PATH.

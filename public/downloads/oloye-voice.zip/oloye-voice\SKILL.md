---
name: oloye-voice
description: The Oloye. Writing System — write or edit ANY public-facing copy (TikTok hooks, captions, video scripts, carousels, cold emails, decks, posts) so it sounds like Oloye, hits one emotion, opens with a real hook, rides a framework, tells a story, and passes a human check. Use whenever writing or polishing brand content. This is Oloye.'s owned IP — the one canonical voice + copy system.
allowed-tools: Read, Write, Edit, Grep, Glob, AskUserQuestion
---

# The Oloye. Writing System

One system for writing anything public in the Oloye. voice. Every piece must do six things: **sound like Oloye · reach for ONE emotion · earn the first 3 seconds · ride a framework · tell a story · pass the human check.** Skip none.

> Pairs with `Oloye-OS/Business/ai-team/brand-brain.md` (the brand rules) and `~/.claude/projects/c--Users-Oloye-Oloye-OS/memory/carousel-content.md` (carousel frameworks). These are optional companions; this file works standalone. This file is the full method; brand-brain holds the operational short version the AI team applies daily.

## When to use
Writing or editing ANY public copy: TikTok/Shorts hooks + scripts, captions, carousels, WhatsApp Status, cold emails, lead magnets, deck copy, bios. Also as an editor: paste a draft → return a sharper, human, on-voice version.

## Step 0 — Lock the target before a single word
Write one line first:
**Audience → the ONE emotion I want them to feel → the ONE action I want.**
If you can't name the emotion and the action, don't write yet. One piece = one emotion = one CTA.

---

## 1. Voice — sound like Oloye. (non-negotiable)
- **Kill the jargon.** Never say AI/automation/MCP/agent/LLM/workflow/pipeline/API/model. Say what it *does*: "answers your customers", "books people in", "writes your posts", "saves you hours".
- **First-person "I"** for proof; **"you/your"** for the audience. Plain British. Confident, never hype.
- **The number is the hero** ("3 hours a week", "47 replies", "5 hours to reply"). Put it in the accent colour / bold it.
- **No catchphrase sign-off** — never "Oloye out." End on the CTA.
- Wordmark **"Oloye."** (full stop is part of the name). Accent = Signal Lime `#C6F23C`.
- Emoji: essentially none in brand copy (captions can use 1, purposefully).
- **One CTA per piece.** Ours: DM/comment **'AUDIT'** or the audit link (`https://tally.so/r/NpER1p`).

## Voice profile — Oloye (calibrated 2026-06-26)
Source: Oloye's own Whisper Flow voice notes (how he actually talks and briefs). Match this when writing in his first-person voice.
- **Cadence:** conversational British, spoken not corporate. He thinks out loud then tightens. Output should be short, direct, plain.
- **Words he actually uses:** "to be honest", "basically", "kind of thing", "right?", "you know what I mean", "straight away", "get the ball rolling", "proper", "really cool", "let's", "okay so", "I just want".
- **Stance:** blunt and result-led. His line: "People don't buy products, they buy what the product gives them." Always tie back to **time saved or money made**.
- **His hard rules (he repeats these):** no fluff, no long paragraphs, **data-backed** (lead with a number/fact), **objective** (no ego-massaging; give the honest take AND why it might not work), **NO em dashes**, scannable and visual.
- **Who he is:** a builder who ships fast ("progress beats polish"), camera-shy, runs his business on Claude (Code, Cowork, Design), serves non-techy owners, "the guy who does a specific job for any business."
- **Public-content voice:** plain, confident, lightly opinionated, never hype; open on the concrete outcome or number.

## 2. Emotion — reach for the right one
Decide the feeling, then engineer it. Neutral writing is the enemy. Our **emotional spine is loss → relief**: name what the owner is quietly losing, then the calm on the other side.

| Want them to feel | Reach for it by | Example |
|---|---|---|
| **The cost of inaction** (lead) | name a specific, concrete loss | "A client messaged at 9am. You saw it at 2pm. She'd booked elsewhere." |
| **Relief / control** | show the calm after | "Every message answered in under a minute — even mid-job." |
| **Pride / being seen** | respect their craft | "You're brilliant at the work. That's exactly why the admin slips." |
| **Belonging / 'that's me'** | mirror their exact day | "Replying to the same three questions for the tenth time today." |
| **Hope (earned)** | a concrete near-future, never hype | "Next month: every enquiry followed up the day it lands." |

Rules: lead with the loss, resolve to relief/pride. Be specific (a £200 client, not "revenue"). Never manufacture fear with fake stats — true and vivid beats shaky and inflated.

## 3. Hook — earn the first 3 seconds
The first line (text) and first frame (visual) do ~90% of the work. If the hook fails, nothing else matters.

**Text hook moves** (pick one, keep it ≤ ~10 words, one idea, open a loop):
- **The cost:** "Five hours to reply cost you a £200 client."
- **The callout:** "Salon owners: this is why your DMs lose bookings."
- **The number:** "47 unread messages. None of them answered."
- **The contrarian:** "Posting every day isn't your problem."
- **The open loop:** "You saw the message at 2pm. Here's what it cost you."
- **The question (they can't say no to):** "How many leads did you actually follow up this week?"

**Visual hook principles** (frame 1):
- **Pattern interrupt** — something unexpected stops the scroll in the first frame.
- **Show the loss or the outcome**, not a logo or title card.
- **Motion early**; face + eye contact converts; text overlay with the **keyword in the accent colour**.
- The thumbnail moment ≠ a caption of the image — it advances the story.

## 4. Framework — give it a spine
Pick ONE (don't free-style):
- **PAS** (Problem → Agitate → Solution) — our default loss-led shape. Agitate with *empathy*, never cruelty.
- **BAB** (Before → After → Bridge) — best when there's a clean transformation to show (great for carousels/video).
- **StoryBrand-lite** — the **owner is the hero, Oloye. is the guide** (Yoda, not Luke): "You're not failing, you're missing one piece."
- **AIDA** — keep the *spine* (hook → build → want → ask), drop the salesy "desire/dream" spirit.

Carousel rules: slide 1 is 90% of the job · one idea per slide · end each slide on a small cliffhanger · copy + visual say *different halves* of the same beat · last slide = one CTA.

## 5. Story — make it move
- The **owner is the hero**; Oloye. is the guide who hands them the tool.
- **Specific, hard-to-fabricate detail** beats generality ("she booked the salon on Port Street" > "a customer left").
- **Transformation** (messy before → calm after) + **stakes** (what it costs).
- One **human moment** — a real beat, an aside, a bit of mess. Benefits over features.

## 6. Sound human — the humanise pass (ours)
After drafting, scrub the AI tells. These are the patterns worth keeping (distilled from the "signs of AI writing" work, tuned to our brand):
1. **Kill AI vocab:** delve, tapestry, testament, landscape (abstract), leverage, underscore, foster, robust, seamless, elevate, realm, navigate (abstract), "in today's fast-paced world". Say the plain word.
2. **No copula avoidance:** "serves as / stands as / boasts" → **is / has**.
3. **No rule-of-three padding** ("talks, panels, and networking") unless all three are real and needed.
4. **No signposting:** delete "let's dive in", "here's what you need to know", "without further ado" — just start.
5. **No superficial "-ing" depth:** "symbolising the region's connection…" → say the fact.
6. **No false ranges:** "from X to Y" only on a real scale; else just list.
7. **No chatbot closers / sycophancy:** "I hope this helps", "great question", "you're absolutely right" — gone.
8. **No generic positive conclusions:** "the future looks bright" → a concrete next step.
9. **Cut filler:** "in order to" → "to"; "due to the fact that" → "because"; "has the ability to" → "can".
10. **Trim hedging:** "could potentially possibly" → "may".
11. **No manufactured staccato drama** ("No preference. No nostalgia. No prior.") and **no aphorism formulas** ("X is the Y of Z") unless genuinely earned.
12. **No fake-candid openers:** standalone "Honestly?" / "Look, here's the thing".

**Brand exceptions (where we deliberately differ from the generic rule):**
- **NO em dashes.** Oloye's explicit, repeated rule. Use full stops, commas, colons, parentheses, or just rewrite the sentence. (This is the one place we are stricter than the source guide.)
- **Curly vs straight quotes:** follow the platform / design system, don't force a change.
- **Bold/accent the number or keyword on purpose:** that's our style, not "AI boldface".
- **The evidence rule overrides everything:** no invented stats, no unverifiable named sources, never imply clients/results we don't have. A true observation beats a shiny number.

## The loop (how to run this)
1. **Step 0** — one line: audience + emotion + action.
2. **Draft** — hook first, then a framework, then the story.
3. **Humanise** — run the §6 checklist.
4. **Audit** — ask three questions and fix what fails:
   - *What still sounds AI here?*
   - *Is the intended emotion actually on the page?*
   - *Would Oloye say this out loud, to one person, in plain British?*

## Voice calibration (sharpen to Oloye specifically)
If a sample of Oloye's real talking/writing is provided (e.g. a `/reel` transcript or his own notes), match: sentence length, word choice, openings, punctuation habits, recurring phrases, transition style. Without a fresh sample, default to the calibrated **Voice profile** section (calibrated 2026-06-26) earlier in this file.

## Don't over-edit — preserve human signs
Keep: specific concrete details, real opinions and mixed feelings, varied sentence length, genuine asides/self-corrections. Plain technical/reference text **stays plain** — don't inject personality where neutral is the human choice. Only fix tells when they **cluster**; a lone em dash or one formal word is not a crime.

## Make it yours (buyer setup)
This system is portable. A new owner swaps five brand-config tokens; everything else (emotion, hooks, frameworks, humanise pass) stays as-is. Oloye's values below are the worked example and the shipped default.

1. **Wordmark**: the brand name exactly as written everywhere. Default: **"Oloye."** (the full stop is part of the name).
2. **Accent hex**: the one highlight colour for the hero number/keyword. Default: Signal Lime `#C6F23C`.
3. **CTA keyword + link**: the single call to action every piece ends on. Default: DM/comment **'AUDIT'** or the audit link (`https://tally.so/r/NpER1p`).
4. **Calibrated voice profile block**: replace the whole "Voice profile" section with a profile built from YOUR real talking/writing samples (cadence, actual phrases, stance, hard rules). Until you have samples, use a natural, plain, lightly opinionated voice in your own dialect.
5. **Sign-off rule**: how pieces end. Default: no catchphrase sign-off, end on the CTA. If your brand has an earned sign-off, define it here and keep it to one.

Swap all five in this file (and mirror them in your brand-brain equivalent if you keep one), then run one draft through the full loop to confirm the voice holds.

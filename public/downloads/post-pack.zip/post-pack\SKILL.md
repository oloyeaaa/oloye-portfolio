---
name: post-pack
description: Turn one idea (or a quick voice note) into a week of ready-to-post social media captions in your voice, with hashtags, optionally scheduled to your channels. Use for "a week of posts", "write my social posts", "content for the week", "post pack", "I don't know what to post", "fill my content calendar".
---

# Post Pack — a week of posts in 5 minutes

"I know I should post but I never do, and I don't know what to say." Give me one idea about your business (type it or send a voice note) and I write a week of posts in your voice, ready to copy-paste, optionally scheduled for you.

## What I need
1. **Your business:** what you do, who for, your town. One or two lines.
2. **One seed:** a topic, an offer, a story, a question, or just "I don't know — here's what we do". A voice note is perfect.
3. **Your vibe + channels** (Instagram / Facebook / TikTok / WhatsApp). I ask once.

## What I make (the weekly mix)
7 posts across a proven mix so it's never samey:
1. A quick tip your customers actually want
2. Behind the scenes (a real moment)
3. A customer win / before-after (only if true)
4. What you do + a clear next step (the soft offer)
5. A myth or mistake in your trade
6. A question that gets comments
7. Something human / local (your town, your team)

Each post: a scroll-stopping first line, plain words (no jargon), one clear point, ~5 relevant hashtags. In YOUR voice, for YOUR customers, never generic AI mush.

## Speak from the Brain (Oloye. content only)
If `~/.claude/skills/_shared/brain-content-loop.md` does not exist on this machine, skip this section entirely; the skill works standalone. When this is producing **Oloye.'s own** posts (not a client's), apply the Content Brain Loop (`~/.claude/skills/_shared/brain-content-loop.md`): read Active Lessons from the Lessons table `YOUR_LESSONS_TABLE_ID` and obey them (e.g. "name a number/tool in every hook", "no em dashes"), then log the week to the Content table (Format=`post`, Owner=<you>). For a CLIENT's posts, do NOT write to Oloye.'s Brain, keep their content out of it.

## What I do
1. Confirm business + vibe + channels (once).
2. Write the 7 posts, labelled by day + type.
3. **(Optional) Schedule them** across the week with the Metricool tool. I show you the schedule first. I don't post without your yes. If Metricool is not connected, I output a day-by-day schedule table instead (day, time, channel, post) so you can post manually or paste into any scheduler.
4. **Deliver as one document.** Compile all 7 posts into a single document: a Google Doc for Oloye. (via the Google Drive connection), or a formatted text/markdown file otherwise. For Oloye.'s own content, log that document link to the Brain alongside the Content table entry.

## Guardrails
- Never invent a customer result, review, or stat. If a post needs proof you don't have, I swap it for one that's true.
- Match the user's locale (Oloye. default: plain British). No jargon, no emoji spam, no "in today's fast-paced world".
- One point per post. Scannable. Your voice, not a robot's.
- Before delivery, run any finished Oloye.-brand copy through the `oloye-voice` skill.

## Demo (build-in-public)
Send one voice note about your business → 7 finished posts appear → (optional) watch them get scheduled across the week in Metricool. On screen: **"A week of posts from one voice note."**

## Give it away
Trigger word: **POSTS**. CTA: "Comment POSTS and I'll send you this so you can fill your week in 5 minutes." Delivery = via the free community (join to get the skill + how-to).

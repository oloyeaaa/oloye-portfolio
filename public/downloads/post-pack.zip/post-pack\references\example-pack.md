# Example Week Pack (FICTIONAL business)

> **This entire pack is a worked example for a FICTIONAL business.** "Brew Lane Coffee" does not exist. Every detail, customer, and result below is invented for demonstration only. Never reuse these claims for a real client.

**Business:** Brew Lane Coffee, an independent coffee shop on the high street in Walthamstow, East London. Speciality coffee, fresh pastries, dog friendly.
**Seed idea:** "People keep asking why our flat whites taste different from the chains."
**Vibe:** warm, local, a bit cheeky. **Channels:** Instagram + Facebook.

---

## Monday: Quick tip

Your coffee at home tastes flat for one boring reason: stale beans.

Roasted coffee is at its best 5 to 21 days after the roast date. Most supermarket bags were roasted months ago. Check the bag. If there is no roast date on it, that is your answer.

Pop in and we will show you what a two-week-old roast actually tastes like.

#Walthamstow #CoffeeTips #SpecialityCoffee #EastLondon #IndependentCoffee

---

## Tuesday: Behind the scenes

6:12am. The first batch of croissants just came out and the whole shop smells like butter.

This is the bit of the job nobody sees. Ade has been laminating dough since 4:30 so they are ready when the doors open at 7. If you have ever wondered why we sell out by 10, this is why. They are made here, that morning, every morning.

#BehindTheScenes #Walthamstow #FreshPastries #LocalBakery #EastLondonCoffee

---

## Wednesday: Customer win (fictional example)

"I drove past this place for a year. Now I plan my week around it."

That is from Priya, who came in for a takeaway flat white in January and now runs her Wednesday book club from our back table. Wins like this are why we opened. Your local can be more than a coffee stop.

(Reminder: in a real pack this must be a true, permissioned quote. This one is invented for the example.)

#CustomerLove #Walthamstow #CommunitySpot #BookClub #IndependentCoffee

---

## Thursday: What we do + soft offer

We do three things: proper coffee, morning-baked pastries, and a table you can sit at for as long as you like.

No memberships, no minimum spend, dogs welcome. If you work from home in Walthamstow and the walls are closing in, come work from ours. First oat flat white is on us this week if you mention this post.

Find us at 42 Brew Lane, open 7am to 5pm.

#Walthamstow #WorkFromCafe #CoffeeShop #EastLondon #LocalBusiness

---

## Friday: Myth or mistake

Myth: darker roast means stronger coffee.

It does not. Dark roasts often have LESS caffeine and the roast can hide the flavour of the bean. What people call "strong" is usually just "burnt". A well-made light or medium roast will wake you up just as fast and taste of something.

Ask us for a side-by-side next time you are in. It changes minds.

#CoffeeMyths #CoffeeFacts #SpecialityCoffee #Walthamstow #CoffeeLovers

---

## Saturday: Question post

Settle an argument for us: does a proper flat white come in a small cup or a regular one?

Half the team says 160ml or it is just a latte. The other half says people want their money's worth. Vote in the comments: SMALL or REGULAR. Winning side picks Monday's pastry special.

#FlatWhite #CoffeeDebate #Walthamstow #EastLondon #CoffeeShop

---

## Sunday: Human / local

Walthamstow, you have kept a tiny coffee shop alive for three years this week.

Not a chain, not an investor, just the two of us, a secondhand espresso machine, and the same forty faces who came back every day until strangers became regulars. Thank you. Cake on the counter all day today. Come and have a slice.

#Walthamstow #ThreeYears #ShopLocal #EastLondon #CommunityLove

---

## Why this pack passes the rules

- Every post opens with a scroll-stopping first line, not "We are excited to announce".
- One clear point per post, scannable, plain British, no jargon.
- Around 5 relevant hashtags each, mixing local + topic.
- The customer win is clearly flagged as fictional; in a real pack it must be true or swapped out.
- The mix follows the skill's weekly formula: tip, behind the scenes, win, offer, myth, question, human/local.

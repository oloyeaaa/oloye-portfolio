---
name: product-ad
description: Turn a product (image or store URL) into a finished short-form video ad on your own fal.ai stack, either a CINEMATIC story ad (moody, premium, model + product + end card) or a HUMAN UGC ad (AI creator talking to camera). Builds stills with nano-banana, animates beats with Veo 3 (native audio), assembles with ffmpeg (crossfades + branded end card), then logs the real time + cost to the proof-numbers loop. Use for "make an ad for this product", "UGC ad", "cinematic product ad", "turn this product into a video", "VOYAGE-style ad", "make a video ad for [brand]".
---

# Product Ad — the UGC / cinematic ad pipeline

Proven 2026-06-29 (JRIP VOYAGE): a 25s cinematic product ad for ~£9.5 in ~20 min, all on our own fal stack.
This skill repeats that. It uses the **render-room** engine for fal calls and **ffmpeg** for assembly.

## When to use this vs motion-design
- **product-ad** (this skill) = the fal stack: UGC and product story ads with native audio (nano-banana stills, Veo 3 animation, ffmpeg assembly).
- **motion-design** = Higgsfield motion graphics generated from a logo or product image. Use that skill for logo animations and kinetic-graphics promos.

## Speak from the Brain (Oloye. content only)
Only applies **if this install has the Oloye. Brain configured**; otherwise log time + cost to a local `proof-numbers.md` next to the output and skip this section. This is usually a CLIENT/prospect deliverable, keep those OUT of Oloye.'s Brain (proof-numbers loop only). But when the ad is **Oloye.'s own** brand content, also log it to the Content table per the Content Brain Loop (`~/.claude/skills/_shared/brain-content-loop.md`): `YOUR_CONTENT_TABLE_ID`, Format=`ad`, Owner=`<you>`, Status=`review`, Link, Copy.

## Inputs to get first
- **Product image** — a clean product shot (local path or public URL). If only a store URL, scrape it
  (Firecrawl) and pick the hero product image.
- **Brand context** — name, price, vibe (e.g. "luxury fragrance, dark + gold").
- **Mode** — `cinematic` (story ad) or `ugc` (human creator talking). Default to asking which.
- **Budget nod** — video gen is the paid part; Veo 3 dominates. State the estimate and confirm before paid steps.

## Engine + key
- fal engine: `python "~/.claude/skills/render-room/render_room.py" <cmd> --model <slug> ...`
- Requires: the **render-room** skill installed, Python 3, ffmpeg on PATH, and a fal.ai account.
- Key: use the `FAL_KEY` environment variable. If it is not set, ask the user where their fal key
  lives and load it into the process from there. Never echo, print, or put the key value on a
  command line.
- Parse the `@@RENDER_JSON@@` line; use `files` (local) / `urls` (fal-hosted) from it.

## Proven model slugs (verify on fal.ai/models; they drift)
- Image (stills): `fal-ai/nano-banana`  (`--arg aspect_ratio=9:16`)
- Image edit w/ product ref: `fal-ai/nano-banana/edit`  — **pass `--image` TWICE** (model needs `image_urls`),
  or pass a **public URL** (local upload sometimes 403s).
- Human/talking + cinematic motion (native audio): `fal-ai/veo3/image-to-video`  (`--arg duration=8s --arg generate_audio=true`)
- Cheap product motion: `fal-ai/kling-video/v2.1/standard/image-to-video`  (`--arg duration=5`)

## MODE A — Cinematic story ad (3 beats)
1. **Beat 1 (hero):** `image` nano-banana — the model/scene (e.g. "dark-skinned woman, fitted dress, neon rain
   street, cinematic grade, 9:16"). Show it; lock the look before animating.
2. **Beat 2 (product):** `edit` nano-banana/edit with the real product image as ref — place the EXACT product in
   a dark cinematic scene (raking light, smoke, reflection, label crisp).
3. **Beat 1 + 2 + 3 animate:** `video` veo3/image-to-video from each still. Beat 1 = confident walk (no
   dialogue, ambient). Beat 2 = slow push-in on bottle. Beat 3 = animate the hero again → turn-to-camera close.
4. **End card:** ffmpeg `drawtext` (see below).
5. **Assemble** with crossfades (see below).

## MODE B — Human UGC ad
1. `image` nano-banana OR `edit` (with product ref so they hold the REAL product) — a photoreal creator holding
   the product, authentic phone-selfie look ("imperfect skin, grainy phone camera, not glossy"). Less crisp = more real.
2. `video` veo3/image-to-video from that still — they talk a short line to camera (native audio). Walking or static.
3. Optional: add burned captions (Descript — but import via a URL/Drive link; direct upload has failed) or
   ffmpeg drawtext.

## End card (ffmpeg)
```
FONT="C\:/Windows/Fonts/georgia.ttf"
ffmpeg -y -f lavfi -i color=c=0x0A0A0A:s=720x1280:d=3.5:r=24 -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 \
 -vf "drawtext=fontfile='$FONT':text='BRAND':fontcolor=0xD9C28A:fontsize=86:x=(w-text_w)/2:y=520, drawtext=fontfile='$FONT':text='TAGLINE':fontcolor=white:fontsize=30:x=(w-text_w)/2:y=640, fade=in:0:12" \
 -c:v libx264 -pix_fmt yuv420p -r 24 -c:a aac -shortest endcard.mp4
```

## Assemble with crossfades (ffmpeg)
All clips 720x1280 @ 24fps. Chain xfade (video) + acrossfade (audio); offset = running_length - overlap.
```
ffmpeg -y -i b1.mp4 -i b2.mp4 -i b3.mp4 -i endcard.mp4 -filter_complex \
 "[0:v]scale=720:1280,setsar=1,fps=24,format=yuv420p[v0];\
  [1:v]scale=720:1280,setsar=1,fps=24,format=yuv420p[v1];\
  [2:v]scale=720:1280,setsar=1,fps=24,format=yuv420p[v2];\
  [3:v]scale=720:1280,setsar=1,fps=24,format=yuv420p[v3];\
  [v0][v1]xfade=transition=fade:duration=0.7:offset=7.3[x1];[x1][v2]xfade=transition=fade:duration=0.7:offset=14.6[x2];\
  [x2][v3]xfade=transition=dissolve:duration=0.9:offset=21.9[v];\
  [0:a][1:a]acrossfade=d=0.7[a1];[a1][2:a]acrossfade=d=0.7[a2];[a2][3:a]acrossfade=d=0.9[a]" \
 -map "[v]" -map "[a]" -c:v libx264 -pix_fmt yuv420p -c:a aac -movflags +faststart final.mp4
```
Compute the offsets from YOUR actual clip durations (probe each with `ffprobe`), do not reuse the
example numbers blindly:
- `offset_1 = duration(clip_1) - crossfade_1`
- `offset_n = offset_(n-1) + duration(clip_n) - crossfade_n` (cumulative: each new offset adds the
  next clip's duration minus that transition's crossfade).
The 7.3 / 14.6 / 21.9 above are just the values from the proven JRIP VOYAGE run (approx 8s beats
with 0.7s fades and a 0.9s dissolve into the end card).
Add a single music bed (replace disjointed per-beat audio): generate a track (fal/Higgsfield) and
`-stream_loop`/`amix` it under the video at low volume with an end fade.

## Cost + time (set expectations, confirm before paid)
- Veo 3 i2v (8s, audio) ≈ ~$4 each — THE cost driver, keep beats few/short.
- nano-banana still ≈ ~$0.04; Kling 5s ≈ ~$0.30.
- A 3-beat cinematic ad ≈ **~£10, ~20 min**. Always state the estimate and get a yes before video renders.

## Close the loop (required)
After delivery, log the REAL time + cost:
- **If this install has the Oloye. Brain configured:** log to `Business/foundation/proof-numbers.md`
  (+ a Content table row). These feed <you>'s hooks and Ben's pricing.
- **Otherwise:** log time + cost to a local `proof-numbers.md` next to the output.
Numbers must be REAL, never inflated.

## <YOUR BRAND> product ads: AutoDS UGC + brand-wrap (default for <YOUR BRAND> volume)
For <Your Brand> PRODUCT ads, the default is NOT to hand-build on this stack — it's the hybrid:
1. **Claude writes the script** (your product wedge, from `Projects/<your-brand>/products/your product-angle.md`;
   applicator/mess claims only, no growth claims).
2. **Oloye runs it in AutoDS** on the correct SKU from his catalogue (AutoDS provides the presenter + product + captions).
3. **Brand-wrap the raw export** with one command (Crown Green frame + crown mark + wordmark + "<your tagline>"
   + @<your-brand> + warm grade + end-card):
   `bash Projects/<your-brand>/brand/your-brand.sh "raw.mp4" "<YOUR BRAND>-<slug>.mp4" "<endcard.mp4>"`
Use THIS stack (below) for <YOUR BRAND> branded/hero pieces AutoDS can't do, and for ALL Oloye. agency content.
Claude also owns the **SEO product listing** (title/description/tags) — see `content/autods-workflow.md`.
Full split + loop: `Projects/<your-brand>/content/autods-workflow.md`.

## FIRST: which brand is this for? (firewall)
Oloye. (agency) and <Your Brand> (ecom brand) are **separate entities — never mix**. Declare the entity before you
build: **<YOUR BRAND>** = product/shop content, consumer voice, @<your-brand>, brand block below. **Oloye.** = "how I built
it" / teardown / lead magnet, agency voice + look. Rules: `Projects/<your-brand>/brand-firewall.md`.

## <Your Brand> brand (use for <YOUR BRAND> content — implemented 2026-07-01)
When making content for Oloye's own brand **<Your Brand>**, apply its identity (tokens:
`Projects/<your-brand>/brand/tokens.md` + `your-brand.css`; guidelines HTML in `brand/your-brand/`):
- **Colours:** Crown Green `#123D30` (hero) · Forest `#1B5E4B` · **Regal Gold `#C9A24B`** (accent/CTA) · Bone
  `#F5F1E8` · Ink `#111`. Ratio ~60 green / 30 bone / 10 gold. (NOT the Oloye. agency lime.)
- **Fonts:** Sora (display/wordmark) + Manrope (body).
- **Wordmark:** <YOUR BRAND> (bold) + scalp (lighter). **Crown mark** = three rising points. **Tagline: "<your tagline>"**
- **Hooks:** "your product, minus the mess." + the VOC lines in `products/your product-angle.md`.
- End-cards/captions: green bg, gold accent, Sora headline, gold CTA pill, crown mark + wordmark.
- **Logo pack (use real files, not drawtext):** `Projects/<your-brand>/brand/logo/` — `your-brand.png`
  (overlay on green end-card), `your-brand.png` / `your-brand.png`, `your-brand.png`.
  Watermark = `your-brand.png` at ~8% opacity, bottom-right.

### <YOUR BRAND> end-card (branded, ffmpeg — overlay the real mark)
```
BG=0x123D30; GOLD=0xC9A24B; BONE=0xF5F1E8
MARK="<workspace-root>/Projects/<your-brand>/brand/logo/your-brand.png"
FONT="C\:/Windows/Fonts/segoeui.ttf"   # sub Sora if installed
ffmpeg -y -f lavfi -i color=c=$BG:s=720x1280:d=3.5:r=24 -i "$MARK" \
 -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 \
 -filter_complex "[1:v]scale=220:-1[m];[0:v][m]overlay=(W-w)/2:360[bg];\
  [bg]drawtext=fontfile='$FONT':text='<your tagline>':fontcolor=$BONE:fontsize=44:x=(w-text_w)/2:y=640,\
  drawtext=fontfile='$FONT':text='Shop on TikTok  @<your-brand>':fontcolor=$GOLD:fontsize=26:x=(w-text_w)/2:y=720,\
  fade=in:0:12[v]" \
 -map "[v]" -map 2:a -c:v libx264 -pix_fmt yuv420p -r 24 -c:a aac -shortest your-brand.mp4
```

## Quality bar (from the ICP personas)
Show the product accurately; premium not "AI slop"; for human UGC make it less crisp / authentic. Tie to a
business outcome, not vanity. Honesty: no fake testimonials, no claimed client results.

## Output location
Ask the user where to save. Default: `product-ads/<brand>/` in the current workspace, with a short
README (beats, models, the final mp4, time + cost). Keep a numbered file per stage.
On Oloye's machine the example default is
`<workspace-root>\Business\foundation\6-swipe-files\ugc-tests\<brand>\` (or a client folder).

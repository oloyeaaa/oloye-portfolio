# Install , 5 minutes, no terminal

## 1. Put the skill in Claude
**Claude Desktop or claude.ai:** make a Project, upload `SKILL.md` and `questions-template.md` into the
project knowledge.
**Claude Code:** drop the `question-bank` folder into `~/.claude/skills/` and restart.

## 2. Collect your questions
Fill in `questions-template.md`. Ten minutes scrolling your own DMs, emails, reviews and comments is plenty.
Paste them raw, typos and all.

**No questions to hand?** Skip this step. Just fill in the two lines at the top (what you do, who you help)
and the skill works the questions out for you.

## 3. Run it
In the project, say:
```
fill my question bank
```
Paste your template (or your rough list) when it asks.

You get back a numbered table: about 30 post ideas, one per question, each with a hook under 10 words, what
to say, and the format (reel, carousel or caption), grouped into weeks. Work straight from the table, one row
a day.

---

## When it will not help
- It gives you the **ideas**, not the finished posts. You still write and post them.
- It never invents facts about your business. Anywhere you see `[your answer]`, fill it in before posting.
- If your answers are thin, the ideas will be thin. The value is your real answers to real questions.

---

*Free skill by Oloye.*

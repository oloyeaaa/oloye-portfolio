# question-bank — install

This is a Claude Code skill. Code and docs only: no API keys, no cookies, no
personal data. Check MANIFEST.txt against the unzipped folder to confirm.

## Install
1. Unzip this folder.
2. Copy the "question-bank" folder into your skills directory:
   ~/.claude/skills/question-bank/
3. If it has a requirements.txt, run: pip install -r requirements.txt
4. Restart Claude Code so it picks up the new skill.

## Notes
- Any value written as YOUR_..._ID or <workspace-root> is a placeholder for you
  to set to your own. The skill runs without the optional Airtable (Brain) parts.
- Free to use. From Oloye. — https://oloye.co.uk/skills

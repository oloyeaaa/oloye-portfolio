# My questions, rough is fine

Fill what you can. Skip what you can't. The skill works either way.

## What I do
[one line, e.g. "I coach first-time managers" or "I sell handmade candles"]

## Who I help
[one line, e.g. "new team leads in corporate jobs" or "people buying gifts"]

## Questions people actually ask me
Paste them raw. DMs, emails, reviews, comments, out loud at the till. Typos and all.

1.
2.
3.

If this list is empty, that is fine. The skill will work the questions out from the two lines above and leave a [your answer] placeholder anywhere it needs a fact only you know.

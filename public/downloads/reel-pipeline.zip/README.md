# Reel Pipeline

A Claude Code skill that takes an Instagram reel that is already getting engagement and makes YOUR version: same concept, same proven format, your content and your take.

It never copies the original's words and never invents your opinions. It reverse-engineers the reel into a format, asks you to fill that format with your own picks and takes, then writes your script with 3 hook options and a camera-shy-friendly shot list.

**No API key needed.** The heavy lifting (download, frame extraction, transcription) runs locally in Python. The analysis and writing happen inside your normal Claude Code session, which you already have open.

## What you get

Give it a reel URL and your own content, get back:

- **3 hook options** using the same mechanic that made the original work
- **A full script** in your voice, on the reel's proven structure
- **A shot list** biased to screen recordings and text cards (minimal face time)
- **A caption** with one CTA

## Install

Requirements: [Claude Code](https://claude.com/claude-code), Python 3.10+, [ffmpeg](https://ffmpeg.org/download.html) on PATH.

```bash
git clone https://github.com/oloyeaaa/reel-pipeline ~/.claude/skills/reel-pipeline
cd ~/.claude/skills/reel-pipeline
```

Then run the installer:

- **Windows:** `powershell -ExecutionPolicy Bypass -File install.ps1`
- **Mac/Linux:** `bash install.sh`

The installer checks Python and ffmpeg, installs the Python dependencies, and creates your `.env`.

Fair warning on size: the transcription library (Whisper) pulls in PyTorch, a 2GB+ one-time download. The install is not stuck, it is just big.

### Instagram cookies (do this once)

Instagram blocks anonymous downloads quickly, so most reels need your own logged-in session cookies:

1. Install the browser extension "Get cookies.txt LOCALLY".
2. Log into instagram.com in that browser.
3. Export cookies for instagram.com and save the file into this folder as `cookies.txt`.
4. `IG_COOKIES_PATH=./cookies.txt` is already set in `.env`.

Your cookies never leave your machine and are git-ignored.

## Use

Open Claude Code anywhere and say:

```
break down this reel and make my version: <reel url>
```

The skill will:

1. Download, extract frames, and transcribe the reel locally.
2. Show you the breakdown: the topic, why the hook works, the structure, and the exact content slots it needs YOUR answers for.
3. Ask for your picks, your take, and your CTA. It will not invent them.
4. Write your script, hooks, shot list, and caption.

## Make it write in YOUR voice

Drop a plain-text file called `voice-rules.txt` in this folder: how you talk, words you use and avoid, a few samples of your real writing. The script guide uses it instead of the default voice. It is git-ignored, so it stays yours.

## Honest limits

- **Instagram's terms.** Downloading reels sits in a grey area of Instagram's terms of service. This tool is for studying formats and making your own original version, not re-uploading anyone's content. Use your own account's cookies, at your own risk, and respect creators.
- **It gives you the script, not the video.** You still record it. That is the point: your face, your screen, your content.
- **Transcription quality** depends on the Whisper model size. If names or jargon come out garbled, set `WHISPER_MODEL=small` (or `medium`) in `.env`.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `yt-dlp failed` | Add cookies (above), or `pip install -U yt-dlp`, or wait out a rate limit |
| `ffmpeg not found` | Install ffmpeg and check `ffmpeg -version` works in a fresh terminal |
| First run very slow | Whisper downloads its model (~150MB for base) on first use, one time |
| Garbled transcript | Raise `WHISPER_MODEL` to `small` or `medium` in `.env` |

## License

MIT. Built by [Oloye.](https://www.oloye.co.uk) More free skills: [oloye.co.uk/skills](https://www.oloye.co.uk/skills).

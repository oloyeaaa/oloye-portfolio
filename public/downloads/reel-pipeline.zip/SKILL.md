---
name: reel-pipeline
description: Take an Instagram reel that is already getting engagement and make your OWN version, same concept and proven format, your own content and take. Downloads the reel, transcribes it locally (Whisper), reverse-engineers it into structure (keep) vs swappable content slots (replace), asks you to fill the slots with your own picks and opinions, then writes the script in YOUR voice with 3 hook options and a low-face shot list. Never invents your opinions. Use for "make my version of this reel", "break down / reverse-engineer this reel", "same reel but my take", "give me a shot list from this reel".
---

# Reel Pipeline — a proven reel becomes YOUR version

You find a reel on your topic that is already getting engagement. This skill makes your own version: **same concept and same proven format, your content and your take.** Example: her reel lists her 5 best tools, yours lists YOUR 5, in the same format that is already working.

No API key needed. The scripts handle the local work (download, frames, transcription) and you, Claude, do the analysis and writing right here in the session.

## The core idea (why this is not a rewriter)

The reel is a **format you fill with your own content**, not a template to copy. The analysis splits the reel into:

- **STRUCTURE** the user keeps (hook shape, pacing, shot sequence, CTA placement).
- **SWAPPABLE SLOTS** the user replaces (the picks, claims, examples, tools it names).

You then ask the user to fill the slots with their own content, and only then write the script. **Never fabricate the user's picks or opinions.** An unfilled slot becomes a visible `[NEEDS FROM YOU: ...]` placeholder and is listed in `missing`.

## One-time setup

Requirements: Python 3.10+, **ffmpeg** and **ffprobe** on PATH. Then, from the skill folder:

```bash
pip install -r requirements.txt
cp .env.example .env
```

Heads up: `openai-whisper` pulls in PyTorch (a 2GB+ download) and the first transcription downloads the Whisper model (~150MB for `base`). The first run takes a few minutes; that is normal, not a hang.

**Instagram cookies (most reels fail without this):**
1. Install the "Get cookies.txt LOCALLY" browser extension.
2. Log into instagram.com in that browser.
3. Export cookies for instagram.com, save the file into the skill folder as `cookies.txt`.
4. Point `IG_COOKIES_PATH` at it in `.env`.

## How to run it (three phases)

Run all commands from the skill folder so `.env` and `output/` resolve.

### Phase A — prepare (the scripts do this)

```bash
python scripts/prepare.py "<reel url>"
```

This downloads the reel, extracts scene-change frames, and transcribes the audio locally. It writes to `output/<id>/`: the frames (with `frames.json` listing paths + timestamps) and `transcript.json`.

### Phase B — analyze (YOU do this, in-session)

1. Read `output/<id>/frames.json` and `output/<id>/transcript.json`.
2. Read every frame image listed in `frames.json` (they are jpg files, view them).
3. Follow `references/analysis-guide.md` exactly: reverse-engineer the reel into topic, hook, structure, and swappable slots, and write the result to `output/<id>/timeline.json` in the schema the guide specifies.
4. Build `output/<id>/fill_template.json` from the slots (the guide shows the shape).
5. Present the breakdown to the user in plain language: the topic, the hook and why it works, the structure, and **exactly what content you need from them for each slot**. Then STOP and ask. Their content, not invented content. Only skip the ask if they explicitly say it is a test.

### Phase C — write (YOU do this, after they answer)

1. Write their answers into `output/<id>/fill.json` (the `mine`, `my_take`, `cta` fields).
2. Follow `references/script-guide.md` exactly: keep the structure, fill the slots with ONLY their content, write in their voice, produce 3 hook options, a low-face shot list, and a caption.
3. Write the result to `output/<id>/tailored_output.json` and present it readably: hooks, script, shot list as a table, caption, and anything in `missing`.

## Your voice, not a template

Out of the box the script guide carries a plain, no-hype default voice. To make it write in the USER'S voice, have them drop a plain-text file of their rules and samples at `voice-rules.txt` in the skill folder. If it exists, it replaces the default voice section in `references/script-guide.md`. Check for it before writing.

## Re-running stages alone

Each stage is a standalone script: `scripts/download.py <url>`, `scripts/extract.py <video>`, `scripts/transcribe.py <audio>`. `prepare.py` chains all three. Artifacts persist in `output/<id>/` so you can re-analyze or re-write without re-downloading.

## Common failures + fixes

- **`yt-dlp failed` / download blocked** → supply `IG_COOKIES_PATH` (private or rate-limited), or `pip install -U yt-dlp` (Instagram changed layout), or wait out a rate limit.
- **Messy transcript** (garbled names/jargon) → raise `WHISPER_MODEL` to `small` or `medium` in `.env`.
- **ffmpeg not found** → install ffmpeg and make sure `ffmpeg`/`ffprobe` are on PATH.
- **Torch/Whisper install slow or huge** → expected on first install (2GB+). It is a one-time cost.

## Notes

- Everything runs locally. Nothing is posted or published anywhere.
- Download reels for your own study only, and respect creators: the output is a NEW script with the user's own content structured on a proven format, never a copy of the original's words.
- Output is a starting point structured on a proven reel. The user records it themselves.

# Reel Pipeline installer (Windows)
# Checks Python + ffmpeg, installs dependencies, creates .env.

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "Reel Pipeline setup" -ForegroundColor Green

# 1. Python
$py = Get-Command python -ErrorAction SilentlyContinue
if (-not $py) {
    Write-Host "Python not found. Install Python 3.10+ from https://www.python.org/downloads/ and re-run." -ForegroundColor Red
    exit 1
}
$ver = python -c "import sys; print('{}.{}'.format(sys.version_info[0], sys.version_info[1]))"
Write-Host "  Python $ver found"

# 2. ffmpeg
$ff = Get-Command ffmpeg -ErrorAction SilentlyContinue
if (-not $ff) {
    Write-Host "ffmpeg not found on PATH. Install it (winget install Gyan.FFmpeg) and re-run." -ForegroundColor Red
    exit 1
}
Write-Host "  ffmpeg found"

# 3. Dependencies (Whisper pulls in PyTorch, 2GB+, one time - this is the slow bit)
Write-Host "  Installing Python dependencies (first run downloads ~2GB for Whisper/PyTorch, be patient)..."
python -m pip install -r requirements.txt

# 4. .env
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "  Created .env from .env.example"
} else {
    Write-Host "  .env already exists, left as is"
}

Write-Host ""
Write-Host "Done. One thing left: export your Instagram cookies (see README, 'Instagram cookies')." -ForegroundColor Green
Write-Host "Then open Claude Code and say: break down this reel and make my version: <url>"

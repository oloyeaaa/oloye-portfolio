#!/usr/bin/env bash
# Reel Pipeline installer (Mac/Linux)
# Checks Python + ffmpeg, installs dependencies, creates .env.
set -e
cd "$(dirname "$0")"

echo "Reel Pipeline setup"

# 1. Python
if command -v python3 >/dev/null 2>&1; then PY=python3; elif command -v python >/dev/null 2>&1; then PY=python; else
  echo "Python not found. Install Python 3.10+ and re-run." >&2; exit 1
fi
echo "  $($PY --version) found"

# 2. ffmpeg
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "ffmpeg not found on PATH. Install it (brew install ffmpeg / apt install ffmpeg) and re-run." >&2; exit 1
fi
echo "  ffmpeg found"

# 3. Dependencies (Whisper pulls in PyTorch, 2GB+, one time - this is the slow bit)
echo "  Installing Python dependencies (first run downloads ~2GB for Whisper/PyTorch, be patient)..."
$PY -m pip install -r requirements.txt

# 4. .env
if [ ! -f .env ]; then
  cp .env.example .env
  echo "  Created .env from .env.example"
else
  echo "  .env already exists, left as is"
fi

echo ""
echo "Done. One thing left: export your Instagram cookies (see README, 'Instagram cookies')."
echo "Then open Claude Code and say: break down this reel and make my version: <url>"

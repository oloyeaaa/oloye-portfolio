# Distribution exclude list

If you package or share a copy of this skill, these must NEVER ship in the distributed copy.
They stay on Oloye's machine only (the live pipeline needs them in place, so do not move or delete them here).

- `scripts/.env` (real API keys and secrets; ship only `.env.example`)
- `scripts/cookies.txt` (Oloye's logged-in Instagram session cookies)
- `scripts/output/` (downloaded reels, transcripts, generated scripts, personal working data)
- `scripts/gen_err.txt` (local error log)
- `scripts/__pycache__/` (compiled Python cache)
- Any downloaded reel video files anywhere in the folder (`*.mp4`, `*.webm`, etc.)

Rule of thumb: distribute code and docs only (`*.py`, `SKILL.md`, `requirements.txt`, `.env.example`, `dashboard/` code files). Everything generated at runtime or containing a credential stays out.

"""
Stage 4: Send extracted frames + transcript to Claude (vision) to build a
structured shot-by-shot timeline: shot type, framing, on-screen text, pacing.
"""
import base64
import json
import os
from pathlib import Path
from anthropic import Anthropic

MODEL = os.environ.get("REEL_PIPELINE_MODEL", "claude-sonnet-4-6")

SYSTEM_PROMPT = """You are a short-form video strategist. You will be shown a \
sequence of frames extracted at scene-change points from a vertical video (Instagram \
Reel), along with each frame's timestamp, plus the full spoken transcript with timestamps.

The user makes videos on the SAME topic as this reel but with their OWN content (their own \
picks, their own opinions, their own examples). Your job is to reverse-engineer this reel so \
they can drop their own content into its proven format. That means cleanly separating two things:

1. STRUCTURE (what they KEEP) — the hook shape, pacing, shot sequence, and CTA placement that \
   make the reel work. This is format, not content.
2. SWAPPABLE SLOTS (what they REPLACE) — the specific pieces of content the reel is built around: \
   the list items, the picks, the claims, the examples, the specific tools/products named. These \
   are what the user substitutes with their own. Do NOT include the hook or CTA as slots; capture \
   those separately.

Example: a "5 best MCPs" reel. The STRUCTURE is "curiosity hook -> numbered list of 5 tools, each \
with a one-line reason -> CTA to comment a keyword". The SWAPPABLE SLOTS are the 5 specific tools \
and the one-line reason given for each. The user will supply their own 5.

For each frame/shot, identify:
- shot_type: one of "talking_head", "b_roll", "text_overlay", "product_closeup", "screen_recording", "other"
- framing: e.g. "medium shot, eye level", "close-up", "overhead"
- on_screen_text: any visible text overlay, verbatim, or null
- notes: anything relevant to pacing/energy/transition style (e.g. "hard cut", "zoom punch-in")

Also produce:
- topic: one short line naming the concept of the reel (e.g. "the best MCP servers to use", \
  "3 AI tools that save hours"). This is the concept the user will remake with their own take.
- hook_verbatim: the exact opening line as spoken or shown on screen (first ~3 seconds), verbatim.
- hook_type: the technique the opening uses to stop the scroll (e.g. "bold claim", "curiosity gap", "question", "visual pattern interrupt").
- hook_mechanic: one sentence on WHY that hook works (the psychological lever it pulls).
- overall_pacing: cuts-per-second estimate and general energy (fast/slow).
- structure_summary: 2-3 sentences describing the format spine (hook -> list/build -> payoff -> CTA, etc.), described as a reusable template.
- cta_verbatim: the exact call-to-action at the end, verbatim, or null.
- swappable_slots: the content pieces the user replaces with their own. For each slot give:
    - slot_id: a short stable id ("pick_1", "claim_1", "example_1", ...)
    - label: what this slot is ("MCP pick #1", "the contrarian claim", "the example customer")
    - original_content: what the reel actually said/showed here, verbatim or close
    - note: what a good replacement needs (e.g. "a tool the user actually rates, plus a one-line reason it earns its place")

Respond with ONLY valid JSON, no markdown fences, no preamble. Schema:
{
  "topic": string,
  "hook_verbatim": string,
  "hook_type": string,
  "hook_mechanic": string,
  "overall_pacing": string,
  "structure_summary": string,
  "cta_verbatim": string|null,
  "swappable_slots": [
    {"slot_id": string, "label": string, "original_content": string, "note": string}
  ],
  "shots": [
    {"timestamp_sec": number|null, "shot_type": string, "framing": string, "on_screen_text": string|null, "notes": string}
  ]
}
"""


ANALYZE_SCHEMA = {
    "type": "object",
    "properties": {
        "topic": {"type": "string"},
        "hook_verbatim": {"type": "string"},
        "hook_type": {"type": "string"},
        "hook_mechanic": {"type": "string"},
        "overall_pacing": {"type": "string"},
        "structure_summary": {"type": "string"},
        "cta_verbatim": {"type": ["string", "null"]},
        "swappable_slots": {"type": "array", "items": {"type": "object", "properties": {
            "slot_id": {"type": "string"}, "label": {"type": "string"},
            "original_content": {"type": "string"}, "note": {"type": "string"},
        }, "required": ["slot_id", "label", "original_content", "note"]}},
        "shots": {"type": "array", "items": {"type": "object", "properties": {
            "timestamp_sec": {"type": ["number", "null"]}, "shot_type": {"type": "string"},
            "framing": {"type": "string"}, "on_screen_text": {"type": ["string", "null"]}, "notes": {"type": "string"},
        }, "required": ["shot_type", "framing", "notes"]}},
    },
    "required": ["topic", "hook_verbatim", "hook_type", "hook_mechanic", "overall_pacing", "structure_summary", "swappable_slots", "shots"],
}


def _image_block(frame_path: str) -> dict:
    data = base64.standard_b64encode(Path(frame_path).read_bytes()).decode("utf-8")
    return {
        "type": "image",
        "source": {"type": "base64", "media_type": "image/jpeg", "data": data},
    }


def analyze_frames(frames: list[dict], transcript: dict, api_key: str) -> dict:
    client = Anthropic(api_key=api_key)

    content = []
    for f in frames:
        ts = f["timestamp_sec"]
        content.append({"type": "text", "text": f"Frame at t={ts}s:"})
        content.append(_image_block(f["path"]))

    transcript_block = "\n".join(
        f"[{s['start']}-{s['end']}] {s['text']}" for s in transcript["segments"]
    )
    content.append({
        "type": "text",
        "text": f"\n\nFull transcript with timestamps:\n{transcript_block}\n\n"
                "Now produce the JSON shot-by-shot breakdown described in the system prompt."
    })

    response = client.messages.create(
        model=MODEL,
        max_tokens=8000,  # raised from 4000: a video with many scene frames was truncating mid-JSON
        system=SYSTEM_PROMPT,
        tools=[{"name": "emit", "description": "Return the shot-by-shot breakdown in the required structure.", "input_schema": ANALYZE_SCHEMA}],
        tool_choice={"type": "tool", "name": "emit"},
        messages=[{"role": "user", "content": content}],
    )
    if response.stop_reason == "max_tokens":
        raise RuntimeError("Analyze hit the max_tokens limit; raise it in analyze.py.")
    for block in response.content:
        if getattr(block, "type", None) == "tool_use":
            return block.input
    raise RuntimeError("Model did not return a tool_use block in analyze.")


if __name__ == "__main__":
    import sys, os
    from dotenv import load_dotenv
    load_dotenv()
    frames_json = sys.argv[1]   # path to json list of {path, timestamp_sec}
    transcript_json = sys.argv[2]
    frames = json.loads(Path(frames_json).read_text())
    transcript = json.loads(Path(transcript_json).read_text())
    result = analyze_frames(frames, transcript, os.environ["ANTHROPIC_API_KEY"])
    print(json.dumps(result, indent=2))

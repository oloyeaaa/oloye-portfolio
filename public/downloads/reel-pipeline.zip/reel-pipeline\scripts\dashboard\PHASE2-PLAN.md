# Dashboard Phase 2 — plan (locked 2026-07-08)

Goal: the dashboard speaks from the Brain on its own (no Claude/MCP session). It calls the Airtable REST API directly. Doc delivery = a Download button (no Google auth), per Oloye's choice.

## Build list
1. **`brain.py`** — small Airtable REST client (uses `AIRTABLE_TOKEN` from `.env`, base `YOUR_AIRTABLE_BASE_ID`):
   - `read_lessons()` → GET Lessons `YOUR_LESSONS_TABLE_ID`, Active=true, Area in {content, video, Production / UGC, general} → list of Lesson strings.
   - `log_content(fields)` → POST a row to Content `YOUR_CONTENT_TABLE_ID` (Channel, Format, Owner=<you>, Status=review, Link, Copy).
   - `find_source(url)` → check Content Copy/Link for the source URL (dedup warning).
2. **Learning (2a):** `_run_generate` calls `read_lessons()` and passes them into `generate_tailored_script`/`generate_youtube_script` (already accept `lessons`). Return the applied lessons so the UI can show them.
3. **Memory (2b):** new endpoint `POST /api/save-to-brain` → `log_content(...)`. UI: a "Save to Brain" button on the output card (review-then-save, not automatic). Returns the Airtable record link.
4. **Dedup:** on analyze, call `find_source(url)`; if hit, surface "you already made a version of this" in the UI (non-blocking).
5. **Download (2c):** `GET /api/export/{video_id}?fmt=html` → returns the formatted script as a standalone HTML doc (same layout as the Google Doc: title, hooks/titles, script/narration, shot-list/section table, caption/description). UI: a "Download" button. User can print-to-PDF from the browser. NO auth needed — can build before the token exists.
6. UI polish: show applied lessons under the output; show the saved-record link after saving.

## Prerequisite (Oloye action)
Create an Airtable Personal Access Token: airtable.com/create/tokens → scopes `data.records:read` + `data.records:write` → access to the AI Team Brain base → add to `scripts/.env` as `AIRTABLE_TOKEN=...`. Unlocks 2a, 2b, dedup. (The Download button does not need it.)

## Deferred
- Real Google Doc button (needs GCP creds) — optional later if the Download file isn't enough.
- Source backlog + one-click queue.
- Auth on the dashboard itself (it is localhost-only, so low risk for now).

## Notes
- Keep client work OUT of the Brain: the dashboard is Oloye. brand content only, so logging to Content is always fine here.
- Canonical loop spec: `~/.claude/skills/_shared/brain-content-loop.md`.

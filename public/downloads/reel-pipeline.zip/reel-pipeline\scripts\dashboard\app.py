"""
Local dashboard for the reel / youtube pipeline (Phase 1).

Runs on your machine so it can drive the REAL engine (yt-dlp, ffmpeg, local Whisper,
the Claude calls). A hosted app could not do that. Start it, open the page, paste a URL,
pick reel or youtube, fill your slots, get the script. No command line.

Run:
    cd ~/.claude/skills/reel-pipeline/scripts
    python -m uvicorn dashboard.app:app --port 8756
Then open http://localhost:8756

Phase 1 = run the pipeline + show the result. Phase 2 (later) = read Lessons + log to the
Content table + make the Google Doc, straight from the dashboard.
"""
import sys, json, threading, uuid, html
from pathlib import Path

# The pipeline modules live one dir up (scripts/). Import them directly, one engine.
SCRIPTS = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(Path(__file__).resolve().parent))  # dashboard/ for brain.py

from dotenv import load_dotenv
load_dotenv(SCRIPTS / ".env")

import os
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

from download import download_reel
from extract import extract_audio, extract_scene_frames
from transcribe import transcribe_audio
from analyze import analyze_frames
from generate_script import generate_tailored_script
from generate_youtube import generate_youtube_script
import brain  # Airtable Brain client (dashboard/brain.py)

app = FastAPI(title="Oloye. Content Pipeline")
OUT = SCRIPTS / "output"

# In-memory job store. { job_id: {state, step, result, error} }
JOBS: dict[str, dict] = {}


def _key() -> str:
    k = os.environ.get("ANTHROPIC_API_KEY")
    if not k:
        raise RuntimeError("ANTHROPIC_API_KEY missing from scripts/.env")
    return k


def _run_analyze(job_id: str, url: str, platform: str = "reel"):
    j = JOBS[job_id]
    try:
        api_key = _key()
        cookies = os.environ.get("IG_COOKIES_PATH")
        wmodel = os.environ.get("WHISPER_MODEL", "base")

        j["step"] = "Downloading video..."
        video = download_reel(url, out_dir=str(OUT), cookies_path=cookies)
        work_dir = OUT / video.stem
        work_dir.mkdir(parents=True, exist_ok=True)

        j["step"] = "Extracting audio + scene frames..."
        audio = extract_audio(video, out_dir=str(work_dir))
        frames = extract_scene_frames(video, out_dir=str(work_dir))
        (work_dir / "frames.json").write_text(json.dumps(frames, indent=2))

        j["step"] = f"Transcribing (whisper/{wmodel}), this is the slow bit..."
        transcript = transcribe_audio(audio, model_size=wmodel)
        (work_dir / "transcript.json").write_text(json.dumps(transcript, indent=2))

        j["step"] = "Reverse-engineering structure + slots (Claude vision)..."
        timeline = analyze_frames(frames, transcript, api_key)
        (work_dir / "timeline.json").write_text(json.dumps(timeline, indent=2))

        # Save source metadata (used by save-to-brain) and run a dedup check (best-effort).
        (work_dir / "meta.json").write_text(json.dumps({"url": url, "platform": platform, "topic": timeline.get("topic", "")}, indent=2))
        dedup = []
        try:
            dedup = brain.find_source(url)
        except Exception:
            pass  # Brain unreachable -> skip dedup, do not fail the run

        j["result"] = {
            "video_id": video.stem,
            "work_dir": str(work_dir),
            "topic": timeline.get("topic", ""),
            "hook_verbatim": timeline.get("hook_verbatim", ""),
            "hook_type": timeline.get("hook_type", ""),
            "hook_mechanic": timeline.get("hook_mechanic", ""),
            "structure_summary": timeline.get("structure_summary", ""),
            "slots": timeline.get("swappable_slots", []),
            "dedup": dedup,
        }
        j["state"] = "done"
        j["step"] = "Reverse-engineered. Fill your slots below."
    except Exception as e:
        j["state"] = "error"
        j["error"] = str(e)


def _run_generate(job_id: str, work_dir: str, brief: str, platform: str, fills: dict):
    j = JOBS[job_id]
    try:
        api_key = _key()
        wd = Path(work_dir)
        transcript = json.loads((wd / "transcript.json").read_text())["text"]
        timeline = json.loads((wd / "timeline.json").read_text())

        # LEARNING: pull active brand-wide lessons and apply them as hard constraints (best-effort).
        lessons = []
        try:
            j["step"] = "Reading lessons from the Brain..."
            lessons = brain.read_lessons()
        except Exception:
            pass  # Brain unreachable -> generate without lessons rather than fail

        j["step"] = "Writing your script in your voice..."
        if platform == "youtube":
            out = generate_youtube_script(transcript, timeline, brief, api_key, fills=fills, lessons=lessons)
            (wd / "youtube_output.json").write_text(json.dumps(out, indent=2))
        else:
            out = generate_tailored_script(transcript, timeline, brief, api_key, fills=fills, lessons=lessons)
            (wd / "tailored_output.json").write_text(json.dumps(out, indent=2))
        j["applied_lessons"] = lessons
        j["result"] = out
        j["state"] = "done"
        j["step"] = "Done."
    except Exception as e:
        j["state"] = "error"
        j["error"] = str(e)


class AnalyzeReq(BaseModel):
    url: str
    platform: str = "reel"


class GenerateReq(BaseModel):
    work_dir: str
    brief: str
    platform: str = "reel"
    fills: dict = {}


def _start(target, *args) -> str:
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {"state": "running", "step": "Starting...", "result": None, "error": None}
    threading.Thread(target=target, args=(job_id, *args), daemon=True).start()
    return job_id


@app.post("/api/analyze")
def api_analyze(req: AnalyzeReq):
    return {"job_id": _start(_run_analyze, req.url, req.platform)}


class SaveReq(BaseModel):
    video_id: str


@app.post("/api/save-to-brain")
def api_save(req: SaveReq):
    """MEMORY: log the generated script to the Content table."""
    wd = OUT / req.video_id
    meta = json.loads((wd / "meta.json").read_text()) if (wd / "meta.json").exists() else {}
    platform = meta.get("platform", "reel")
    topic = meta.get("topic", "") or req.video_id
    src = meta.get("url", "")

    if platform == "youtube":
        out = json.loads((wd / "youtube_output.json").read_text())
        channel, fmt = "YouTube", "video"
        hook = (out.get("title_options") or [""])[0]
        body = out.get("narration_full", "")
    else:
        out = json.loads((wd / "tailored_output.json").read_text())
        channel, fmt = "TikTok / Reels", "short video"
        hook = (out.get("hook_options") or [""])[0]
        body = out.get("tailored_script", "")

    copy = f"HOOK: {hook}\n\nSource: {src}\n\n{body}"
    try:
        rec = brain.log_content(title=f"{topic} ({platform})", channel=channel, fmt=fmt, link="", copy=copy)
        return {"ok": True, "url": rec["url"]}
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)


@app.post("/api/generate")
def api_generate(req: GenerateReq):
    return {"job_id": _start(_run_generate, req.work_dir, req.brief, req.platform, req.fills)}


@app.get("/api/job/{job_id}")
def api_job(job_id: str):
    j = JOBS.get(job_id)
    if not j:
        return JSONResponse({"error": "no such job"}, status_code=404)
    return j


def _export_html(video_id: str, o: dict) -> str:
    """Render a saved script as a clean, print-ready document (Ctrl+P -> Save as PDF).
    Paper style so it reads like a proper doc, branded Oloye. with the lime accent."""
    e = lambda s: html.escape(str(s or ""))
    parts = []
    if o.get("title_options"):  # youtube
        title = e(o["title_options"][0])
        parts.append(f"<h2>Title options</h2><ul>" + "".join(f"<li>{e(t)}</li>" for t in o["title_options"]) + "</ul>")
        parts.append(f"<h2>Narration (paste into ElevenLabs)</h2><div class='script'>{e(o.get('narration_full'))}</div>")
        rows = "".join(
            f"<tr><td>{e(s.get('section_number'))}</td><td>{e(s.get('chapter_title'))}</td>"
            f"<td>{e(s.get('narration'))}</td><td>{e(s.get('screen_recording'))}</td>"
            f"<td>{e(s.get('on_screen_text'))}</td></tr>" for s in o.get("sections", []))
        parts.append("<h2>Sections</h2><table><tr><th>#</th><th>Chapter</th><th>Narration</th><th>Screen recording</th><th>On-screen text</th></tr>" + rows + "</table>")
        if o.get("chapters"):
            parts.append("<h2>Chapters</h2><ul>" + "".join(f"<li>{e(c.get('time_hint'))} {e(c.get('title'))}</li>" for c in o["chapters"]) + "</ul>")
        parts.append(f"<h2>Description</h2><div class='script'>{e(o.get('youtube_description'))}</div>")
    else:  # reel
        title = "Reel script"
        parts.append("<h2>Hook options</h2><ul>" + "".join(f"<li>{e(h)}</li>" for h in o.get("hook_options", [])) + "</ul>")
        parts.append(f"<h2>Script</h2><div class='script'>{e(o.get('tailored_script'))}</div>")
        rows = "".join(
            f"<tr><td>{e(s.get('shot_number'))}</td><td>{e(s.get('duration_sec'))}s</td>"
            f"<td>{e(s.get('shot_type'))}</td><td>{e(s.get('what_to_do'))}</td>"
            f"<td>{e(s.get('on_screen_text'))}</td></tr>" for s in o.get("shot_list", []))
        parts.append("<h2>Shot list</h2><table><tr><th>#</th><th>Time</th><th>Type</th><th>What to do</th><th>On-screen text</th></tr>" + rows + "</table>")
        parts.append(f"<h2>Caption</h2><div class='script'>{e(o.get('caption_suggestion'))}</div>")
    if o.get("missing"):
        parts.append("<h2 style='color:#b23'>Still missing from you</h2><ul>" + "".join(f"<li>{e(m)}</li>" for m in o["missing"]) + "</ul>")

    css = """
      @page{margin:18mm}
      *{box-sizing:border-box} body{font-family:'Inter',system-ui,sans-serif;color:#15181d;max-width:800px;margin:0 auto;padding:32px 24px;line-height:1.55}
      .wm{font-family:'Space Grotesk',system-ui,sans-serif;font-weight:700;font-size:22px}.wm i{color:#7d9b16;font-style:normal}
      h1{font-family:'Space Grotesk',system-ui,sans-serif;font-size:30px;margin:6px 0 2px}
      h2{font-family:'Space Grotesk',system-ui,sans-serif;font-size:19px;margin:26px 0 8px;border-bottom:2px solid #C6F23C;display:inline-block;padding-bottom:2px}
      .script{white-space:pre-wrap;background:#F5F6F7;border:1px solid #DDE0E4;border-radius:8px;padding:14px 16px;margin-top:6px}
      table{width:100%;border-collapse:collapse;margin-top:8px;font-size:13px}
      th,td{text-align:left;padding:7px 9px;border-bottom:1px solid #DDE0E4;vertical-align:top}th{color:#5a5f67}
      ul{margin:6px 0 6px 20px} .hint{color:#5a5f67;font-size:13px;margin-top:4px}
      @media print{.noprint{display:none}}
    """
    fonts = "@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Inter:wght@400;600&display=swap');"
    return (f"<!doctype html><html><head><meta charset='utf-8'><title>{title} (Oloye.)</title>"
            f"<style>{fonts}{css}</style></head><body>"
            f"<div class='wm'>Oloye<i>.</i></div><h1>{title}</h1>"
            f"<div class='hint noprint'>Press Ctrl+P (Cmd+P) to save this as a PDF.</div>"
            + "".join(parts) + "</body></html>")


@app.get("/api/export/{video_id}", response_class=HTMLResponse)
def api_export(video_id: str):
    wd = OUT / video_id
    for name in ("tailored_output.json", "youtube_output.json"):
        p = wd / name
        if p.exists():
            return _export_html(video_id, json.loads(p.read_text()))
    return HTMLResponse(f"<p>No script found for {html.escape(video_id)}. Generate one first.</p>", status_code=404)


@app.get("/", response_class=HTMLResponse)
def index():
    return (Path(__file__).resolve().parent / "index.html").read_text(encoding="utf-8")


@app.get("/docs-page", response_class=HTMLResponse)
def docs_page():
    return (Path(__file__).resolve().parent / "docs.html").read_text(encoding="utf-8")

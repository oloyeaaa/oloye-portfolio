"""
Airtable Brain client for the dashboard (Phase 2).

A standalone dashboard has no Claude/MCP, so it calls the Airtable REST API directly with
AIRTABLE_TOKEN (a Personal Access Token). This is the same Brain the blog loop + Claude sessions use.

Base: YOUR_AIRTABLE_BASE_ID
- Lessons  YOUR_LESSONS_TABLE_ID  (read active, brand-wide, to apply as hard constraints)
- Content  YOUR_CONTENT_TABLE_ID  (log finished scripts = memory)
"""
import os
import httpx

BASE = "YOUR_AIRTABLE_BASE_ID"
T_LESSONS = "YOUR_LESSONS_TABLE_ID"
T_CONTENT = "YOUR_CONTENT_TABLE_ID"

# Content field IDs
F = {
    "title": "YOUR_TITLE_FIELD_ID", "channel": "YOUR_CHANNEL_FIELD_ID", "format": "YOUR_FORMAT_FIELD_ID",
    "owner": "YOUR_OWNER_FIELD_ID", "status": "YOUR_STATUS_FIELD_ID", "link": "YOUR_LINK_FIELD_ID", "copy": "YOUR_COPY_FIELD_ID",
}
# Lessons field IDs
L = {"lesson": "YOUR_LESSON_FIELD_ID", "area": "YOUR_AREA_FIELD_ID", "active": "YOUR_ACTIVE_FIELD_ID"}

RELEVANT_AREAS = {"content", "video", "Production / UGC", "general"}


def _token() -> str:
    t = os.environ.get("AIRTABLE_TOKEN")
    if not t:
        raise RuntimeError("AIRTABLE_TOKEN missing from scripts/.env")
    return t


def _headers() -> dict:
    return {"Authorization": f"Bearer {_token()}", "Content-Type": "application/json"}


def read_lessons() -> list[str]:
    """Return active, brand-wide lesson strings to apply as hard constraints."""
    url = f"https://api.airtable.com/v0/{BASE}/{T_LESSONS}"
    out, offset = [], None
    with httpx.Client(timeout=30) as c:
        while True:
            params = {"pageSize": 100}
            if offset:
                params["offset"] = offset
            r = c.get(url, headers=_headers(), params=params)
            r.raise_for_status()
            data = r.json()
            for rec in data.get("records", []):
                f = rec.get("fields", {})
                active = f.get("Active") is True
                area = f.get("Area")
                area_name = area.get("name") if isinstance(area, dict) else area
                lesson = f.get("Lesson")
                if active and lesson and (area_name in RELEVANT_AREAS or area_name is None):
                    out.append(lesson)
            offset = data.get("offset")
            if not offset:
                break
    return out


def find_source(source_url: str) -> list[dict]:
    """Dedup: existing Content rows whose Copy mentions this source URL. Best-effort."""
    if not source_url:
        return []
    # crude: pull recent Content and substring-match in Copy (Airtable formula would need field-name escaping)
    url = f"https://api.airtable.com/v0/{BASE}/{T_CONTENT}"
    hits = []
    with httpx.Client(timeout=30) as c:
        r = c.get(url, headers=_headers(), params={"pageSize": 100})
        r.raise_for_status()
        for rec in r.json().get("records", []):
            copy = rec.get("fields", {}).get("Copy", "") or ""
            if source_url in copy:
                hits.append({"id": rec["id"], "title": rec.get("fields", {}).get("Title", "")})
    return hits


def log_content(title: str, channel: str, fmt: str, link: str, copy: str, owner: str = "<you>", status: str = "review") -> dict:
    """Create a Content row (the memory half). Returns {id, url}."""
    url = f"https://api.airtable.com/v0/{BASE}/{T_CONTENT}"
    fields = {
        F["title"]: title, F["channel"]: channel, F["format"]: fmt,
        F["owner"]: owner, F["status"]: status, F["copy"]: copy,
    }
    if link:
        fields[F["link"]] = link
    body = {"records": [{"fields": fields}], "typecast": True}
    with httpx.Client(timeout=30) as c:
        r = c.post(url, headers=_headers(), json=body)
        r.raise_for_status()
        rec = r.json()["records"][0]
    return {"id": rec["id"], "url": f"https://airtable.com/{BASE}/{T_CONTENT}/{rec['id']}"}


if __name__ == "__main__":
    from dotenv import load_dotenv
    from pathlib import Path
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
    ls = read_lessons()
    print(f"read {len(ls)} active brand-wide lessons:")
    for x in ls:
        print(" -", x)

"""
Stage 1: Download an Instagram reel to local disk via yt-dlp.
"""
import subprocess
import sys
import os
from pathlib import Path


def download_reel(url: str, out_dir: str = "output", cookies_path: str | None = None) -> Path:
    """
    Downloads the reel video to out_dir/<id>.mp4.
    Returns the path to the downloaded file.
    """
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    out_template = str(Path(out_dir) / "%(id)s.%(ext)s")

    cmd = [
        sys.executable, "-m", "yt_dlp",
        "-f", "mp4",
        "-o", out_template,
        "--no-playlist",
        "--print", "after_move:filepath",
    ]

    if cookies_path and os.path.exists(cookies_path):
        cmd += ["--cookies", cookies_path]

    cmd.append(url)

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        raise RuntimeError(
            f"yt-dlp failed.\nstdout: {result.stdout}\nstderr: {result.stderr}\n"
            "Common fixes: (1) reel is private/age-gated -> supply IG_COOKIES_PATH, "
            "(2) Instagram changed its layout -> run `pip install -U yt-dlp`, "
            "(3) rate limited -> wait and retry."
        )

    filepath = result.stdout.strip().splitlines()[-1]
    return Path(filepath)


if __name__ == "__main__":
    import sys
    url = sys.argv[1]
    path = download_reel(url)
    print(f"Downloaded: {path}")

"""
Stage 2: Extract scene-change frames + audio track from the downloaded video.

Scene-change detection (rather than fixed-interval sampling) grabs frames at
actual cut points, which is what you want for a shot-by-shot breakdown.
"""
import subprocess
import re
from pathlib import Path


def extract_audio(video_path: Path, out_dir: str = "output") -> Path:
    audio_path = Path(out_dir) / f"{video_path.stem}_audio.wav"
    cmd = [
        "ffmpeg", "-y", "-i", str(video_path),
        "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
        str(audio_path),
    ]
    subprocess.run(cmd, capture_output=True, text=True, check=True)
    return audio_path


def extract_scene_frames(
    video_path: Path,
    out_dir: str = "output",
    scene_threshold: float = 0.3,
    max_frames: int = 40,
) -> list[dict]:
    """
    Extracts frames at scene-change points using ffmpeg's scene detection filter.
    Also grabs the very first frame (scene detection misses the opening shot).
    Returns list of {"path": str, "timestamp_sec": float}.
    """
    frames_dir = Path(out_dir) / f"{video_path.stem}_frames"
    frames_dir.mkdir(parents=True, exist_ok=True)

    # showinfo prints pts_time for each frame that passes the scene filter -> parse from stderr
    cmd = [
        "ffmpeg", "-y", "-i", str(video_path),
        "-vf", f"select='gt(scene,{scene_threshold})',showinfo",
        "-vsync", "vfr",
        str(frames_dir / "scene_%04d.jpg"),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)

    timestamps = [float(m) for m in re.findall(r"pts_time:([\d.]+)", result.stderr)]

    frame_files = sorted(frames_dir.glob("scene_*.jpg"))

    # Always include frame 0 (t=0) so the opening hook shot isn't missed
    first_frame_path = frames_dir / "scene_0000.jpg"
    if not first_frame_path.exists():
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(video_path), "-frames:v", "1", str(first_frame_path)],
            capture_output=True, text=True,
        )
        frame_files = [first_frame_path] + frame_files
        timestamps = [0.0] + timestamps

    frames = []
    for i, f in enumerate(frame_files[:max_frames]):
        ts = timestamps[i] if i < len(timestamps) else None
        frames.append({"path": str(f), "timestamp_sec": ts})

    return frames


if __name__ == "__main__":
    import sys
    video_path = Path(sys.argv[1])
    audio = extract_audio(video_path)
    frames = extract_scene_frames(video_path)
    print(f"Audio: {audio}")
    print(f"Frames: {len(frames)} extracted")
    for f in frames:
        print(f"  {f['timestamp_sec']}s -> {f['path']}")

"""
Stage 5 (YouTube long-form): given the original transcript + reverse-engineered
timeline (structure + swappable slots) + the creator's own slot content, produce a
long-form 16:9 YouTube tutorial as a NARRATION voiceover script (for ElevenLabs) plus
a synced screen-recording shot list. ZERO talking head, all screen + b-roll.

Reuses the shared engine: same download/extract/transcribe/analyze stages as the reel
pipeline, and the same VOICE_RULES + em-dash guard. This is the youtube counterpart to
generate_script.py, not a fork of the whole pipeline.

Key rule (same as reel): keep the source video's proven structure, fill the swappable
slots with the creator's OWN content, NEVER invent their opinions. Unfilled slot -> a
visible "[NEEDS FROM YOU: ...]" placeholder + listed in "missing".
"""
import json
from anthropic import Anthropic
from generate_script import _strip_em_dashes, VOICE_RULES, MODEL, _lessons_block, call_json

# Structured-output schema for the long-form YouTube result (forces valid JSON).
YOUTUBE_SCHEMA = {
    "type": "object",
    "properties": {
        "title_options": {"type": "array", "items": {"type": "string"}},
        "sections": {"type": "array", "items": {"type": "object", "properties": {
            "section_number": {"type": "number"}, "chapter_title": {"type": "string"}, "narration": {"type": "string"},
            "screen_recording": {"type": "string"}, "on_screen_text": {"type": ["string", "null"]}, "approx_duration_sec": {"type": "number"},
        }, "required": ["section_number", "chapter_title", "narration", "screen_recording", "approx_duration_sec"]}},
        "narration_full": {"type": "string", "description": "all section narrations joined, paste-ready for ElevenLabs"},
        "chapters": {"type": "array", "items": {"type": "object", "properties": {
            "time_hint": {"type": "string"}, "title": {"type": "string"}}, "required": ["title"]}},
        "youtube_description": {"type": "string"},
        "missing": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["title_options", "sections", "narration_full", "chapters", "youtube_description", "missing"],
}

SYSTEM_PROMPT = f"""You are a long-form YouTube scriptwriter writing in ONE creator's voice.

The creator found a YouTube video on their topic that already performs well, and wants to make \
their OWN version: same concept and proven structure, their own content and take. The video is a \
LONG-FORM 16:9 tutorial with NO talking head. It is narrated by the creator's cloned voice \
(ElevenLabs) over screen recordings and b-roll. You will be given:
1. The original video's transcript.
2. A reverse-engineered breakdown: topic, hook, reusable STRUCTURE, and SWAPPABLE SLOTS.
3. The creator's OWN content for those slots.

Your job:
A. KEEP the proven structure (how it hooks, the order it teaches in, where it recaps, CTA placement). \
   Reuse the FORMAT, never copy the original's wording.
B. FILL the slots with the creator's supplied content ONLY. NEVER invent their opinions, picks, tools, \
   numbers, or examples. For an unsupplied slot, write "[NEEDS FROM YOU: <what to supply>]" and list it in "missing".
C. Write the NARRATION as a clean voiceover to be spoken by a voice clone. It must read naturally out loud: \
   plain spoken sentences, good rhythm, no stage directions inside the narration, no markdown, no bracketed \
   cues (except the NEEDS placeholder). Tutorial phrases like "you can see here" are fine when they match \
   what is on screen. HARD LIMIT: narration_full must be UNDER 5000 characters total (ElevenLabs caps a single \
   voice generation at 5000 chars). Keep sections tight to stay under it; if the topic needs more, cut scope \
   (fewer points) rather than exceed 5000, and note the cut in "missing".
D. This is LONG-FORM. Retention is everything: a strong hook in the first 15-30 seconds that says what they \
   will be able to do by the end, then teach it step by step, then a short recap, then ONE CTA. Break the body \
   into clear sections that double as YouTube chapters.
E. For each section give the exact SCREEN RECORDING to capture (what app, what to click, what to show) and any \
   on-screen text. Zero face, all screen + b-roll. Say what to record specifically.
F. Also give 3 YouTube TITLE options (searchable + curiosity, not clickbait) and a YouTube description.

{VOICE_RULES}

Respond with ONLY valid JSON, no markdown fences, no preamble. Schema:
{{
  "title_options": [string, string, string],
  "sections": [
    {{"section_number": number, "chapter_title": string, "narration": string,
      "screen_recording": string, "on_screen_text": string|null, "approx_duration_sec": number}}
  ],
  "narration_full": string,   // all section narrations joined in order, clean, ready to paste straight into ElevenLabs
  "chapters": [{{"time_hint": string, "title": string}}],
  "youtube_description": string,
  "missing": [string]
}}
"""


def generate_youtube_script(
    original_transcript: str,
    timeline: dict,
    user_brief: str,
    api_key: str,
    fills: dict | None = None,
    lessons: list[str] | None = None,
) -> dict:
    client = Anthropic(api_key=api_key)

    fills = fills or {}
    fills_block = json.dumps(fills, indent=2) if fills else "(none supplied yet)"

    user_content = f"""ORIGINAL TRANSCRIPT:
{original_transcript}

REVERSE-ENGINEERED BREAKDOWN (topic, hook, structure, swappable slots):
{json.dumps(timeline, indent=2)}

THE CREATOR'S BRIEF (their angle / audience / energy):
{user_brief}

THE CREATOR'S OWN CONTENT FOR THE SLOTS (use ONLY this, never invent more):
{fills_block}{_lessons_block(lessons)}

Produce the JSON described in the system prompt. Long-form 16:9, narrated voiceover for ElevenLabs, zero face, \
all screen recording. Keep the structure, fill the slots with the creator's content only, and make narration_full \
paste-ready for ElevenLabs."""

    return _strip_em_dashes(call_json(client, SYSTEM_PROMPT, user_content, YOUTUBE_SCHEMA, max_tokens=12000))


if __name__ == "__main__":
    import sys, os, argparse
    from pathlib import Path
    from dotenv import load_dotenv
    load_dotenv()

    parser = argparse.ArgumentParser(description="Generate long-form YouTube narration script from saved artifacts")
    parser.add_argument("transcript_json", help="path to transcript.json")
    parser.add_argument("timeline_json", help="path to timeline.json")
    parser.add_argument("brief", help="the creator's brief / angle")
    parser.add_argument("--fill", help="path to fill.json with the creator's slot content", default=None)
    parser.add_argument("--lessons", help="path to a JSON array of learned lessons (strings) to apply as hard constraints", default=None)
    args = parser.parse_args()

    transcript = json.loads(Path(args.transcript_json).read_text())["text"]
    timeline = json.loads(Path(args.timeline_json).read_text())
    fills = json.loads(Path(args.fill).read_text()) if args.fill else None
    lessons = json.loads(Path(args.lessons).read_text()) if args.lessons else None

    result = generate_youtube_script(
        transcript, timeline, args.brief, os.environ["ANTHROPIC_API_KEY"], fills=fills, lessons=lessons
    )
    print(json.dumps(result, indent=2))

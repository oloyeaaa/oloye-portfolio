"""
End-to-end pipeline: reel URL -> your tailored script + recording shot list.

Two ways to run:

  # Phase A only: reverse-engineer the reel and print exactly what content it needs FROM YOU.
  python main.py "<reel url>" --analyze-only

  # Full run: analyze, then generate using your slot content (fill.json).
  python main.py "<reel url>" --brief "your angle" --fill output/<id>/fill.json

The intended flow is A then B: run --analyze-only, fill in output/<id>/fill.json with your
own picks/take, then generate. This keeps the reel's proven format but drops YOUR content in,
and never invents your opinions. Each stage writes its output to output/<video_id>/ so any
stage can be inspected or re-run alone.
"""
import argparse
import json
import os
import sys
from pathlib import Path

# Windows terminals default to cp1252, which crashes rich on unicode glyphs.
# Force UTF-8 so output (and error teardown) renders cleanly.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
from dotenv import load_dotenv
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from download import download_reel
from extract import extract_audio, extract_scene_frames
from transcribe import transcribe_audio
from analyze import analyze_frames
from generate_script import generate_tailored_script
from generate_youtube import generate_youtube_script

load_dotenv()
console = Console()


def _api_key() -> str:
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        raise SystemExit("Set ANTHROPIC_API_KEY in your .env file first (see .env.example).")
    return key


def run_analyze(url: str, out_dir: str = "output") -> tuple[str, dict]:
    """Stages 1-4: download, extract, transcribe, reverse-engineer the reel.
    Saves timeline.json + a fill_template.json, and prints what content is needed from the user."""
    api_key = _api_key()
    cookies_path = os.environ.get("IG_COOKIES_PATH")
    whisper_model = os.environ.get("WHISPER_MODEL", "base")

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
        t = progress.add_task("Downloading reel...", total=None)
        video_path = download_reel(url, out_dir=out_dir, cookies_path=cookies_path)
        progress.update(t, description=f"Downloaded: {video_path.name}")

        work_dir = str(Path(out_dir) / video_path.stem)
        Path(work_dir).mkdir(parents=True, exist_ok=True)

        t = progress.add_task("Extracting audio + scene frames...", total=None)
        audio_path = extract_audio(video_path, out_dir=work_dir)
        frames = extract_scene_frames(video_path, out_dir=work_dir)
        (Path(work_dir) / "frames.json").write_text(json.dumps(frames, indent=2))
        progress.update(t, description=f"Extracted {len(frames)} scene frames")

        t = progress.add_task(f"Transcribing audio (whisper/{whisper_model})...", total=None)
        transcript = transcribe_audio(audio_path, model_size=whisper_model)
        (Path(work_dir) / "transcript.json").write_text(json.dumps(transcript, indent=2))
        progress.update(t, description="Transcription done")

        t = progress.add_task("Reverse-engineering structure + slots (Claude vision)...", total=None)
        timeline = analyze_frames(frames, transcript, api_key)
        (Path(work_dir) / "timeline.json").write_text(json.dumps(timeline, indent=2))
        progress.update(t, description="Structure + swappable slots identified")

    # Build a fill template the user (or Claude) completes with their own content.
    slots = timeline.get("swappable_slots", [])
    fill_template = {
        "topic": timeline.get("topic", ""),
        "my_take": "",  # your angle / opinion on this topic
        "cta": "",      # your call to action (e.g. comment AUDIT)
        "slots": {
            s["slot_id"]: {
                "label": s.get("label", ""),
                "original": s.get("original_content", ""),
                "note": s.get("note", ""),
                "mine": "",  # <-- put YOUR version here
            }
            for s in slots
        },
    }
    fill_path = Path(work_dir) / "fill_template.json"
    fill_path.write_text(json.dumps(fill_template, indent=2))

    _print_fill_request(timeline, work_dir)
    return work_dir, timeline


def _print_fill_request(timeline: dict, work_dir: str):
    console.print(f"\n[bold green]Reel reverse-engineered.[/bold green] Artifacts in: {work_dir}/\n")
    console.print(f"[bold]TOPIC:[/bold] {timeline.get('topic', '(unknown)')}")
    console.print(f"[bold]HOOK:[/bold] \"{timeline.get('hook_verbatim', '')}\"  "
                  f"([italic]{timeline.get('hook_type', '')} — {timeline.get('hook_mechanic', '')}[/italic])")
    console.print(f"[bold]FORMAT:[/bold] {timeline.get('structure_summary', '')}\n")

    slots = timeline.get("swappable_slots", [])
    console.print("[bold yellow]WHAT I NEED FROM YOU[/bold yellow] (your own content for each slot):\n")
    for s in slots:
        console.print(f"  • [bold]{s.get('label','')}[/bold] ({s.get('slot_id','')})")
        console.print(f"      she said: \"{s.get('original_content','')}\"")
        console.print(f"      you supply: {s.get('note','')}\n")
    console.print("Plus: your take/angle on the topic, and your CTA.\n")
    console.print(f"Fill your answers into: [bold]{work_dir}/fill_template.json[/bold] "
                  "(the \"mine\", \"my_take\", \"cta\" fields), then run generation.")


def run_generate(work_dir: str, brief: str, fill_path: str | None = None, platform: str = "reel",
                 lessons_path: str | None = None) -> dict:
    """Stage 5: generate the script in your voice using your slot content.
    platform 'reel' -> to-camera short-form script + shot list.
    platform 'youtube' -> long-form 16:9 narration voiceover (ElevenLabs) + screen-recording shot list.
    lessons_path -> JSON array of learned lessons (from the Brain's Lessons table) applied as hard constraints."""
    api_key = _api_key()
    transcript = json.loads((Path(work_dir) / "transcript.json").read_text())["text"]
    timeline = json.loads((Path(work_dir) / "timeline.json").read_text())
    fills = json.loads(Path(fill_path).read_text()) if fill_path else None
    lessons = json.loads(Path(lessons_path).read_text()) if lessons_path else None

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
        if platform == "youtube":
            t = progress.add_task("Writing your YouTube narration + screen plan (your voice)...", total=None)
            output = generate_youtube_script(transcript, timeline, brief, api_key, fills=fills, lessons=lessons)
            (Path(work_dir) / "youtube_output.json").write_text(json.dumps(output, indent=2))
            progress.update(t, description="YouTube script generated")
        else:
            t = progress.add_task("Writing your script + shot list (your voice)...", total=None)
            output = generate_tailored_script(transcript, timeline, brief, api_key, fills=fills, lessons=lessons)
            (Path(work_dir) / "tailored_output.json").write_text(json.dumps(output, indent=2))
            progress.update(t, description="Script generated")

    if platform == "youtube":
        _print_youtube(output, work_dir)
    else:
        _print_output(output, work_dir)
    return output


def _print_youtube(output: dict, work_dir: str):
    console.print(f"\n[bold green]Done.[/bold green] Saved to: {work_dir}/youtube_output.json\n")
    console.print("[bold]TITLE OPTIONS[/bold]")
    for i, tt in enumerate(output.get("title_options", []), 1):
        console.print(f"  {i}. {tt}")
    console.print("\n[bold]SECTIONS (narration + what to screen-record)[/bold]\n")
    for s in output.get("sections", []):
        console.print(f"  [{s['section_number']}] {s.get('chapter_title','')} (~{s.get('approx_duration_sec','?')}s)")
        console.print(f"      VO: {s['narration']}")
        console.print(f"      SCREEN: {s['screen_recording']}")
        if s.get("on_screen_text"):
            console.print(f"      TEXT: \"{s['on_screen_text']}\"")
        console.print("")
    console.print("[bold]CHAPTERS[/bold]")
    for c in output.get("chapters", []):
        console.print(f"  {c.get('time_hint','')}  {c.get('title','')}")
    console.print(f"\n[bold]DESCRIPTION[/bold]\n{output.get('youtube_description','')}")
    missing = output.get("missing", [])
    if missing:
        console.print(f"\n[bold red]Still missing from you:[/bold red] {', '.join(missing)}")
    console.print("\n[bold]narration_full[/bold] is saved in the JSON, paste it straight into ElevenLabs.")


def _print_output(output: dict, work_dir: str):
    console.print(f"\n[bold green]Done.[/bold green] Saved to: {work_dir}/tailored_output.json\n")
    console.print("[bold]HOOK OPTIONS[/bold]")
    for i, h in enumerate(output.get("hook_options", []), 1):
        console.print(f"  {i}. {h}")
    console.print("\n[bold]TAILORED SCRIPT[/bold]\n")
    console.print(output["tailored_script"])
    console.print("\n[bold]SHOT LIST[/bold]\n")
    for shot in output["shot_list"]:
        console.print(
            f"  [{shot['shot_number']}] ({shot['duration_sec']}s, {shot['shot_type']}): "
            f"{shot['what_to_do']}"
        )
        if shot.get("on_screen_text"):
            console.print(f"      text overlay: \"{shot['on_screen_text']}\"")
        if shot.get("recording_note"):
            console.print(f"      note: {shot['recording_note']}")
    console.print(f"\n[bold]Caption idea:[/bold] {output['caption_suggestion']}")
    missing = output.get("missing", [])
    if missing:
        console.print(f"\n[bold red]Still missing from you:[/bold red] {', '.join(missing)}")


def run_pipeline(url: str, brief: str, out_dir: str = "output", fill_path: str | None = None, platform: str = "reel",
                 lessons_path: str | None = None):
    work_dir, _ = run_analyze(url, out_dir=out_dir)
    return run_generate(work_dir, brief, fill_path=fill_path, platform=platform, lessons_path=lessons_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Reel/YouTube video -> your tailored script + shot list")
    parser.add_argument("url", help="Instagram reel or YouTube video URL")
    parser.add_argument("--platform", choices=["reel", "youtube"], default="reel",
                        help="reel = to-camera short-form (default). youtube = long-form 16:9 narration voiceover (ElevenLabs), zero face.")
    parser.add_argument("--analyze-only", action="store_true",
                        help="Only reverse-engineer the source video and print what content it needs from you, then stop.")
    parser.add_argument("--brief", help="Your angle/audience/energy for your version (required unless --analyze-only)")
    parser.add_argument("--fill", help="Path to your fill.json (slot content). Use fill_template.json from --analyze-only.")
    parser.add_argument("--lessons", help="Path to a JSON array of learned lessons (from the Brain's Lessons table) to apply as hard constraints.")
    parser.add_argument("--out", default="output", help="Output directory")
    args = parser.parse_args()

    if args.analyze_only:
        run_analyze(args.url, args.out)
    else:
        if not args.brief:
            parser.error("--brief is required unless --analyze-only is set.")
        run_pipeline(args.url, args.brief, args.out, fill_path=args.fill, platform=args.platform, lessons_path=args.lessons)

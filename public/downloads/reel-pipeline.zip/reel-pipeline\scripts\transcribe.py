"""
Stage 3: Transcribe audio with local Whisper (no API cost, runs on CPU).
"""
from pathlib import Path
import os


def transcribe_audio(audio_path: Path, model_size: str = "base") -> dict:
    """
    Returns {"text": full transcript, "segments": [{"start", "end", "text"}, ...]}
    """
    import whisper  # imported lazily so the rest of the pipeline works without it installed

    model = whisper.load_model(model_size)
    result = model.transcribe(str(audio_path), fp16=False)

    segments = [
        {"start": round(s["start"], 2), "end": round(s["end"], 2), "text": s["text"].strip()}
        for s in result["segments"]
    ]
    return {"text": result["text"].strip(), "segments": segments}


if __name__ == "__main__":
    import sys, json
    audio_path = Path(sys.argv[1])
    model_size = os.getenv("WHISPER_MODEL", "base")
    out = transcribe_audio(audio_path, model_size)
    print(json.dumps(out, indent=2))

# Analysis guide — reverse-engineer the reel (Phase B)

You are acting as a short-form video strategist. You have the scene-change frames of a vertical video (with each frame's timestamp) and the full spoken transcript with timestamps. Read ALL frames and the transcript before writing anything.

The user makes videos on the SAME topic as this reel but with their OWN content (their own picks, opinions, examples). Your job is to reverse-engineer the reel so they can drop their content into its proven format. That means cleanly separating two things:

1. **STRUCTURE (what they KEEP)** — the hook shape, pacing, shot sequence, and CTA placement that make the reel work. This is format, not content.
2. **SWAPPABLE SLOTS (what they REPLACE)** — the specific content pieces the reel is built around: the list items, the picks, the claims, the examples, the specific tools/products named. Do NOT include the hook or CTA as slots; capture those separately.

Example: a "5 best MCPs" reel. The STRUCTURE is "curiosity hook -> numbered list of 5 tools, each with a one-line reason -> CTA to comment a keyword". The SWAPPABLE SLOTS are the 5 specific tools and the one-line reason for each. The user supplies their own 5.

For each frame/shot, identify:
- `shot_type`: one of `talking_head`, `b_roll`, `text_overlay`, `product_closeup`, `screen_recording`, `other`
- `framing`: e.g. "medium shot, eye level", "close-up", "overhead"
- `on_screen_text`: any visible text overlay, verbatim, or null
- `notes`: anything relevant to pacing/energy/transition style (e.g. "hard cut", "zoom punch-in")

Also produce:
- `topic`: one short line naming the concept of the reel. This is the concept the user remakes with their own take.
- `hook_verbatim`: the exact opening line as spoken or shown on screen (first ~3 seconds).
- `hook_type`: the technique the opening uses to stop the scroll (e.g. "bold claim", "curiosity gap", "question", "visual pattern interrupt").
- `hook_mechanic`: one sentence on WHY that hook works (the psychological lever it pulls).
- `overall_pacing`: cuts-per-second estimate and general energy (fast/slow).
- `structure_summary`: 2-3 sentences describing the format spine (hook -> list/build -> payoff -> CTA), described as a reusable template.
- `cta_verbatim`: the exact call-to-action at the end, verbatim, or null.
- `swappable_slots`: the content pieces the user replaces. For each slot:
  - `slot_id`: short stable id (`pick_1`, `claim_1`, `example_1`, ...)
  - `label`: what this slot is ("tool pick #1", "the contrarian claim", "the example customer")
  - `original_content`: what the reel actually said/showed here, verbatim or close
  - `note`: what a good replacement needs (e.g. "a tool the user actually rates, plus a one-line reason it earns its place")

## Write `output/<id>/timeline.json`

Exactly this schema (valid JSON, no comments):

```json
{
  "topic": "string",
  "hook_verbatim": "string",
  "hook_type": "string",
  "hook_mechanic": "string",
  "overall_pacing": "string",
  "structure_summary": "string",
  "cta_verbatim": "string or null",
  "swappable_slots": [
    {"slot_id": "string", "label": "string", "original_content": "string", "note": "string"}
  ],
  "shots": [
    {"timestamp_sec": 0.0, "shot_type": "string", "framing": "string", "on_screen_text": "string or null", "notes": "string"}
  ]
}
```

## Write `output/<id>/fill_template.json`

Built from the slots, for the user to fill:

```json
{
  "topic": "<topic from timeline>",
  "my_take": "",
  "cta": "",
  "slots": {
    "<slot_id>": {
      "label": "<label>",
      "original": "<original_content>",
      "note": "<note>",
      "mine": ""
    }
  }
}
```

## Then present it and STOP

Show the user, in plain language: the topic, the hook (verbatim + why it works), the structure summary, and for every slot: what the original said, and what you need from them. Plus their take/angle and their CTA. Then ask them for their content. Do not proceed to writing until they answer (unless they said it is a test).

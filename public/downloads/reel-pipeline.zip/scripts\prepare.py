"""
Prepare a reel for analysis: download -> extract frames + audio -> transcribe.

Usage (from the skill folder):
    python scripts/prepare.py "<reel url>"

Writes to output/<id>/:
    frames.json        list of {path, timestamp_sec} for every scene-change frame
    <id>_frames/       the frame jpgs
    transcript.json    {"text": ..., "segments": [{start, end, text}]}

No API key needed. The analysis and script writing happen in your Claude session
(see references/analysis-guide.md and references/script-guide.md).
"""
import argparse
import json
import os
import sys
from pathlib import Path

# Windows terminals default to cp1252, which crashes rich on unicode glyphs.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).resolve().parent))

from dotenv import load_dotenv
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from download import download_reel
from extract import extract_audio, extract_scene_frames
from transcribe import transcribe_audio

load_dotenv()
console = Console()


def prepare(url: str, out_dir: str = "output") -> str:
    cookies_path = os.environ.get("IG_COOKIES_PATH")
    whisper_model = os.environ.get("WHISPER_MODEL", "base")

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
        t = progress.add_task("Downloading reel...", total=None)
        video_path = download_reel(url, out_dir=out_dir, cookies_path=cookies_path)
        progress.update(t, description=f"Downloaded: {video_path.name}")

        work_dir = str(Path(out_dir) / video_path.stem)
        Path(work_dir).mkdir(parents=True, exist_ok=True)

        t = progress.add_task("Extracting audio + scene frames...", total=None)
        audio_path = extract_audio(video_path, out_dir=work_dir)
        frames = extract_scene_frames(video_path, out_dir=work_dir)
        (Path(work_dir) / "frames.json").write_text(json.dumps(frames, indent=2))
        progress.update(t, description=f"Extracted {len(frames)} scene frames")

        t = progress.add_task(f"Transcribing audio (whisper/{whisper_model})...", total=None)
        transcript = transcribe_audio(audio_path, model_size=whisper_model)
        (Path(work_dir) / "transcript.json").write_text(json.dumps(transcript, indent=2))
        progress.update(t, description="Transcription done")

    console.print(f"\n[bold green]Prepared.[/bold green] Artifacts in: {work_dir}/")
    console.print(f"  frames.json     ({len(frames)} scene frames)")
    console.print(f"  transcript.json ({len(transcript['segments'])} segments)")
    console.print("\nNext: analyze in your Claude session, following references/analysis-guide.md.")
    return work_dir


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Reel URL -> frames + transcript, ready for in-session analysis")
    parser.add_argument("url", help="Instagram reel (or other yt-dlp supported) URL")
    parser.add_argument("--out", default="output", help="Output directory")
    args = parser.parse_args()
    prepare(args.url, args.out)

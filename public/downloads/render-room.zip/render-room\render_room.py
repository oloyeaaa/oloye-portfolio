#!/usr/bin/env python
"""
Render Room — pay-per-use media generation via fal.ai, for Claude Code.

Subcommands (model is always explicit, so new fal models work with no code change):
  image    text -> image
  edit     image(s) + prompt -> edited image
  video    image -> video
  upscale  video -> upscaled video

Key handling: reads FAL_KEY from the environment (fal_client does this automatically).
Never pass the key on the command line.

Output: downloads every media URL in the result to the output folder and prints one
machine-readable line prefixed with @@RENDER_JSON@@ {json}. On failure: {"ok": false, ...}.

Examples:
  python render_room.py image  --model fal-ai/nano-banana --prompt "a dog in a cape" --arg aspect_ratio=1:1
  python render_room.py edit   --model fal-ai/nano-banana/edit --prompt "make it night" --image a.png
  python render_room.py video  --model fal-ai/kling-video/v2/standard/image-to-video --image hero.png --prompt "slow push in" --arg duration=5
  python render_room.py upscale --model fal-ai/topaz/upscale/video --video clip.mp4
"""
import argparse, json, os, sys, time, datetime, urllib.request, urllib.parse, mimetypes, pathlib

# Everything created lives inside Oloye-OS (the content system's media home).
DEFAULT_OUT = os.path.join(os.path.expanduser("~"), "Oloye-OS", "Content-System", "media")
SKILL_DIR = os.path.dirname(os.path.abspath(__file__))


def load_env():
    """Load FAL_KEY from a local .env (skill dir, then CWD, then home) without
    overriding an already-set environment variable. The key never leaves the file."""
    if os.environ.get("FAL_KEY"):
        return
    for d in (SKILL_DIR, os.getcwd(), os.path.expanduser("~")):
        p = os.path.join(d, ".env")
        if not os.path.isfile(p):
            continue
        try:
            with open(p, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    k = k.strip()
                    v = v.strip().strip('"').strip("'")
                    # only set non-empty values, and don't override what's already set —
                    # so a leftover empty FAL_KEY= in one file can't block a real one in another
                    if k and v and not os.environ.get(k):
                        os.environ[k] = v
        except OSError:
            pass
        if os.environ.get("FAL_KEY"):
            return


def out(obj):
    print("@@RENDER_JSON@@" + json.dumps(obj))
    sys.exit(0 if obj.get("ok") else 1)


def coerce(v):
    """Turn a CLI string into int/float/bool/json where sensible."""
    low = v.lower()
    if low in ("true", "false"):
        return low == "true"
    if low == "null":
        return None
    for cast in (int, float):
        try:
            return cast(v)
        except ValueError:
            pass
    if (v.startswith("[") and v.endswith("]")) or (v.startswith("{") and v.endswith("}")):
        try:
            return json.loads(v)
        except ValueError:
            pass
    return v


def parse_args_list(pairs):
    d = {}
    for p in pairs or []:
        if "=" not in p:
            out({"ok": False, "error": f"--arg must be key=value, got: {p}"})
        k, v = p.split("=", 1)
        d[k] = coerce(v)
    return d


def find_urls(node, acc):
    """Recursively collect http(s) media URLs from a result payload."""
    if isinstance(node, dict):
        for v in node.values():
            find_urls(v, acc)
    elif isinstance(node, list):
        for v in node:
            find_urls(v, acc)
    elif isinstance(node, str):
        if node.startswith("http://") or node.startswith("https://"):
            acc.append(node)
    return acc


def download(url, out_dir, stem, idx):
    ext = os.path.splitext(urllib.parse.urlparse(url).path)[1] or ".bin"
    name = f"{stem}{'' if idx == 0 else f'-{idx+1}'}{ext}"
    dest = os.path.join(out_dir, name)
    urllib.request.urlretrieve(url, dest)
    return dest


def main():
    ap = argparse.ArgumentParser(prog="render_room")
    ap.add_argument("cmd", choices=["image", "edit", "video", "upscale"])
    ap.add_argument("--model", required=True, help="fal model slug, e.g. fal-ai/nano-banana")
    ap.add_argument("--prompt", default=None)
    ap.add_argument("--image", action="append", help="local image path or URL (repeatable)")
    ap.add_argument("--video", default=None, help="local video path or URL")
    ap.add_argument("--arg", action="append", help="extra model arg key=value (repeatable)")
    ap.add_argument("--image-key", default=None, help="override payload key for image input")
    ap.add_argument("--out", default=DEFAULT_OUT)
    args = ap.parse_args()

    load_env()
    if not os.environ.get("FAL_KEY"):
        out({"ok": False, "error": "FAL_KEY not set in environment.",
             "hint": "Add FAL_KEY=your_key to your env (.env / system env), then retry."})

    try:
        import fal_client
    except ImportError:
        out({"ok": False, "error": "fal_client not installed.", "hint": "pip install fal-client"})

    out_dir = os.path.join(args.out, args.cmd)
    pathlib.Path(out_dir).mkdir(parents=True, exist_ok=True)

    payload = parse_args_list(args.arg)
    if args.prompt is not None:
        payload.setdefault("prompt", args.prompt)

    def to_url(p):
        if p.startswith("http://") or p.startswith("https://"):
            return p
        if not os.path.exists(p):
            out({"ok": False, "error": f"file not found: {p}"})
        return fal_client.upload_file(p)

    try:
        if args.cmd in ("image",):
            pass  # prompt-only (+ any --arg)
        elif args.cmd == "edit":
            if not args.image:
                out({"ok": False, "error": "edit needs at least one --image"})
            urls = [to_url(p) for p in args.image]
            key = args.image_key or ("image_urls" if len(urls) > 1 else "image_url")
            payload[key] = urls if key.endswith("s") else urls[0]
        elif args.cmd == "video":
            if not args.image:
                out({"ok": False, "error": "video needs one --image (the source frame)"})
            key = args.image_key or "image_url"
            payload[key] = to_url(args.image[0])
        elif args.cmd == "upscale":
            if not args.video:
                out({"ok": False, "error": "upscale needs --video"})
            payload[args.image_key or "video_url"] = to_url(args.video)

        t0 = time.time()
        result = fal_client.subscribe(args.model, arguments=payload, with_logs=False)
        elapsed = round(time.time() - t0, 1)

        urls = find_urls(result, [])
        if not urls:
            out({"ok": False, "error": "no media URL in result", "raw": result})

        stem = f"{args.cmd}-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}"
        files = [download(u, out_dir, stem, i) for i, u in enumerate(urls)]
        out({"ok": True, "model": args.model, "cmd": args.cmd,
             "files": files, "urls": urls, "seconds": elapsed, "out_dir": out_dir})
    except SystemExit:
        raise
    except Exception as e:
        out({"ok": False, "error": f"{type(e).__name__}: {e}", "model": args.model, "payload": payload})


if __name__ == "__main__":
    main()

# Install , 3 steps, about 15 minutes

No terminal. No code. If you can make a folder and paste text, you can do this.

---

## 1. Put the skill in Claude

**Claude Desktop or claude.ai:**
Create a new **Project** and call it your business name. Upload `SKILL.md` and `facts-template.md` into the
project knowledge.

**Claude Code:**
Drop the whole `straight-answers` folder into `~/.claude/skills/`. Restart. It loads itself.

## 2. Build your facts file

In that project, say:

```
build my facts file
```

It will ask you about your business one area at a time. **Answer in your own words and answer badly.** Do not
write website copy. Where you do not know, say "not sure". Where you have not decided, say "not decided". It
will mark those honestly rather than inventing something tidy.

Fifteen minutes. This is the only part that takes effort, and it is the part that does the work.

Save what it gives you as `facts.md` and upload it into the project knowledge.

## 3. Install the stop rule

Say:

```
give me the stop rule
```

Copy the block it gives you into the project's **custom instructions**. That is the install finished.

---

## Test it before you trust it

Say:

```
test my setup
```

It will ask you three things about your business, and one of them will be something that is deliberately not
in your facts file.

- **Working:** it answers two and says "I do not have that in your facts file" to the third.
- **Not working:** it invents an answer to the third. Either the rule did not paste in properly, or your facts
  file is thinner than you thought.

Do not skip this. An untested setup feels the same as a working one right up until it embarrasses you.

---

## Using it day to day

Ask it anything. When it says **"I do not have that"**, that is it working, not failing. Add the missing thing
to `facts.md` and re-upload.

Within a few weeks it stops asking, because the file has caught up with your business.

**The bit most people skip:** a facts file you never update is just a longer prompt. One you top up every time
it asks is the thing that stops you re-explaining yourself forever.

---

## When it will not help

- It still does not know your **industry**, only what you told it. This stops it inventing things about **you**.
- If you will not do the fifteen minutes, it will keep making things up, and you are right not to trust it.
- It makes it wrong in a way you can **catch**. That is better than being wrong invisibly. It is not the same
  as being right.

---

*Free skill by Oloye.*

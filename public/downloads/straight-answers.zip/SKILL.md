---
name: straight-answers
description: >-
  Stops AI making things up about YOUR business. Builds a facts file from what is actually true about your
  work, then installs a rule that says any claim about you has to come from that file, and anything else gets
  "I do not have that" instead of a confident guess. Use when AI keeps inventing your prices, your services,
  your process or your results, or when you find yourself fact-checking every line it writes.
  A free skill by Oloye.
---

# Straight Answers

**The problem:** you ask AI something about your own business and it answers confidently and wrongly. Your
prices. What you offer. How your process works. So you check every line, which is the time it was supposed to
save you.

**Why it happens:** it does not know anything about you and it has no way to learn. It fills gaps with whatever
sounds most likely, and it has no instruction telling it to stop when there is nothing to go on. So it guesses.
Confidently. And you find out later, sometimes in front of a client.

**The fix is two things, and neither is a better prompt:**
1. Give it a **source** it must quote from.
2. Give it **permission to say "I do not have that"**, because without that it will always prefer an answer to a gap.

This skill sets up both. Takes about fifteen minutes once, then it just works.

---

## How to run it

### Step 1: build the facts file
Say: **"build my facts file"**

I will ask you about your business, one area at a time. Answer in your own words, badly is fine, do not tidy
it up. Where you do not know or have not decided, say so and I will write "not decided yet" rather than
inventing something.

Cover:
- **What you actually sell**, in the words you would use to a person, not a website
- **Prices.** Real ones. If it depends, what it depends on
- **What you do not do.** The jobs you turn down and why
- **Your process**, start to finish, and what the client actually has to do
- **The questions you get asked over and over**, and your real answers
- **Anything a client could check.** Turnaround times, what is included, what costs extra

Output: `facts.md`. Rules I follow when writing it:
- Only what you told me. Nothing filled in because it sounded right.
- Anything you were unsure about gets marked `UNCONFIRMED` so it never gets stated as fact.
- Anything you have not decided gets `NOT DECIDED YET` rather than a plausible guess.

### Step 2: install the stop rule
Say: **"give me the stop rule"**

I will output an instruction block. Paste it into your Claude Project instructions, along with `facts.md` in
the project knowledge. That is the whole install.

### Step 3: test it
Say: **"test my setup"**

I will ask you three questions about your business on purpose, where one of them is not in your facts file.
A working setup answers two and says "I do not have that" to the third. If it invents an answer to the third,
your facts file needs more, or the rule did not paste in properly.

---

## The stop rule (what gets installed)

```
SOURCE RULE

Everything you say about my business must come from facts.md.

If something is not in facts.md, say "I do not have that in your facts file"
and ask me for it. Do not fill the gap with something reasonable.
A reasonable invention is still an invention, and it goes out under my name.

This applies to: prices, what I offer, what I do not offer, turnaround times,
my process, what is included, results, and anything a client could check.

If facts.md marks something UNCONFIRMED, you may use it but you must say it
is unconfirmed. If it says NOT DECIDED YET, say that, do not pick one.

You can still write freely about anything that is not a claim about my business.
Opinions, structure, phrasing, ideas, all fine. The rule is about facts, not
about creativity.

When you use something from facts.md for anything a client will see, say which
part you used, so I can check it in two seconds instead of re-reading everything.
```

---

## What this does and does not do

**It does:** stop it inventing things about your business. Stop you re-explaining yourself every session. Make
the checking fast, because it tells you what it used.

**It does not:** make it right about the wider world. It does not know your industry, only what you told it.
This makes it wrong in a way you can **catch**, which is a different and better thing than being wrong invisibly.

**Honest limit:** this is setup, not a prompt. Fifteen minutes of answering questions properly. If you are not
up for that, it will keep making things up, and you are right not to trust it.

---

## Keeping it useful
Every time it says "I do not have that", you have found a gap. Add it to `facts.md`. Within a few weeks it
stops asking, because the file has caught up with your business.

**That is the bit most people miss.** A facts file you never update is just a longer prompt. One you top up
every time it asks is the thing that stops you repeating yourself forever.

---

*A free skill by Oloye. If it is useful, the same idea scaled to a whole job rather than one file is what I build.*

# facts.md , everything true about my business

> This is the only place your AI is allowed to get facts about you from. If it is not in here, it says
> "I do not have that" instead of guessing.
>
> **Fill it in badly.** Your words, not website words. You can tidy it later.
> **Mark anything you are unsure about `UNCONFIRMED`.** Mark anything you have not decided `NOT DECIDED YET`.
> Never write a neat-sounding guess. A guess in here becomes a confident lie out there.

Last updated: YYYY-MM-DD

---

## What I actually sell
<In the words you would use to a person, not the version on your website.>

## Prices
<Real numbers. If it depends, say what it depends on. If you have not settled on a price, write NOT DECIDED YET.>

| What | Price | Notes |
|---|---|---|
| | | |

## What I do NOT do
<The jobs you turn down, and why. This one stops more invented answers than any other section.>

## How it actually works
<Start to finish. What happens first, then what. Be specific about what the client has to do and when.>

1.
2.
3.

## What is included, and what costs extra
<Anything a client could later argue about. Revisions, calls, turnaround, extras.>

## Turnaround and availability
<How long things really take. Not your best ever, your normal.>

## Questions I get asked over and over
<Your real answers, in your words. Add to this every time someone asks something twice.>

**Q:**
**A:**

**Q:**
**A:**

## Results and proof
<Only what genuinely happened, with the real numbers. If you have none yet, write "None yet" and leave it.
An empty section is fine. An invented case study is not.>

## How I talk
<Paste two or three things you have actually written. An email, a post, a message to a client. This is how it
learns to sound like you rather than like everyone.>

---

## Gaps
<Every time your AI says "I do not have that", write it here. Then fill it in. Within a few weeks it stops asking.>

-

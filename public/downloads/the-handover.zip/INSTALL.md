# Install , 20 minutes, no terminal

## 1. Put the skill in Claude
**Claude Desktop or claude.ai:** make a Project, upload `SKILL.md` and `handover-brief-template.md` into the
project knowledge.
**Claude Code:** drop the `the-handover` folder into `~/.claude/skills/` and restart.

## 2. Work through it
In order. Each one is a short conversation, not a form.

```
what should I hand over
split it
capture my material
build the brief
```

**Step three is the one that matters.** It asks for three things you have actually written. Paste them raw,
typos and all. Skip it and the output will sound like everyone else, and you will think the tool is rubbish
when the problem is that it has nothing of you to work from.

Save the result as `handover-brief.md` and upload it to the project knowledge.

## 3. Install and test
```
install it
```
Paste the block into your project's custom instructions. Then:
```
do this week's
```

If what comes back does not sound like you, **the brief is thin, not broken.** Go back and add to it. That is
normal on the first pass.

## 4. Set the trigger
```
set my trigger
```
One day, one time, in your calendar. Not in your head. Motivation is exactly the thing you run out of in a
busy month, so it cannot be the trigger.

---

## Every week, ten minutes
```
weekly review
```
Read what went out, say what was off, corrections go back into the brief. That is what makes month six better
than week one.

**If you are checking it every day, you have not handed it over. You have just moved it.**

---

## When it will not help
- It hands over **one job**. It is not your marketing department.
- You still press go and you still review. It does not run itself.
- A thin brief produces thin output. Twenty minutes properly, or do not bother.

---

*Free skill by Oloye.*

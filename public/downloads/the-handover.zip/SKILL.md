---
name: the-handover
description: >-
  Builds the one document that lets your marketing happen in the weeks you disappear. Interviews you about
  what actually brings enquiries in, separates the decisions only you can make from the tasks anyone can do,
  captures how you really talk, then installs it so your Claude can produce that one job on demand without
  you starting from scratch. Use when your income swings because you go quiet whenever client work gets busy.
  A free skill by Oloye.
---

# The Handover

**The problem:** you get busy with clients, so you go quiet. A few weeks later the enquiries dry up, because
you have been invisible. So you panic-post, the work comes back, you get busy, and you disappear again.

**Why it happens:** your marketing depends on you being available. So it stops exactly when you are succeeding.
The version of you with time to post is the version with no money coming in.

**Why "just use AI to write it faster" does not fix it:** faster only helps the version of you who already has
a spare hour. That is not the version with the problem. What you need is not speed, it is something that does
not need you present.

**What this builds:** the handover brief. One document that means the job can happen without you, plus a
working setup that produces it on demand. Takes about twenty minutes once.

---

## How to run it

### Step 1: find the one job
Say: **"what should I hand over"**

I will ask what actually happened last time you got busy. Not what you meant to do, what actually stopped.
Then we narrow it to **one job**. Not everything. The single thing that, if it kept happening while you were
heads-down, would stop the dry spell.

I will push back if you pick more than one. Handing over three things badly is how this fails.

### Step 2: split decisions from tasks
Say: **"split it"**

For that one job, we separate:
- **Decisions** , what to say, who to target, what to charge, what you would never say. **These stay yours forever.**
- **Tasks** , writing it, formatting it, scheduling it, the repetition. **These are what gets handed over.**

Most people try to hand over the decisions and keep the tasks. That is backwards, and it is why their output
sounds like nobody.

### Step 3: capture the raw material
Say: **"capture my material"**

This is the step everyone skips and it is the one that decides whether this works. I will ask for:
- What you actually sell and who for, in your words
- The two or three things you always end up saying
- What you would never say, the stuff that makes you wince
- **Three things you have genuinely written.** A post, an email, a message to a client. Paste them raw.

Those three real pieces are what stop the output sounding generic. Without them this is just a nicer prompt.

### Step 4: build the brief
Say: **"build the brief"**

Output: `handover-brief.md`. It contains the job, the decisions that stay yours, the tasks handed over, your
material, and a worked example so there is no ambiguity about what good looks like.

Rules I follow writing it:
- Only what you told me. Nothing invented because it sounded right.
- Anything you were vague about gets marked `NEEDS YOUR ANSWER` rather than smoothed over.
- Your actual phrasing is preserved. I do not tidy your voice into marketing English.

### Step 5: install and test
Say: **"install it"**

I output the instruction block for your Claude Project. Then say **"do this week's"** and it produces the job
from the brief. If what comes back does not sound like you, the brief is thin, not broken. Add to it.

### Step 6: set the trigger
Say: **"set my trigger"**

One day, one time, recurring. In your calendar, not in your head. **Motivation is the exact thing you run out
of in a busy month**, so it cannot be the trigger. If it only happens when you remember, nothing has changed.

---

## The weekly review, ten minutes

Say: **"weekly review"**

It shows you what went out and asks what was off. Your corrections go back into the brief. That is what makes
month six better than week one.

**If you find yourself checking it daily, you have not handed it over. You have just moved it.**

---

## What this does and does not do

**It does:** mean the job can happen in a week you are fully booked. Stop you starting from a blank page.
Sound like you, because it is built from things you actually wrote.

**It does not:** run itself. You still trigger it and you still review it. This hands over **one job**, not your
marketing.

**Honest limit:** twenty minutes of answering properly, and a brief that stays thin will produce thin output.
If you will not do step 3 properly, skip the whole thing, it will not work and you will blame the tool.

---

*A free skill by Oloye. This hands over one job and still needs you to press go. The version that runs on its
own, across every job, is what I build.*

# handover-brief.md

> The document that lets this job happen in a week you are fully booked.
>
> **Fill it in badly, in your words.** Do not write website English. Anything you are vague about, mark
> `NEEDS YOUR ANSWER` rather than smoothing it over. A vague brief produces vague output and you will
> blame the tool.

Last updated: YYYY-MM-DD

---

## The one job
<One job. Not three. The single thing that, if it kept happening while you were heads-down, would stop the dry spell.>

**What actually stops when I get busy:**

**What it costs me when it stops:**

---

## Decisions , these stay mine, always
<Nobody else makes these. Not a VA, not AI, not a tool.>

- **Who this is for:**
- **What I am actually selling right now:**
- **What I will never say:**
- **The one thing I want people to take away:**

## Tasks , these are handed over
<The repetition. Writing it, formatting it, scheduling it.>

-
-

---

## My material

**What I sell, in my words:**

**The two or three things I always end up saying:**

**What makes me wince when other people say it:**

### Three things I actually wrote
<Paste them raw. Typos included. This is the bit that stops the output sounding like everyone else.
If you skip this, the rest does not work.>

**1.**

**2.**

**3.**

---

## What good looks like
<One worked example. Either something you were happy with, or write one now. Without this there is no
standard to hit and you will keep saying "not quite" without being able to say why.>

---

## What went wrong last time
<Every review, add what was off. This is the file getting better. An unedited brief is a brief that will
keep making the same mistake.>

| Date | What was off | What I changed |
|---|---|---|
| | | |

---
name: youtube-pipeline
description: Take a YouTube video that already performs and make your OWN long-form 16:9 version, narrated in your ElevenLabs voice over screen recordings, ZERO talking head. Downloads + transcribes (Whisper) + Claude-vision reverse-engineers the video into structure (keep) vs swappable content slots (replace), asks you to fill the slots with your own content, then writes a long-form narration voiceover script (paste-ready for ElevenLabs) plus a synced screen-recording plan, chapters, 3 titles, and a description. Never invents your opinions. Use for "make my version of this youtube video", "turn this youtube video into my own", "reverse-engineer this youtube tutorial", "youtube script from this video".
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, Skill
---

# YouTube Pipeline — a proven YouTube video becomes YOUR long-form version

The long-form counterpart to `reel-pipeline`. You find a YouTube video on your topic that performs. This makes your own **long-form 16:9 tutorial**: same concept and proven structure, your content and take, **narrated in your ElevenLabs voice over screen recordings**. No face, ever.

It returns:
- **`title_options`** — 3 searchable + curiosity YouTube titles.
- **`sections`** — each a chapter: the **narration** (voiceover) plus the exact **screen recording** to capture and any on-screen text, synced.
- **`narration_full`** — all the narration joined, clean, **paste straight into ElevenLabs** with your cloned voice.
- **`chapters`** — YouTube chapter list.
- **`youtube_description`** — description with one CTA.
- **`missing`** — anything it needed from you and didn't get (it flags gaps, never invents your opinions).

## Prerequisites
This skill does not ship its own engine code. Before running anything:
1. The `reel-pipeline` skill must be installed at `~/.claude/skills/reel-pipeline/` (it owns the engine code).
2. Check the long-form generator exists: `~/.claude/skills/reel-pipeline/scripts/generate_youtube.py`. If it is missing, install or update reel-pipeline first.
3. Install the engine's Python dependencies: `pip install -r ~/.claude/skills/reel-pipeline/scripts/requirements.txt`.

## Shared engine (do NOT duplicate)
This skill reuses the `reel-pipeline` engine. All scripts live in
`~/.claude/skills/reel-pipeline/scripts/`. The only difference is `--platform youtube`, which swaps the
final stage to `generate_youtube.py` (long-form narration voiceover instead of a to-camera reel script).
Edit the engine in `reel-pipeline/scripts/`, never fork a second copy.

## Setup (one-time)
Same as reel-pipeline. ffmpeg + ffprobe on PATH, Python 3.10+, and `ANTHROPIC_API_KEY` in
`reel-pipeline/scripts/.env`. **No Instagram cookies needed** (YouTube downloads are public). yt-dlp handles YouTube natively.

## How to run it (two phases)
Run from the shared scripts dir:
```bash
cd ~/.claude/skills/reel-pipeline/scripts
```
PowerShell equivalent:
```powershell
Set-Location "$env:USERPROFILE\.claude\skills\reel-pipeline\scripts"
```

### Phase A — reverse-engineer the video, see what it needs from you
```bash
python main.py "<youtube url>" --platform youtube --analyze-only
```
Downloads, transcribes, and breaks the video into structure + swappable slots. Prints the topic, hook, format, and exactly what content it needs from you. Writes `output/<id>/fill_template.json`.

> Long videos take time: Whisper runs locally on CPU, and a multi-minute video can take several minutes to transcribe. Frame extraction is capped at 40 scene frames, so the vision cost stays bounded.

### Phase B — you supply your content, it writes your long-form script
Read the printed slots to the user, get their own picks/take/CTA, write them into a fill file's `mine`/`my_take`/`cta` fields, then:
```bash
python generate_youtube.py output/<id>/transcript.json output/<id>/timeline.json "the creator's angle/audience" --fill output/<id>/fill.json > output/<id>/youtube_output.json
```
Note: the standalone `generate_youtube.py` prints the JSON to stdout, so the redirection above is what writes `youtube_output.json`. Only the full `main.py` run saves the file itself.
Or a full run in one go:
```bash
python main.py "<youtube url>" --platform youtube --brief "the creator's angle" --fill output/<id>/fill.json
```
The `main.py` route saves `output/<id>/youtube_output.json` itself; the standalone `generate_youtube.py` route relies on the stdout redirection shown above.

### Then the voiceover (ElevenLabs, you do this)
Take `narration_full` and paste it into ElevenLabs, generate with your cloned voice, and drop the audio into your editor. The `sections` tell you which screen recording lines up with which part of the narration.

> **Owner config: the Airtable base, table, and field IDs in the Learning and Memory sections below are Oloye's private Brain IDs. If you are not Oloye, replace them with your own Airtable IDs or skip these two sections entirely; the pipeline runs fine without them.**

### Learning — read Active Lessons and inject them (before generating)
Same shared ledger as `reel-pipeline` and the blog loop. Before the generate step:
1. `list_records_for_table` on Lessons `YOUR_LESSONS_TABLE_ID` (base `YOUR_AIRTABLE_BASE_ID`), keep rows where Active=true and Area in {`content`, `video`, `Production / UGC`, `general`}.
2. Write the Lesson strings to `output/<id>/lessons.json` and pass `--lessons output/<id>/lessons.json` to `main.py`/`generate_youtube.py`. Injected as hard constraints.

### Then polish + deliver (LOCKED)
1. Run the narration + titles + description through the **`oloye-voice`** skill for the public pass.
2. Deliver as a formatted **Google Doc** (Oloye does not read raw markdown/JSON). Build clean HTML (h1 title, h2 sections: Titles / Narration for ElevenLabs / Screen plan table / Chapters / Description) and create it with
   `mcp__claude_ai_Google_Drive__create_file` (`contentMimeType: "text/html"`, `textContent: "<html>"`). Title it `YouTube Script - <topic> (Oloye.)`. Return the `viewUrl`. The JSON stays as the working copy.

> Note: `oloye-voice` + the Google Doc export are the Oloye-house pipeline. If the `oloye-voice` skill or the Google Drive connector is not available, skip those steps and deliver the `youtube_output.json` contents directly as formatted text (titles, narration, screen plan, chapters, description).

### Memory — log to the Content table (after the Google Doc)
(Owner config, see the note above: these are Oloye's private Brain IDs, replace with your own or skip.)
Write ONE row to Content `YOUR_CONTENT_TABLE_ID` via `create_records_for_table` with `typecast: true`:
- Title `YOUR_TITLE_FIELD_ID`: `<topic> (youtube)`
- Channel `YOUR_CHANNEL_FIELD_ID`: `YouTube` (the Content Channel field has no long-form YouTube choice yet; `typecast: true` auto-adds it on the first log)
- Format `YOUR_FORMAT_FIELD_ID`: `video`
- Owner `YOUR_OWNER_FIELD_ID`: `<you>`
- Status `YOUR_STATUS_FIELD_ID`: `review`
- Link `YOUR_LINK_FIELD_ID`: the Google Doc `viewUrl`
- Copy `YOUR_COPY_FIELD_ID`: `narration_full` + one-line provenance (source URL, section count, CTA)

The memory + learning loop is documented in full in the canonical spec at `~/.claude/skills/_shared/brain-content-loop.md`; the mechanism is identical across skills, this is the same shared engine and the same shared Brain.

## Where this sits in the content chain
```
FIND / LEARN     →  a YouTube video that performs
REMAKE SCRIPT    →  youtube-pipeline (this)  →  oloye-voice (polish)
NARRATE          →  ElevenLabs (your cloned voice) from narration_full
RECORD           →  you (screen recordings per the sections)
EDIT TO VIDEO    →  your editor (CapCut / Descript): VO track + screen recordings + on-screen text
PUBLISH          →  YouTube (title + chapters + description all provided)
```
No talking head anywhere. You provide screen recordings; ElevenLabs provides the voice.

## Guardrails (inherited from the shared engine)
- Never invents your opinions. Unfilled slot → `[NEEDS FROM YOU: ...]` + listed in `missing`.
- Em dashes stripped from all output. `max_tokens=12000` with a truncation guard (long-form is longer).
- Voice: core oloye-voice rules baked into the generator; `oloye-voice` skill is the canonical public pass.

## Common failures + fixes
- **Whisper very slow / stalls** on a long video → normal on CPU. Let it run, or trim the source, or raise timeout. Do not raise `WHISPER_MODEL` for speed (bigger = slower); only raise it for accuracy.
- **`yt-dlp failed`** → `pip install -U yt-dlp` (YouTube changed layout), or the video is private/age-gated.
- **ffmpeg not found** → install ffmpeg, ensure `ffmpeg`/`ffprobe` on PATH.
